#!/usr/bin/env python3
"""
Generic YAML-driven PySpark job runner for AWS Glue.
This script is purposely simple for teaching: parse a YAML config and execute actions.
"""

import sys
from typing import Dict, Any

from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
import yaml


def parse_args():
    """Parse arguments using AWS Glue's getResolvedOptions"""
    args = getResolvedOptions(sys.argv, ['config_path'])
    return args


def load_yaml(path: str) -> Dict[str, Any]:
    if path.startswith('s3://'):
        # In Glue, you would use boto3 to read S3; simplified here for course
        import boto3
        s3 = boto3.client('s3')
        bucket_key = path.replace('s3://', '', 1)
        bucket, key = bucket_key.split('/', 1)
        obj = s3.get_object(Bucket=bucket, Key=key)
        return yaml.safe_load(obj['Body'].read())
    else:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)


def read_action(spark: SparkSession, params: Dict[str, Any]) -> DataFrame:
    fmt = params.get('format', 'csv')
    path = params['path']
    options = params.get('options', {})
    reader = spark.read.format(fmt)
    for k, v in options.items():
        reader = reader.option(k, v)
    return reader.load(path)


def select_action(df: DataFrame, params: Dict[str, Any]) -> DataFrame:
    cols = params['columns']
    return df.select([F.col(c) for c in cols])


def with_columns_action(df: DataFrame, params: Dict[str, Any]) -> DataFrame:
    # params: { columns: [{name: 'new_col', expr: "amount * 0.2"}, ...] }
    for c in params.get('columns', []):
        name = c['name']
        expr = c['expr']
        df = df.withColumn(name, F.expr(expr))
    return df


def filter_action(df: DataFrame, params: Dict[str, Any]) -> DataFrame:
    # params: { expr: "amount > 0" }
    return df.filter(F.expr(params['expr']))


def join_action(left: DataFrame, right: DataFrame, params: Dict[str, Any]) -> DataFrame:
    # params: { on: ["key1", "key2"], how: "left|inner|right|full" }
    how = params.get('how', 'inner')
    on = params['on']
    return left.join(right, on=on, how=how)


def write_action(df: DataFrame, params: Dict[str, Any]) -> None:
    fmt = params.get('format', 'parquet')
    mode = params.get('mode', 'overwrite')
    path = params['path']
    options = params.get('options', {})
    writer = df.write.mode(mode).format(fmt)
    for k, v in options.items():
        writer = writer.option(k, v)
    if 'partitionBy' in params:
        writer = writer.partitionBy(params['partitionBy'])
    writer.save(path)


def main():
    args = parse_args()
    spark = SparkSession.builder.appName('yaml-runner').getOrCreate()

    cfg = load_yaml(args['config_path'])
    views: Dict[str, DataFrame] = {}

    # Read sources
    for src in cfg.get('sources', []):
        name = src['name']
        views[name] = read_action(spark, src)

    # Transforms (optional)
    for t in cfg.get('transforms', []):
        t_type = t['type']
        out = t['as']
        if t_type == 'select':
            df = select_action(views[t['from']], t)
        elif t_type == 'with_columns':
            df = with_columns_action(views[t['from']], t)
        elif t_type == 'filter':
            df = filter_action(views[t['from']], t)
        elif t_type == 'join':
            df = join_action(views[t['left']], views[t['right']], t)
        else:
            raise ValueError(f'Unknown transform type: {t_type}')
        views[out] = df

    # Writes
    for tgt in cfg.get('targets', []):
        df = views[tgt['from']]
        write_action(df, tgt)

    spark.stop()


if __name__ == '__main__':
    main()
