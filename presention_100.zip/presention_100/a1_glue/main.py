import os
import boto3
import yaml
from typing import Optional
from nicegui import ui, app
from fastapi import Request, UploadFile, File, HTTPException
from datetime import datetime


# AWS Clients
s3_client = boto3.client('s3')
glue_client = boto3.client('glue')

# Configuration
BUCKET_NAME = os.getenv('BUCKET_NAME', 'glue-play-eric-ok1')
GLUE_ROLE = os.getenv('GLUE_ROLE', 'GlueYAMLRunnerRole')
SCRIPT_LOCATION = f's3://{BUCKET_NAME}/scripts/job_runner.py'


@ui.page('/')
def index_page():
    with ui.header().classes('items-center justify-between px-4'):
        ui.label('🏰 Disney-Inspired ETL Platform').classes('text-h5')
        ui.label(f'Bucket: {BUCKET_NAME}').classes('text-caption')

    with ui.column().classes('w-full items-center p-4'):
        
        # File Upload Section
        with ui.card().classes('w-full max-w-3xl'):
            ui.label('📤 Upload Files to S3').classes('text-h6 mb-2')
            
            upload_status = ui.label().classes('text-caption')
            
            async def handle_upload(e):
                upload_status.set_text('Uploading...')
                
                try:
                    filename = e.name
                    content = e.content.read()
                    
                    # Determine S3 key based on file type
                    if filename.endswith('.yaml') or filename.endswith('.yml'):
                        s3_key = f'configs/{filename}'
                    elif filename.endswith('.py'):
                        s3_key = f'scripts/{filename}'
                    elif filename.endswith('.csv'):
                        s3_key = f'raw/orders/{filename}'
                    else:
                        s3_key = f'uploads/{filename}'
                    
                    # Upload to S3
                    s3_client.put_object(
                        Bucket=BUCKET_NAME,
                        Key=s3_key,
                        Body=content
                    )
                    
                    upload_status.set_text(f'✅ Uploaded: s3://{BUCKET_NAME}/{s3_key}')
                    ui.notify(f'Uploaded {filename} successfully!', type='positive')
                    
                except Exception as ex:
                    upload_status.set_text(f'❌ Error: {str(ex)}')
                    ui.notify(f'Upload failed: {str(ex)}', type='negative')
            
            ui.upload(
                on_upload=handle_upload,
                multiple=True,
                auto_upload=True
            ).props('accept=".yaml,.yml,.py,.csv" color=primary').classes('w-full')

        # Job Submission Section
        with ui.card().classes('w-full max-w-3xl mt-4'):
            ui.label('🚀 Submit Glue Job').classes('text-h6 mb-2')
            
            job_name = ui.input('Job Name', placeholder='orders-yaml-runner').props('filled').classes('w-full')
            config_name = ui.input(
                'Config Name', 
                placeholder='orders_processing.yaml'
            ).props('filled').classes('w-full')
            
            status = ui.label().classes('text-caption mt-2')
            job_run_id = ui.label().classes('text-caption')
            full_config_path = ui.label().classes('text-caption')

            async def submit():
                if not job_name.value:
                    ui.notify('Please enter a job name', type='warning')
                    return
                
                if not config_name.value:
                    ui.notify('Please enter a config name', type='warning')
                    return
                
                # Construct full S3 path
                config_path = f's3://{BUCKET_NAME}/configs/{config_name.value}'
                full_config_path.set_text(f'📍 Config: {config_path}')
                
                status.set_text('⏳ Checking if job exists...')
                
                try:
                    # Check if job exists, create if not
                    try:
                        glue_client.get_job(JobName=job_name.value)
                        status.set_text('✓ Job exists, starting run...')
                    except glue_client.exceptions.EntityNotFoundException:
                        status.set_text('⏳ Job not found, creating job...')
                        
                        # Create the job
                        glue_client.create_job(
                            Name=job_name.value,
                            Role=GLUE_ROLE,
                            Command={
                                'Name': 'glueetl',
                                'ScriptLocation': SCRIPT_LOCATION,
                                'PythonVersion': '3'
                            },
                            DefaultArguments={
                                '--job-language': 'python'
                            },
                            GlueVersion='4.0',
                            MaxCapacity=2.0
                        )
                        
                        status.set_text('✅ Job created, starting run...')
                        ui.notify(f'Created job: {job_name.value}', type='positive')
                    
                    # Start Glue job run with the specified config
                    response = glue_client.start_job_run(
                        JobName=job_name.value,
                        Arguments={
                            '--config_path': config_path
                        }
                    )
                    
                    run_id = response['JobRunId']
                    status.set_text(f'✅ Job submitted successfully!')
                    job_run_id.set_text(f'Job Run ID: {run_id}')
                    ui.notify(f'Job started: {run_id}', type='positive')
                    
                except Exception as ex:
                    status.set_text(f'❌ Error: {str(ex)}')
                    ui.notify(f'Job submission failed: {str(ex)}', type='negative')

            ui.button('Submit Job', on_click=submit).props('color=primary icon=play_arrow')

        # Job Status Section
        with ui.card().classes('w-full max-w-3xl mt-4'):
            ui.label('📊 Check Job Status').classes('text-h6 mb-2')
            
            status_job_name = ui.input('Job Name', placeholder='orders-yaml-runner').props('filled').classes('w-full')
            status_run_id = ui.input('Run ID', placeholder='jr_...').props('filled').classes('w-full')
            status_result = ui.label().classes('text-caption mt-2')
            
            async def check_status():
                if not status_job_name.value or not status_run_id.value:
                    ui.notify('Please enter both job name and run ID', type='warning')
                    return
                
                status_result.set_text('⏳ Checking status...')
                
                try:
                    response = glue_client.get_job_run(
                        JobName=status_job_name.value,
                        RunId=status_run_id.value
                    )
                    
                    job_run = response['JobRun']
                    state = job_run['JobRunState']
                    
                    status_icon = {
                        'SUCCEEDED': '✅',
                        'FAILED': '❌',
                        'RUNNING': '⏳',
                        'STOPPED': '⏸️',
                        'TIMEOUT': '⏱️'
                    }.get(state, '❓')
                    
                    status_result.set_text(f'{status_icon} Status: {state}')
                    
                    if state == 'FAILED' and 'ErrorMessage' in job_run:
                        status_result.set_text(f'{status_icon} Status: {state}\nError: {job_run["ErrorMessage"]}')
                    
                    ui.notify(f'Job status: {state}', type='positive' if state == 'SUCCEEDED' else 'info')
                    
                except Exception as ex:
                    status_result.set_text(f'❌ Error: {str(ex)}')
                    ui.notify(f'Status check failed: {str(ex)}', type='negative')
            
            ui.button('Check Status', on_click=check_status).props('color=secondary icon=refresh')

        # S3 Browser Section
        with ui.card().classes('w-full max-w-3xl mt-4'):
            ui.label('📁 Browse S3 Files').classes('text-h6 mb-2')
            
            prefix_input = ui.input('Prefix', placeholder='curated/orders/').props('filled').classes('w-full')
            files_list = ui.column().classes('w-full')
            
            async def browse_s3():
                files_list.clear()
                prefix = prefix_input.value or ''
                
                try:
                    response = s3_client.list_objects_v2(
                        Bucket=BUCKET_NAME,
                        Prefix=prefix
                    )
                    
                    if 'Contents' in response:
                        with files_list:
                            ui.label(f'Found {len(response["Contents"])} files:').classes('text-caption mb-2')
                            for obj in response['Contents'][:20]:  # Limit to 20 files
                                key = obj['Key']
                                size = obj['Size']
                                modified = obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
                                ui.label(f'📄 {key} ({size} bytes) - {modified}').classes('text-caption')
                    else:
                        with files_list:
                            ui.label('No files found').classes('text-caption')
                    
                    ui.notify('Files loaded', type='positive')
                    
                except Exception as ex:
                    with files_list:
                        ui.label(f'❌ Error: {str(ex)}').classes('text-caption')
                    ui.notify(f'Browse failed: {str(ex)}', type='negative')
            
            ui.button('Browse', on_click=browse_s3).props('color=secondary icon=folder_open')


# API Endpoints
@app.get('/api/health')
def health():
    return {'status': 'ok', 'bucket': BUCKET_NAME}


@app.post('/api/upload')
async def upload_file(file: UploadFile = File(...), prefix: str = 'uploads'):
    """Upload file to S3"""
    try:
        content = await file.read()
        s3_key = f'{prefix}/{file.filename}'
        
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=s3_key,
            Body=content
        )
        
        return {
            'success': True,
            'bucket': BUCKET_NAME,
            'key': s3_key,
            's3_uri': f's3://{BUCKET_NAME}/{s3_key}'
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post('/api/submit_job')
async def submit_job(req: Request):
    """Submit Glue job"""
    try:
        data = await req.json()
        job_name = data.get('job_name')
        config_path = data.get('config_path')
        
        if not job_name or not config_path:
            raise HTTPException(status_code=400, detail='job_name and config_path required')
        
        response = glue_client.start_job_run(
            JobName=job_name,
            Arguments={
                '--config_path': config_path
            }
        )
        
        return {
            'success': True,
            'job_name': job_name,
            'job_run_id': response['JobRunId']
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get('/api/job_status/{job_name}/{run_id}')
def job_status(job_name: str, run_id: str):
    """Get Glue job status"""
    try:
        response = glue_client.get_job_run(
            JobName=job_name,
            RunId=run_id
        )
        
        job_run = response['JobRun']
        
        return {
            'job_name': job_name,
            'run_id': run_id,
            'status': job_run['JobRunState'],
            'started_on': job_run.get('StartedOn', '').isoformat() if job_run.get('StartedOn') else None,
            'completed_on': job_run.get('CompletedOn', '').isoformat() if job_run.get('CompletedOn') else None,
            'error_message': job_run.get('ErrorMessage')
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ in {"__main__", "__mp_main__"}:
    ui.run(host='0.0.0.0', port=int(os.getenv('PORT', '8084')))
