# AWS Glue YAML-Driven ETL Platform - Setup Guide

Complete step-by-step PowerShell commands for setting up and running the Disney-inspired ETL platform.

---

## Part 1: S3 Bucket Setup

### Step 1.1: Create S3 Bucket

```powershell
# Create bucket in us-east-1 region
aws s3 mb s3://glue-play-eric-ok1 --region us-east-1

# Set environment variable for bucket name
$env:BUCKET_NAME="glue-play-eric-ok1"
```

### Step 1.2: Create Folder Structure

```powershell
# Create required folders in S3
aws s3api put-object --bucket ${env:BUCKET_NAME} --key raw/orders/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key curated/orders/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key scripts/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key configs/
```

---

## Part 2: Upload Files to S3

### Step 2.1: Upload Sample Data and Scripts

```powershell
# Upload sample orders CSV
aws s3 cp sample_orders.csv s3://${env:BUCKET_NAME}/raw/orders/

# Upload job runner script
aws s3 cp job_runner.py s3://${env:BUCKET_NAME}/scripts/

# Upload YAML configuration
aws s3 cp orders_processing.yaml s3://${env:BUCKET_NAME}/configs/
```

### Step 2.2: Verify Uploads

```powershell
# List all files in bucket
aws s3 ls s3://${env:BUCKET_NAME}/ --recursive
```

---

## Part 3: IAM Role Configuration

### Step 3.1: Create Glue Service Role

```powershell
# Create IAM role with trust policy
aws iam create-role `
  --role-name GlueYAMLRunnerRole `
  --assume-role-policy-document file://glue-trust-policy.json
```

### Step 3.2: Attach AWS Managed Policy

```powershell
# Attach AWS Glue service role policy
aws iam attach-role-policy `
  --role-name GlueYAMLRunnerRole `
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole
```

### Step 3.3: Add S3 Access Policy

```powershell
# Attach custom S3 access policy
aws iam put-role-policy `
  --role-name GlueYAMLRunnerRole `
  --policy-name S3Access `
  --policy-document file://s3-access-policy.json
```

### Step 3.4: Verify Role Configuration

```powershell
# Get role details
aws iam get-role --role-name GlueYAMLRunnerRole
```

---

## Part 4: AWS Configuration

### Step 4.1: Set Default Region

```powershell
# Configure AWS CLI default region
aws configure set region us-east-1
```

---

## Part 5: Create and Run Glue Job

### Step 5.1: Create Glue Job

```powershell
# Create Glue ETL job
aws glue create-job `
  --name orders-yaml-runner `
  --role GlueYAMLRunnerRole `
  --command '{
    "Name": "glueetl",
    "ScriptLocation": "s3://glue-play-eric-ok1/scripts/job_runner.py",
    "PythonVersion": "3"
  }' `
  --default-arguments '{
    "--config_path": "s3://glue-play-eric-ok1/configs/orders_processing.yaml",
    "--job-language": "python"
  }' `
  --glue-version "4.0" `
  --max-capacity 2 `
  --region us-east-1
```

### Step 5.2: Start Job Run

```powershell
# Trigger the Glue job
aws glue start-job-run --job-name orders-yaml-runner
```

### Step 5.3: Check Job Status

```powershell
# Check job run status (replace with your JobRunId)
aws glue get-job-run `
  --job-name orders-yaml-runner `
  --run-id jr_a826cb4ece2a8684cd085b1270d0b9c3cb343863003632fb5ba6b0cfc34d36b1 `
  --query 'JobRun.JobRunState'

# Expected output: "SUCCEEDED"
```

---

## Part 6: Verify Output

### Step 6.1: List Processed Files

```powershell
# List curated/processed files
aws s3 ls s3://${env:BUCKET_NAME}/curated/orders/ --recursive

# Expected: Parquet files partitioned by year
# Example: curated/orders/year=2024/part-00000-*.snappy.parquet
```

---

## Summary

**S3 Bucket Created**: `glue-play-eric-ok1`  
**IAM Role Created**: `GlueYAMLRunnerRole`  
**Glue Job Created**: `orders-yaml-runner`  
**Job Status**: SUCCEEDED  
**Output**: Parquet files in `s3://glue-play-eric-ok1/curated/orders/`

---

## Notes

- All commands are PowerShell-compatible
- Environment variable `$env:BUCKET_NAME` is used throughout
- Region is set to `us-east-1`
- Job uses Glue version 4.0 with 2 DPUs