```ps1
>  aws s3 mb s3://glue-play-eric-ok1 --region us-east-1
make_bucket: glue-play-eric-ok1
$env:BUCKET_NAME="glue-play-eric-ok1"


# Create folder structure
aws s3api put-object --bucket ${env:BUCKET_NAME} --key raw/orders/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key curated/orders/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key scripts/
aws s3api put-object --bucket ${env:BUCKET_NAME} --key configs/

```

```ps1

aws s3 cp sample_orders.csv s3://${env:BUCKET_NAME}/raw/orders/
upload: .\sample_orders.csv to s3://glue-play-eric-ok1/raw/orders/sample_orders.csv

aws s3 cp job_runner.py s3://${env:BUCKET_NAME}/scripts/
upload: .\job_runner.py to s3://glue-play-eric-ok1/scripts/job_runner.py
```



>  ^C
F:\glue_disney_inspired_etl_platform\code_block
>  aws s3 cp glue/job_runner.py s3://${env:BUCKET_NAME}/scripts/  


>  aws s3 ls s3://${env:BUCKET_NAME}/ --recursive
2025-10-15 20:41:44          0 configs/
2025-10-15 20:41:38          0 curated/orders/
2025-10-15 20:41:37          0 raw/orders/
2025-10-15 20:44:57        454 raw/orders/sample_orders.csv
2025-10-15 20:41:40          0 scripts/
2025-10-15 20:50:22       3754 scripts/job_runner.py
k


aws s3 cp orders_processing.yaml s3://${env:BUCKET_NAME}/configs/




>  aws iam create-role --role-name GlueYAMLRunnerRole --assume-role-policy-document file://glue-trust-policy.json
{
    "Role": {
        "Path": "/",
        "RoleName": "GlueYAMLRunnerRole",
        "RoleId": "AROA3PRH5FRIFFCZWLPP7",
        "Arn": "arn:aws:iam::789283941456:role/GlueYAMLRunnerRole",
        "CreateDate": "2025-10-15T19:03:32+00:00",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "Service": "glue.amazonaws.com"
                    },
                    "Action": "sts:AssumeRole"
                }
            ]
        }
    }
}




aws iam attach-role-policy --role-name GlueYAMLRunnerRole --policy-arn arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole



aws iam put-role-policy --role-name GlueYAMLRunnerRole --policy-name S3Access --policy-document file://s3-access-policy.json



aws iam get-role --role-name GlueYAMLRunnerRole





aws glue create-job --name orders-yaml-runner --role GlueYAMLRunnerRole --command '{
    "Name": "glueetl",
    "ScriptLocation": "s3://glue-play-eric-ok1/scripts/job_runner.py",
    "PythonVersion": "3"
  }' --default-arguments '{
    "--config_path": "s3://glue-play-eric-ok1/configs/orders_processing.yaml",
    "--job-language": "python"
  }' --glue-version "4.0" --max-capacity 2 --region us-east-1






  aws configure set region us-east-1






  aws glue start-job-run --job-name orders-yaml-runner


  >    aws glue start-job-run --job-name orders-yaml-runner
{
    "JobRunId": "jr_bbfbc5ba25b433418acca3cd8166d768bcb6f4fd123dce1bab13e5472470f1af"
}

F:\glue_disney_inspired_etl_platform\code_block
>



aws glue get-job-run --job-name orders-yaml-runner --run-id jr_a826cb4ece2a8684cd085b1270d0b9c3cb343863003632fb5ba6b0cfc34d36b1 --query 'JobRun.JobRunState'



>  aws glue get-job-run --job-name orders-yaml-runner --run-id jr_a826cb4ece2a8684cd085b1270d0b9c3cb343863003632fb5ba6b0cfc34d36b1 --query 'JobRun.JobRunState'
"SUCCEEDED"

```bash
aws s3 ls s3://${env:BUCKET_NAME}/curated/orders/ --recursive



>  aws s3 ls s3://${env:BUCKET_NAME}/curated/orders/ --recursive
2025-10-15 21:52:32       2880 curated/orders/year=2024/part-00000-393ea2a6-5331-467c-9349-ddb757c76d9a.c000.snappy.parquet
F:\glue_disney_inspired_etl_platform\code_block