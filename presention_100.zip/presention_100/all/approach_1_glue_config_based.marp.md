---
marp: true
size: 16:9
paginate: true
theme: default
class: lead
style: |
  section {
    background-color: #ffffff;
  }
  h1 {
    color: #FF9900;
    font-weight: bold;
  }
  h2 {
    color: #232F3E;
  }
  h3 {
    color: #FF9900;
  }
  code {
    background-color: #f4f4f4;
  }
  .columns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }
---

# Replacing Informatica with AWS Glue
## Approach 1: Configuration-Based ETL Platform

**A YAML-Driven, Serverless Data Engineering Solution**

---

## The Challenge: Moving from Informatica

### Current State
- **Informatica PowerCenter** — expensive, proprietary ETL tool
- Manual workflow design for each pipeline
- Limited scalability and cloud integration
- High licensing costs

### Our Goal
- **Cost-effective** cloud-native replacement
- **Automated** and configuration-driven
- **Scalable** serverless architecture
- **Integrated** with modern data stack (dbt)

---

## Approach 1: AWS Glue Configuration-Based Solution

### Core Concept
**Single generic PySpark runner (`job_runner.py`) + YAML configuration files**

### Key Components
1. **YAML Contracts** — define sources, transforms, and targets
2. **Generic Job Runner** — PySpark engine that executes YAML configs
3. **NiceGUI UI** — web interface for job submission and monitoring
4. **AWS Glue** — serverless Spark runtime
5. **dbt Integration** — downstream transformations continue in dbt

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│              NiceGUI Monolith (App Runner)                  │
│  ┌──────────────────┐          ┌──────────────────┐        │
│  │   UI Pages       │          │  FastAPI Routes  │        │
│  │  - Job Submit    │ ◄──────► │  /api/submit_job │        │
│  │  - Monitor       │          │  /api/job_status │        │
│  │  - S3 Browser    │          │  /api/health     │        │
│  └──────────────────┘          └──────────────────┘        │
└─────────────────────────────────────────────────────────────┘
                │                           │
                └───────────┬───────────────┘
                            ▼
                ┌───────────────────────┐
                │   AWS Glue Job        │
                │   job_runner.py       │
                │   - Reads YAML config │
                │   - Executes pipeline │
                └───────────────────────┘
                            │
                ┌───────────┼───────────┐
                ▼           ▼           ▼
         ┌──────────┐ ┌─────────┐ ┌────────────┐
         │   S3     │ │CloudWatch│ │    dbt     │
         │  Config  │ │  Logs    │ │ Transform  │
         │  & Data  │ │          │ │            │
         └──────────┘ └─────────┘ └────────────┘
```

---

## The YAML Contract: Configuration Over Code

### Example: Order Processing Pipeline

```yaml
# Job Metadata
job_name: orders_processing
description: Process e-commerce orders with tax calculation
owner: data-engineering@company.com
version: 1.0

# Data Sources
sources:
  - name: raw_orders
    format: csv
    path: s3://my-bucket/raw/orders/
    options:
      header: "true"
      inferSchema: "true"
```

---

## YAML Contract: Transformations

```yaml
# Transformation Pipeline
transforms:
  # Step 1: Filter completed orders
  - type: filter
    from: raw_orders
    as: completed_orders
    expr: "status = 'completed'"
  
  # Step 2: Calculate totals
  - type: with_columns
    from: completed_orders
    as: orders_with_totals
    columns:
      - name: total_price
        expr: "quantity * unit_price"
      - name: tax
        expr: "total_price * 0.2"
      - name: grand_total
        expr: "total_price + tax"
      - name: year
        expr: "year(to_date(order_date))"
```

---

## YAML Contract: Output Targets

```yaml
# Step 3: Select final columns
  - type: select
    from: orders_with_totals
    as: final_orders
    columns: [order_id, customer_id, product, quantity, 
              unit_price, total_price, tax, grand_total, 
              order_date, year]

# Output Targets
targets:
  - from: final_orders
    format: parquet
    mode: overwrite
    path: s3://my-bucket/curated/orders/
    partitionBy: [year]
    options:
      compression: snappy
```

---

## The Generic Job Runner: `job_runner.py`

### Core Logic (Simplified)

```python
def main():
    args = parse_args()  # Get config_path from Glue arguments
    spark = SparkSession.builder.appName('yaml-runner').getOrCreate()
    
    cfg = load_yaml(args['config_path'])  # Load YAML from S3
    views = {}
    
    # Read sources
    for src in cfg.get('sources', []):
        name = src['name']
        views[name] = read_action(spark, src)
    
    # Execute transforms
    for t in cfg.get('transforms', []):
        t_type = t['type']
        if t_type == 'select':
            df = select_action(views[t['from']], t)
        elif t_type == 'with_columns':
            df = with_columns_action(views[t['from']], t)
        # ... more transform types
        views[t['as']] = df
    
    # Write targets
    for tgt in cfg.get('targets', []):
        write_action(views[tgt['from']], tgt)
```

---

## Supported Transform Actions

### Built-in Operations

| Action | Description | Example |
|--------|-------------|---------|
| **select** | Choose specific columns | `columns: [id, name, amount]` |
| **filter** | Filter rows by condition | `expr: "amount > 100"` |
| **with_columns** | Add calculated columns | `expr: "amount * 0.2"` |
| **join** | Join two datasets | `on: [customer_id], how: left` |

### Extensible Design
- Add new action handlers as functions
- No changes to core runner logic
- Maintain backward compatibility

---

## NiceGUI UI: Single-Service Architecture

### Key Features
1. **File Upload** — Upload YAML configs and data files to S3
2. **Job Submission** — Trigger Glue jobs with config selection
3. **Status Monitoring** — Real-time job status checks
4. **S3 Browser** — View output files and logs

### Technology Stack
- **NiceGUI** — Python UI framework with built-in FastAPI
- **uvicorn** — ASGI server for production
- **boto3** — AWS SDK for Python
- **Docker** — Containerization for AWS App Runner

---

## Demo: Job Submission Workflow

### Step-by-Step Process

1. **Upload Configuration**
   - Upload `orders_processing.yaml` to S3 via UI
   - File stored at `s3://bucket/configs/orders_processing.yaml`

2. **Submit Job**
   - Enter job name: `orders-yaml-runner`
   - Select config: `orders_processing.yaml`
   - Click "Submit Job"

3. **Monitor Execution**
   - UI shows Job Run ID
   - Check status: RUNNING → SUCCEEDED
   - View CloudWatch logs for details

4. **Verify Output**
   - Browse S3: `s3://bucket/curated/orders/`
   - Partitioned Parquet files ready for dbt

---

## Integration with dbt

### ELT Workflow

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Extract   │      │    Load     │      │  Transform  │
│  (Sources)  │  →   │ (Glue Job)  │  →   │    (dbt)    │
│             │      │             │      │             │
│ S3 Raw CSV  │      │ S3 Parquet  │      │ Data Marts  │
└─────────────┘      └─────────────┘      └─────────────┘
```

### dbt Source Validation
```yaml
# dbt sources.yml
sources:
  - name: curated
    database: analytics
    schema: curated
    tables:
      - name: orders
        description: Processed orders from Glue
        columns:
          - name: order_id
            tests:
              - unique
              - not_null
```

---

## Benefits of This Approach

<div class="columns">

### ✅ Advantages
- **Zero code for new pipelines** — just YAML
- **Serverless & scalable** — Glue auto-scales
- **Cost-effective** — pay per job minute
- **AWS-native** — seamless S3, Athena, Redshift integration
- **Self-service** — analysts can create jobs via UI
- **Version controlled** — Git tracks YAML changes
- **Fast iteration** — deploy new pipeline in minutes

### ⚠️ Trade-offs
- **AWS lock-in** — tied to Glue ecosystem
- **Learning curve** — PySpark and Glue concepts
- **Limited connectors** — manual integration for non-S3 sources
- **Glue constraints** — job timeout limits, worker configs

</div>

---

## Cost Comparison: Informatica vs. AWS Glue

### Informatica PowerCenter
- **Licensing**: $100K+ per year (enterprise)
- **Infrastructure**: Dedicated servers or cloud VMs
- **Maintenance**: Full-time admin required

### AWS Glue (This Approach)
- **Compute**: $0.44/DPU-hour (Data Processing Unit)
- **Storage**: S3 standard ~$0.023/GB/month
- **Example**: 100 jobs/day × 5 min avg = **~$330/month**

### 💰 Potential Savings: **90%+ reduction in ETL costs**

---

## Real-World Example: Order Processing

### Input Data
```csv
order_id,customer_id,product,quantity,unit_price,status,order_date
1001,C001,Widget,5,10.00,completed,2024-01-15
1002,C002,Gadget,2,25.00,pending,2024-01-15
1003,C001,Widget,3,10.00,completed,2024-01-16
```

### YAML Config
- Filter: `status = 'completed'`
- Calculate: `total_price`, `tax`, `grand_total`
- Partition by: `year`

### Output
```
s3://bucket/curated/orders/year=2024/
  ├── part-00000.snappy.parquet
  └── part-00001.snappy.parquet
```

---

## Deployment Architecture

### Local Development
```bash
# Run NiceGUI app locally
python demos/nicegui_app/main.py
# Access at http://localhost:8084
```

### Production Deployment
```bash
# Build Docker image
docker build -t glue-etl-ui .

# Push to ECR
aws ecr get-login-password | docker login --username AWS --password-stdin
docker tag glue-etl-ui:latest <account>.dkr.ecr.us-east-1.amazonaws.com/glue-etl-ui
docker push <account>.dkr.ecr.us-east-1.amazonaws.com/glue-etl-ui

# Deploy to App Runner (via Console or CLI)
aws apprunner create-service --service-name glue-etl-platform ...
```

---

## Security & IAM Configuration

### Glue Job Role (`GlueYAMLRunnerRole`)
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": "arn:aws:s3:::my-bucket/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "*"
    }
  ]
}
```

---

## Monitoring & Observability

### CloudWatch Integration
- **Logs**: All PySpark output captured
- **Metrics**: Job duration, DPU usage, success/failure rates
- **Alarms**: Trigger SNS notifications on failures

### Example CloudWatch Insights Query
```sql
fields @timestamp, @message
| filter @message like /ERROR/
| sort @timestamp desc
| limit 20
```

### Job Status Tracking
- UI polls Glue API: `get_job_run(JobName, RunId)`
- States: `SUBMITTED` → `RUNNING` → `SUCCEEDED`/`FAILED`

---

## Extending the Platform

### Future Enhancements

1. **More Transform Actions**
   - Aggregations (`groupBy`, `sum`, `avg`)
   - Window functions
   - Custom UDFs

2. **Orchestration**
   - AWS Step Functions for multi-job workflows
   - EventBridge for scheduling

3. **Data Quality**
   - Great Expectations integration
   - Schema validation pre-flight checks

4. **Metadata Management**
   - AWS Glue Data Catalog integration
   - Lineage tracking with OpenLineage

---

## Comparison with Other Approaches

| Criteria | Glue Config | Meltano Clone | PyAirbyte |
|----------|-------------|---------------|-----------|
| **Setup Complexity** | Medium | High | Low |
| **Maintenance** | Low | High | Medium |
| **Flexibility** | Medium | High | High |
| **Connector Library** | Limited | Custom | 350+ |
| **Cost** | $$ | $ | $ |
| **AWS Lock-in** | Yes | No | No |
| **Learning Curve** | PySpark | Framework Dev | Python SDK |
| **Best For** | AWS-native shops | Custom needs | Connector variety |

---

## When to Choose This Approach

### ✅ Ideal Scenarios
- Already using AWS ecosystem (S3, Redshift, Athena)
- Need serverless, auto-scaling ETL
- Want configuration-driven pipelines
- Team comfortable with PySpark
- Budget-conscious (vs. Informatica)

### ❌ Not Ideal If
- Multi-cloud strategy required
- Need 100+ pre-built connectors
- Prefer UI-based workflow design (like Informatica)
- Real-time streaming is primary use case

---

## Migration Strategy from Informatica

### Phase 1: Pilot (1-2 months)
- Select 3-5 simple Informatica workflows
- Convert to YAML configs
- Deploy and validate in dev environment

### Phase 2: Incremental Migration (3-6 months)
- Migrate 20-30% of workflows
- Run parallel (Informatica + Glue)
- Build confidence with stakeholders

### Phase 3: Full Cutover (6-12 months)
- Migrate remaining workflows
- Decommission Informatica
- Optimize Glue jobs for cost

---

## Success Metrics

### KPIs to Track

| Metric | Target |
|--------|--------|
| **Pipeline Creation Time** | < 30 min (vs. 2-3 days in Informatica) |
| **Cost Reduction** | 80-90% vs. Informatica licensing |
| **Job Success Rate** | > 95% |
| **Mean Time to Recovery** | < 15 min (auto-retry) |
| **Data Freshness** | < 1 hour lag |

### Business Impact
- Faster time-to-insight for analytics
- Reduced data engineering bottleneck
- Self-service for data analysts

---

## Code Walkthrough: Key Files

### 1. `job_runner.py` (123 lines)
- Generic PySpark engine
- Action handlers: `read`, `select`, `filter`, `with_columns`, `join`, `write`
- YAML parser with S3 support

### 2. `orders_processing.yaml` (63 lines)
- Real-world example configuration
- Metadata, sources, transforms, targets

### 3. `main.py` (311 lines)
- NiceGUI UI with FastAPI routes
- File upload, job submission, status check
- S3 browser functionality

**All code available in the project repository**

---

## Live Demo: End-to-End Workflow

### Demo Steps
1. **Show UI** — Navigate to http://localhost:8084
2. **Upload Config** — Upload `orders_processing.yaml`
3. **Upload Data** — Upload `sample_orders.csv` to S3
4. **Submit Job** — Trigger Glue job via UI
5. **Monitor Status** — Watch job progress (RUNNING → SUCCEEDED)
6. **View Logs** — Check CloudWatch for execution details
7. **Browse Output** — View Parquet files in S3
8. **Query with Athena** — Run SQL on processed data

**[Switch to live demo environment]**

---

## Q&A: Common Questions

### Q: How do we handle schema evolution?
**A:** Use `inferSchema: "true"` or define explicit schemas in YAML. Glue Data Catalog can track schema versions.

### Q: What about error handling and retries?
**A:** Glue has built-in retry (default 3 attempts). Add custom error handling in `job_runner.py` for specific cases.

### Q: Can we run this on-premises?
**A:** Not directly (Glue is AWS-only). Could adapt for Databricks or open-source Spark with modifications.

### Q: How do we test YAML configs before production?
**A:** Run in dev Glue environment with sample data. Add YAML schema validation in UI.

---

## Next Steps & Recommendations

### Immediate Actions
1. **Proof of Concept** — Deploy this solution in dev AWS account
2. **Pilot Workflow** — Convert one Informatica workflow to YAML
3. **Stakeholder Demo** — Show UI and cost projections to leadership

### Long-Term Roadmap
1. **Expand Transform Library** — Add aggregations, pivots, etc.
2. **Integrate with dbt Cloud** — Trigger dbt runs post-Glue
3. **Build CI/CD Pipeline** — Automate YAML validation and deployment
4. **Add Data Quality Checks** — Pre/post-job validation

---

## Resources & Documentation

### Project Repository
- **GitHub**: `github.com/your-org/glue_disney_etl_platform`
- **Code**: `F:\glue_disney_inspired_etl_platform\`
  - `code_block/job_runner.py`
  - `code_block/orders_processing.yaml`
  - `demos/nicegui_app/main.py`

### AWS Documentation
- [AWS Glue Developer Guide](https://docs.aws.amazon.com/glue/)
- [PySpark API Reference](https://spark.apache.org/docs/latest/api/python/)
- [AWS App Runner](https://docs.aws.amazon.com/apprunner/)

### Contact
- **Email**: ericmajuk.aggrey@sanofi.com
- **Slack**: #data-engineering

---

## Summary: Why Choose Approach 1?

### The Value Proposition

**Configuration-driven ETL on AWS Glue offers:**
- ✅ **90% cost reduction** vs. Informatica
- ✅ **10x faster** pipeline creation (YAML vs. custom code)
- ✅ **Serverless** — no infrastructure to manage
- ✅ **Scalable** — handles millions of rows automatically
- ✅ **Integrated** — seamless dbt handoff for transformations
- ✅ **Self-service** — empower analysts with UI

**This is a production-ready, battle-tested approach for AWS-native data platforms.**

---

# Thank You!

## Questions & Discussion

**Let's discuss:**
- How does this fit your current architecture?
- What Informatica workflows would you migrate first?
- Any concerns about AWS lock-in?

**Contact me for:**
- Code walkthrough sessions
- POC setup assistance
- Architecture review

---

## Appendix: Additional Slides

### Backup slides for deep-dive questions

---

## Appendix A: Full `job_runner.py` Code

```python
#!/usr/bin/env python3
"""
Generic YAML-driven PySpark job runner for AWS Glue.
"""
import sys
from typing import Dict, Any
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
import yaml

def parse_args():
    args = getResolvedOptions(sys.argv, ['config_path'])
    return args

def load_yaml(path: str) -> Dict[str, Any]:
    if path.startswith('s3://'):
        import boto3
        s3 = boto3.client('s3')
        bucket_key = path.replace('s3://', '', 1)
        bucket, key = bucket_key.split('/', 1)
        obj = s3.get_object(Bucket=bucket, Key=key)
        return yaml.safe_load(obj['Body'].read())
    else:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
```

---

## Appendix B: IAM Trust Policy

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "glue.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

### Attach Policies
- `AWSGlueServiceRole` (managed policy)
- Custom S3 access policy (see previous slide)

---

## Appendix C: Sample Data

### `sample_orders.csv`
```csv
order_id,customer_id,product,quantity,unit_price,status,order_date
1001,C001,Widget,5,10.00,completed,2024-01-15
1002,C002,Gadget,2,25.00,pending,2024-01-15
1003,C001,Widget,3,10.00,completed,2024-01-16
1004,C003,Doohickey,1,50.00,completed,2024-01-16
1005,C002,Widget,10,10.00,cancelled,2024-01-17
```

### Expected Output (Parquet)
- Filtered: 3 completed orders
- Calculated: `total_price`, `tax`, `grand_total`
- Partitioned by: `year=2024`

---

## Appendix D: Troubleshooting Guide

### Common Issues

| Issue | Solution |
|-------|----------|
| **Job fails with "Access Denied"** | Check IAM role has S3 permissions |
| **YAML parse error** | Validate YAML syntax (use yamllint) |
| **Glue job timeout** | Increase timeout in job settings or optimize query |
| **Out of memory** | Increase DPU count (default 2 → 10) |
| **Schema mismatch** | Use explicit schema or `mergeSchema: true` |

### Debugging Tips
- Enable Glue job bookmarks for incremental loads
- Use `df.explain()` to see query plan
- Check CloudWatch logs for PySpark errors

