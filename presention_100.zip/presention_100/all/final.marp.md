---
marp: true
size: 16:9
paginate: true
theme: default
class: lead
style: |
  section {
    background-color: #ffffff;
  }
  h1 {
    color: #2C3E50;
    font-weight: bold;
  }
  h2 {
    color: #E74C3C;
  }
  h3 {
    color: #3498DB;
  }
  code {
    background-color: #f4f4f4;
    padding: 2px 6px;
  }
  .columns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }
  .compact {
    font-size: 0.85em;
  }
---

# Alternatives for Ingestion with dbt
## Moving Legacy Pipelines from Informatica to Modern Data Stack

**Eric Aggrey**  
Data Engineering Manager  
📧 ericmajuk.aggrey@sanofi.com

---

## Executive Summary

### The Challenge
- **Legacy Tool**: Informatica 
- **Current Stack**: dbt + Airflow for transformations and orchestration
- **Goal**: Find cost-effective, scalable alternatives for data ingestion

### Three Approaches Evaluated

| **Approach** | **Best For** | **Cost** | **Complexity** |
|-------------|-------------|---------|---------------|
| **1. AWS Glue (Config-Based)** | Enterprise scale, serverless | Medium | Low |
| **2. Singer Pydantic Framework** | Custom | Low | Medium |
| **3. PyAirbyte/Custom Python** | Flexibility, control | Very Low | High |

---

## Approach 1: AWS Glue Configuration-Based ETL
### Serverless, YAML-Driven Data Engineering

**Core Concept**: Single generic PySpark runner + YAML configuration files

#### Key Components
- **YAML Contracts** — Define sources, transforms, and targets
- **Generic Job Runner** — PySpark engine (`job_runner.py`) that executes configs
- **NiceGUI UI** — Web interface for job submission and monitoring
- **AWS Glue** — Serverless Spark runtime (auto-scaling)
- **dbt Integration** — Seamless handoff to dbt for transformations

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│              NiceGUI Monolith (App Runner)                  │
│  ┌──────────────────┐          ┌──────────────────┐        │
│  │   UI Pages       │          │  FastAPI Routes  │        │
│  │  - Job Submit    │ ◄──────► │  /api/submit_job │        │
│  │  - Monitor       │          │  /api/job_status │        │
│  │  - S3 Browser    │          │  /api/health     │        │
│  └──────────────────┘          └──────────────────┘        │
└─────────────────────────────────────────────────────────────┘
                │                           │
                └───────────┬───────────────┘
                            ▼
                ┌───────────────────────┐
                │   AWS Glue Job        │
                │   job_runner.py       │
                │   - Reads YAML config │
                │   - Executes pipeline │
                └───────────────────────┘
                            │
                ┌───────────┼───────────┐
                ▼           ▼           ▼
         ┌──────────┐ ┌─────────┐ ┌────────────┐
         │   S3     │ │CloudWatch│ │    dbt     │
         │  Config  │ │  Logs    │ │ Transform  │
         │  & Data  │ │          │ │            │
         └──────────┘ └─────────┘ └────────────┘
```

---

## The YAML Contract: Configuration Over Code

### Example: Order Processing Pipeline

```yaml
# Job Metadata
job_name: orders_processing
description: Process e-commerce orders with tax calculation
owner: data-engineering@company.com
version: 1.0

# Data Sources
sources:
  - name: raw_orders
    format: csv
    path: s3://my-bucket/raw/orders/
    options:
      header: "true"
      inferSchema: "true"
```

---

## YAML Contract: Transformations

```yaml
# Transformation Pipeline
transforms:
  # Step 1: Filter completed orders
  - type: filter
    from: raw_orders
    as: completed_orders
    expr: "status = 'completed'"

```
  ---

```yaml

## YAML Contract: Transformations  continued 

  # Step 2: Calculate totals
  - type: with_columns
    from: completed_orders
    as: orders_with_totals
    columns:
      - name: total_price
        expr: "quantity * unit_price"
      - name: tax
        expr: "total_price * 0.2"
      - name: grand_total
        expr: "total_price + tax"
      - name: year
        expr: "year(to_date(order_date))"
```

---

## YAML Contract: Output Targets

```yaml
# Step 3: Select final columns
  - type: select
    from: orders_with_totals
    as: final_orders
    columns: [order_id, customer_id, product, quantity, 
              unit_price, total_price, tax, grand_total, 
              order_date, year]

# Output Targets
targets:
  - from: final_orders
    format: parquet
    mode: overwrite
    path: s3://my-bucket/curated/orders/
    partitionBy: [year]
    options:
      compression: snappy
```

---

## The Generic Job Runner: `job_runner.py`

### Core Logic (Simplified)

```python
def main():
    args = parse_args()  # Get config_path from Glue arguments
    spark = SparkSession.builder.appName('yaml-runner').getOrCreate()
    
    cfg = load_yaml(args['config_path'])  # Load YAML from S3
    views = {}
    
    # Read sources
    for src in cfg.get('sources', []):
        name = src['name']
        views[name] = read_action(spark, src)
```
---

```python
    
    # Execute transforms
    for t in cfg.get('transforms', []):
        t_type = t['type']
        if t_type == 'select':
            df = select_action(views[t['from']], t)
        elif t_type == 'with_columns':
            df = with_columns_action(views[t['from']], t)
        # ... more transform types
        views[t['as']] = df
    
    # Write targets
    for tgt in cfg.get('targets', []):
        write_action(views[tgt['from']], tgt)
```

---

## Supported Transform Actions

### Built-in Operations

| Action | Description | Example |
|--------|-------------|---------|
| **select** | Choose specific columns | `columns: [id, name, amount]` |
| **filter** | Filter rows by condition | `expr: "amount > 100"` |
| **with_columns** | Add calculated columns | `expr: "amount * 0.2"` |
| **join** | Join two datasets | `on: [customer_id], how: left` |

### Extensible Design
- Add new action handlers as functions
- No changes to core runner logic
- Maintain backward compatibility

---

## NiceGUI UI: Single-Service Architecture

### Key Features
1. **File Upload** — Upload YAML configs and data files to S3
2. **Job Submission** — Trigger Glue jobs with config selection
3. **Status Monitoring** — Real-time job status checks
4. **S3 Browser** — View output files and logs

### Technology Stack
- **NiceGUI** — Python UI framework with built-in FastAPI
- **uvicorn** — ASGI server for production
- **boto3** — AWS SDK for Python
- **Docker** — Containerization for AWS App Runner

---

## Demo: Job Submission Workflow

### Step-by-Step Process

1. **Upload Configuration**
   - Upload `orders_processing.yaml` to S3 via UI
   - File stored at `s3://bucket/configs/orders_processing.yaml`

2. **Submit Job**
   - Enter job name: `orders-yaml-runner`
   - Select config: `orders_processing.yaml`
   - Click "Submit Job"
---

3. **Monitor Execution**
   - UI shows Job Run ID
   - Check status: RUNNING → SUCCEEDED
   - View CloudWatch logs for details

4. **Verify Output**
   - Browse S3: `s3://bucket/curated/orders/`
   - Partitioned Parquet files ready for dbt

---

## Integration with dbt

### ELT Workflow

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Extract   │      │    Load     │      │  Transform  │
│  (Sources)  │  →   │ (Glue Job)  │  →   │    (dbt)    │
│             │      │             │      │             │
│ S3 Raw CSV  │      │ S3 Parquet  │      │ Data Marts  │
└─────────────┘      └─────────────┘      └─────────────┘
```
---
### dbt Source Validation
```yaml
# dbt sources.yml
sources:
  - name: curated
    database: analytics
    schema: curated
    tables:
      - name: orders
        description: Processed orders from Glue
        columns:
          - name: order_id
            tests:
              - unique
              - not_null
```
---


## Approach 1 (cont'd): Implementation Details

### Sample YAML Configuration
```yaml
job_name: orders_ingestion
source:
  type: jdbc
  connection: postgresql://prod-db.sanofi.com/sales
  query: "SELECT * FROM orders WHERE updated_at >= '{{start_date}}'"
  
transforms:
  - type: deduplicate
    key_columns: [order_id]
  - type: filter
    condition: "status != 'cancelled'"
    
target:
  type: s3
  bucket: sanofi-data-lake
  path: raw/orders/
  format: parquet
```
---

## Benefits of This Approach

<div class="columns">

### ✅ Advantages
- **Zero code for new pipelines** — just YAML
- **Serverless & scalable** — Glue auto-scales
- **Cost-effective** — pay per job minute
- **AWS-native** — seamless S3, Athena, Redshift integration
- **Self-service** — analysts can create jobs via UI
- **Version controlled** — Git tracks YAML changes
- **Fast iteration** — deploy new pipeline in minutes



</div>

---


<div class="columns">


### ⚠️ Trade-offs
- **AWS lock-in** — tied to Glue ecosystem
- **Learning curve** — PySpark and Glue concepts
- **Limited connectors** — manual integration for non-S3 sources
- **Glue constraints** — job timeout limits, worker configs

</div>




---

## Cost Comparison: Informatica vs. AWS Glue

### Informatica PowerCenter
- **Licensing**: $$$ per year (enterprise)
- **Infrastructure**: Dedicated servers or cloud VMs
- **Maintenance**: Full-time admin required

### AWS Glue (This Approach)
- **Compute**: $0.44/DPU-hour (Data Processing Unit)
- **Storage**: S3 standard ~$0.023/GB/month


### 💰 Potential Savings: **90%+ reduction in ETL costs**

#### When to Use
✅ Large-scale data processing (100GB+)  
✅ Need serverless auto-scaling  
✅ Familiar with AWS ecosystem  
✅ Want minimal code maintenance  



### Key Metrics
- **Cost Reduction**: 75% vs Informatica
- **Setup Time**: 2-3 days
- **Developer Productivity**: +60% (config vs code)

---

## Approach 2: Singer/Meltano Framework
### Open-Source, Type-Safe Data Integration

**Core Concept**: Singer taps/targets + Pydantic validation + dbt auto-generation

#### Key Components
- **Singer Protocol** — JSON-based data exchange standard
- **Meltano** — Open-source ELT orchestration
- **Pydantic** — Type-safe configuration validation
- **350+ Taps** — Pre-built connectors (Snowflake, PostgreSQL, APIs)
- **dbt Auto-Generation** — Creates sources + staging models automatically

#### Architecture
```
Singer Tap → Catalog Discovery → JSON Streams → Target → dbt Sources (auto-generated)
```

#### When to Use
✅ Need many different source connectors  
✅ Want open-source with community support  
✅ Type-safe configurations important  
✅ Auto-generate dbt boilerplate  

---

## Approach 2 (cont'd): Implementation Details

### CLI Workflow
```powershell
# 1. Configure source (interactive)
singer-framework init --source-type snowflake

# 2. Discover schema (auto-detect tables)
singer-framework discover --config snowflake.yml --output catalog.json

# 3. Generate dbt sources + models (one command)
singer-framework generate-sources catalog.json snowflake.yml \
  --dbt-project ./dbt --generate-models
```

### Auto-Generated dbt Model
```sql
{{ config(materialized='incremental', unique_key='order_id') }}

with source as (
    select * from {{ source('snowflake', 'orders') }}
),
renamed as (
    select
        order_id,
        customer_id,
        amount,
        current_timestamp() as _loaded_at
    from source
)
select * from renamed
{% if is_incremental() %}
    where _loaded_at > (select max(_loaded_at) from {{ this }})
{% endif %}
```

### Key Metrics
- **Cost Reduction**: 90% vs Informatica
- **Setup Time**: 1 day
- **dbt Boilerplate**: 80% reduction

---

## Approach 3: PyAirbyte & Custom Python
### Flexibility and Full Control

**Core Concept**: Choose between 350+ pre-built connectors or custom Python code

#### Two Sub-Approaches

**3A. PyAirbyte SDK**
- Leverage Airbyte connectors in Python
- Incremental sync built-in
- Community-maintained

**3B. Custom Python Extractors**
- Direct API integration
- Full control over logic
- Minimal dependencies

#### Architecture
```
Python Script → API Requests → DuckDB (local) → Parquet/CSV → S3 → dbt
```

#### When to Use
✅ Need maximum flexibility  
✅ Custom authentication/logic required  
✅ Local development-first approach  
✅ Small to medium data volumes  

---

## Approach 3 (cont'd): Implementation Comparison

### PyAirbyte Approach
```python
import airbyte as ab

# Use pre-built GitHub connector
source = ab.get_source("source-github", config={
    "repository": "sanofi/data-platform",
    "personal_access_token": os.getenv("GITHUB_TOKEN")
})

# Read and write to DuckDB
source.check()
result = source.read()
result.write_to_database("duckdb://./local.db", "raw_data")
```

### Custom Python Approach
```python
import requests
import duckdb

# Full control with standard libraries
def extract_github_data(repo, token):
    response = requests.get(
        f"https://api.github.com/repos/{repo}/issues",
        headers={"Authorization": f"token {token}"}
    )
    data = response.json()
    
    conn = duckdb.connect("local.db")
    conn.execute("CREATE SCHEMA IF NOT EXISTS raw_data")
    conn.execute("INSERT INTO raw_data.issues SELECT * FROM data")
```

### Key Metrics (Custom Python)
- **Cost Reduction**: 95% vs Informatica
- **Setup Time**: 2-4 hours
- **Developer Control**: 100%

---

## Side-by-Side Comparison

| **Criteria** | **Approach 1: Glue** | **Approach 2: Singer/Meltano** | **Approach 3: PyAirbyte/Python** |
|-------------|---------------------|-------------------------------|--------------------------------|
| **Cost** | Medium ($500-2K/mo) | Low ($0-500/mo) | Very Low ($0-100/mo) |
| **Scalability** | Excellent (1TB+) | Good (100GB-1TB) | Moderate (<100GB) |
| **Setup Time** | 2-3 days | 1 day | 2-4 hours |
| **Maintenance** | Low | Medium | High |
| **Flexibility** | Medium | High | Very High |
| **Learning Curve** | Low (YAML) | Medium (Singer protocol) | High (Python dev) |
| **Community** | AWS only | Large open-source | Massive (Python) |
| **dbt Integration** | Manual | Auto-generated | Manual |
| **Best For** | Enterprise scale | Standard connectors | Custom logic |

---

## Technology Stack Integration

### How Each Approach Fits with dbt + Airflow

#### Approach 1: AWS Glue
```python
# Airflow DAG
glue_job = GlueJobOperator(
    task_id='extract_orders',
    job_name='job_runner',
    script_args={'--config': 's3://configs/orders.yml'}
)
dbt_run = BashOperator(
    task_id='transform',
    bash_command='dbt run --models staging.orders'
)
glue_job >> dbt_run
```

#### Approach 2: Singer/Meltano
```python
# Airflow DAG
singer_sync = BashOperator(
    task_id='extract_orders',
    bash_command='singer-framework generate-sources catalog.json config.yml --dbt-project ./dbt --generate-models'
)
dbt_run = BashOperator(
    task_id='transform',
    bash_command='dbt run --models staging.*'
)
singer_sync >> dbt_run
```

#### Approach 3: PyAirbyte/Python
```python
# Airflow DAG
extract = PythonOperator(
    task_id='extract_orders',
    python_callable=extract_github_data
)
dbt_run = BashOperator(
    task_id='transform',
    bash_command='dbt run --models staging.*'
)
extract >> dbt_run
```




---

# Thank You!

## Let's Transform Our Data Engineering Together

**Ready to move beyond Informatica and embrace modern data stack alternatives.**

📧 ericmajuk.aggrey@sanofi.com  
💼 Data Engineering Manager, Sanofi

**Next Steps**: Schedule follow-up meeting to select pilot approach and form evaluation team.

---
