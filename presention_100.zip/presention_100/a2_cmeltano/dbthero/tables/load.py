import sys
import os

# Add the parent directory to sys.path to allow importing as a package
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

# Import from the tables package
from tables import metadata, engine
from tables.data_load_helpers import LoadData

if __name__ == '__main__':
    try:
        # Create tables
        #metadata.drop_all(engine)
        metadata.create_all(engine)
        print("Tables created successfully")
        
        # Create a single instance of LoadData for all operations
        load_data = LoadData()
        
        try:
            # Load data in a single transaction
            load_data.load_in_order(
                {
                    'states': 50,
                    'product_categories': 10,
                    'customers': 100,
                    'suppliers': 15,
                    'employees': 20,
                    'products': 200,
                    'orders': 50,
                    'order_items': 150,
                    'inventory_transactions': 100,
                    'payments': 50
                }
            )
            print("Data loaded successfully")
        except Exception as e:
            print(f"Error loading data: {e}")
        finally:
            # Make sure to close the connection properly
            load_data.close_connection()
    except Exception as e:
        print(f"Error setting up database: {e}")
