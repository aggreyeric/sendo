# OLTP Tables Definitions

## customers
```
customers (
    customer_id integer,
    first_name varchar(50),
    last_name varchar(50),
    email varchar(100),
    phone varchar(20),
    address varchar(200),
    city varchar(50),
    state_id integer,
    zip_code varchar(10),
    created_at timestamp,
    updated_at timestamp
)
```

## products
```
products (
    product_id integer,
    name varchar(100),
    description text,
    category_id integer,
    price float,
    cost float,
    sku varchar(50),
    inventory_quantity integer,
    created_at timestamp,
    updated_at timestamp
)
```

## product_categories
```
product_categories (
    category_id integer,
    name varchar(50),
    description varchar(200)
)
```

## orders
```
orders (
    order_id integer,
    customer_id integer,
    order_date timestamp,
    status varchar(20),
    shipping_address varchar(200),
    shipping_city varchar(50),
    shipping_state_id integer,
    shipping_zip varchar(10),
    payment_method varchar(50),
    order_total float,
    tax_amount float,
    shipping_amount float
)
```

## order_items
```
order_items (
    order_item_id integer,
    order_id integer,
    product_id integer,
    quantity integer,
    unit_price float,
    line_total float
)
```

## employees
```
employees (
    employee_id integer,
    first_name varchar(50),
    last_name varchar(50),
    email varchar(100),
    hire_date date,
    position varchar(50),
    department varchar(50),
    salary float,
    manager_id integer
)
```

## states
```
states (
    id integer,
    name varchar(255)
)
```

## suppliers
```
suppliers (
    supplier_id integer,
    name varchar(100),
    contact_name varchar(100),
    email varchar(100),
    phone varchar(20),
    address varchar(200),
    city varchar(50),
    state_id integer,
    zip_code varchar(10)
)
```

## inventory_transactions
```
inventory_transactions (
    transaction_id integer,
    product_id integer,
    transaction_type varchar(20),
    quantity integer,
    transaction_date timestamp,
    reference_id integer,
    notes varchar(200)
)
```

## payments
```
payments (
    payment_id integer,
    order_id integer,
    payment_date timestamp,
    amount float,
    payment_method varchar(50),
    transaction_id varchar(100),
    status varchar(20)
)
```
