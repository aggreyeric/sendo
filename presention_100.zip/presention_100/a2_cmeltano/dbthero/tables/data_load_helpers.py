from .tables import customers, products, product_categories, orders, order_items, employees, suppliers, inventory_transactions, payments, States, engine
from sqlalchemy import insert, select, func
import faker
from datetime import datetime, timedelta
import random

fake = faker.Faker()


class LoadData:
    def __init__(self, increment=None):
        """
        Initialize the LoadData class
        
        Args:
            increment: Optional starting increment for IDs. If None, will determine the next available ID
                      from the database for each table.
        """
        self.increment = increment
        self.engine = engine
        self.connection = engine.connect()
        # Start a transaction
        self.transaction = self.connection.begin()
        
        self._customer_increment = None
        self._product_increment = None
        self._category_increment = None
        self._order_increment = None
        self._order_item_increment = None
        self._employee_increment = None
        self._supplier_increment = None
        self._transaction_increment = None
        self._payment_increment = None
        
        # Cache for relationship data
        self._customer_ids = None
        self._product_ids = None
        self._category_ids = None
        self._order_ids = None
        self._employee_ids = None
        self._supplier_ids = None
        self._state_ids = None
    
    def _get_next_id(self, table, id_column):
        """Get the next available ID for a table"""
        if self.increment is not None:
            return self.increment
        
        # Query the max ID and add 1
        query = select(func.coalesce(func.max(id_column), 0))
        result = self.connection.execute(query).scalar()
        return result + 1
    
    def _get_customer_increment(self):
        """Get the next customer ID"""
        if self._customer_increment is None:
            self._customer_increment = self._get_next_id(customers, customers.c.customer_id)
        return self._customer_increment
    
    def _get_product_increment(self):
        """Get the next product ID"""
        if self._product_increment is None:
            self._product_increment = self._get_next_id(products, products.c.product_id)
        return self._product_increment
    
    def _get_category_increment(self):
        """Get the next category ID"""
        if self._category_increment is None:
            self._category_increment = self._get_next_id(product_categories, product_categories.c.category_id)
        return self._category_increment
    
    def _get_order_increment(self):
        """Get the next order ID"""
        if self._order_increment is None:
            self._order_increment = self._get_next_id(orders, orders.c.order_id)
        return self._order_increment
    
    def _get_order_item_increment(self):
        """Get the next order item ID"""
        if self._order_item_increment is None:
            self._order_item_increment = self._get_next_id(order_items, order_items.c.order_item_id)
        return self._order_item_increment
    
    def _get_employee_increment(self):
        """Get the next employee ID"""
        if self._employee_increment is None:
            self._employee_increment = self._get_next_id(employees, employees.c.employee_id)
        return self._employee_increment
    
    def _get_supplier_increment(self):
        """Get the next supplier ID"""
        if self._supplier_increment is None:
            self._supplier_increment = self._get_next_id(suppliers, suppliers.c.supplier_id)
        return self._supplier_increment
    
    def _get_transaction_increment(self):
        """Get the next transaction ID"""
        if self._transaction_increment is None:
            self._transaction_increment = self._get_next_id(inventory_transactions, inventory_transactions.c.transaction_id)
        return self._transaction_increment
    
    def _get_payment_increment(self):
        """Get the next payment ID"""
        if self._payment_increment is None:
            self._payment_increment = self._get_next_id(payments, payments.c.payment_id)
        return self._payment_increment
    
    def _get_customer_ids(self, refresh=False):
        """Get all customer IDs from the database"""
        if self._customer_ids is None or refresh:
            query = select(customers.c.customer_id)
            self._customer_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._customer_ids if self._customer_ids else [1]
    
    def _get_product_ids(self, refresh=False):
        """Get all product IDs from the database"""
        if self._product_ids is None or refresh:
            query = select(products.c.product_id)
            self._product_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._product_ids if self._product_ids else [1]
    
    def _get_category_ids(self, refresh=False):
        """Get all category IDs from the database"""
        if self._category_ids is None or refresh:
            query = select(product_categories.c.category_id)
            self._category_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._category_ids if self._category_ids else [1]
    
    def _get_order_ids(self, refresh=False):
        """Get all order IDs from the database"""
        if self._order_ids is None or refresh:
            query = select(orders.c.order_id)
            self._order_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._order_ids if self._order_ids else [1]
    
    def _get_employee_ids(self, refresh=False):
        """Get all employee IDs from the database"""
        if self._employee_ids is None or refresh:
            query = select(employees.c.employee_id)
            self._employee_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._employee_ids if self._employee_ids else [1]
    
    def _get_supplier_ids(self, refresh=False):
        """Get all supplier IDs from the database"""
        if self._supplier_ids is None or refresh:
            query = select(suppliers.c.supplier_id)
            self._supplier_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._supplier_ids if self._supplier_ids else [1]
    
    def _get_state_ids(self, refresh=False):
        """Get all state IDs from the database"""
        if self._state_ids is None or refresh:
            query = select(States.c.id)
            self._state_ids = [row[0] for row in self.connection.execute(query).fetchall()]
        return self._state_ids if self._state_ids else list(range(1, 51))  # Default to 1-50 if no states
    
    def load_in_order(self, counts):
        """
        Load data in the correct order to maintain referential integrity
        
        Args:
            counts: Dictionary with table names as keys and counts as values
                   Example: {'states': 50, 'customers': 100, 'products': 200}
        """
        try:
            # First, load reference tables with no dependencies
            if 'states' in counts:
                self.insert_states()
            
            if 'product_categories' in counts:
                self.insert_product_categories(counts['product_categories'])
                # Refresh cache after insertion
                self._get_category_ids(refresh=True)
            
            # Then load tables with simple dependencies
            if 'customers' in counts:
                self.insert_customers(counts['customers'])
                # Refresh cache after insertion
                self._get_customer_ids(refresh=True)
            
            if 'suppliers' in counts:
                self.insert_suppliers(counts['suppliers'])
                # Refresh cache after insertion
                self._get_supplier_ids(refresh=True)
            
            if 'employees' in counts:
                self.insert_employees(counts['employees'])
                # Refresh cache after insertion
                self._get_employee_ids(refresh=True)
            
            if 'products' in counts:
                self.insert_products(counts['products'])
                # Refresh cache after insertion
                self._get_product_ids(refresh=True)
            
            # Then load tables with complex dependencies
            if 'orders' in counts:
                self.insert_orders(counts['orders'])
                # Refresh cache after insertion
                self._get_order_ids(refresh=True)
            
            if 'order_items' in counts:
                self.insert_order_items(counts['order_items'])
            
            if 'inventory_transactions' in counts:
                self.insert_inventory_transactions(counts['inventory_transactions'])
            
            if 'payments' in counts:
                self.insert_payments(counts['payments'])
            
            # Commit the transaction
            self.transaction.commit()
            return "Data loaded successfully in the correct order to maintain referential integrity"
        except Exception as e:
            # Rollback on error
            self.transaction.rollback()
            raise e

    def insert_customers(self, amount):
        """Insert customer records"""
        results = []
        start_id = self._get_customer_increment()
        state_ids = self._get_state_ids()
        
        try:
            # Start a new transaction if one isn't already active
            if not self.transaction or not self.transaction.is_active:
                self.transaction = self.connection.begin()
            
            for i in range(amount):
                customer_id = start_id + i
                # Generate phone number and ensure it's not longer than 20 characters
                phone = fake.phone_number()
                if len(phone) > 20:
                    phone = phone[:18]  # Truncate to 20 characters
                    
                stmt = insert(customers).values(customer_id=customer_id,
                                                first_name=fake.first_name(),
                                                last_name=fake.last_name(),
                                                email=fake.email(),
                                                phone=phone,
                                                address=fake.street_address(),
                                                city=fake.city(),
                                                state_id=random.choice(state_ids),
                                                zip_code=fake.zipcode(),
                                                created_at=datetime.now(),
                                                updated_at=datetime.now()
                                                )
                result = self.connection.execute(stmt)
                results.append(result)
            
            # Commit the transaction
            self.transaction.commit()
            print(f"Successfully inserted {amount} customer records")
            
            # Start a new transaction for future operations
            self.transaction = self.connection.begin()
            
            # Update the increment for next batch
            self._customer_increment = start_id + amount
            # Add new IDs to cache
            if self._customer_ids is not None:
                self._customer_ids.extend(range(start_id, start_id + amount))
            return results
        except Exception as e:
            # Rollback on error
            if self.transaction and self.transaction.is_active:
                self.transaction.rollback()
            print(f"Error inserting customers: {e}")
            # Start a new transaction for future operations
            self.transaction = self.connection.begin()
            raise e

    def insert_products(self, amount):
        """Insert product records"""
        results = []
        start_id = self._get_product_increment()
        category_ids = self._get_category_ids()
        
        for i in range(amount):
            product_id = start_id + i
            stmt = insert(products).values(product_id=product_id,
                                           name=fake.word() + " " + fake.word(),
                                           description=fake.text(max_nb_chars=200),
                                           category_id=random.choice(category_ids),
                                           price=round(random.uniform(10.0, 1000.0), 2),
                                           cost=round(random.uniform(5.0, 800.0), 2),
                                           sku=fake.bothify(text='SKU-????-####'),
                                           inventory_quantity=random.randint(0, 1000),
                                           created_at=datetime.now(),
                                           updated_at=datetime.now()
                                           )
            result = self.connection.execute(stmt)
            results.append(result)
        
        # Update the increment for next batch
        self._product_increment = start_id + amount
        # Add new IDs to cache
        if self._product_ids is not None:
            self._product_ids.extend(range(start_id, start_id + amount))
        return results

    def insert_product_categories(self, amount):
        """Insert product category records"""
        results = []
        start_id = self._get_category_increment()
        
        for i in range(amount):
            category_id = start_id + i
            stmt = insert(product_categories).values(category_id=category_id,
                                                     name=fake.word() + " Category",
                                                     description=fake.sentence()
                                                     )
            result = self.connection.execute(stmt)
            results.append(result)
        
        # Update the increment for next batch
        self._category_increment = start_id + amount
        # Add new IDs to cache
        if self._category_ids is not None:
            self._category_ids.extend(range(start_id, start_id + amount))
        return results

    def insert_orders(self, amount):
        """Insert order records"""
        results = []
        start_id = self._get_order_increment()
        statuses = ['pending', 'completed', 'shipped', 'cancelled']
        payment_methods = ['credit_card', 'paypal', 'bank_transfer', 'cash']
        customer_ids = self._get_customer_ids()
        state_ids = self._get_state_ids()
        
        for i in range(amount):
            order_id = start_id + i
            order_date = fake.date_time_between(start_date='-1y', end_date='now')
            
            # Calculate realistic order totals
            items_count = random.randint(1, 5)
            item_prices = [round(random.uniform(10.0, 200.0), 2) for _ in range(items_count)]
            subtotal = sum(item_prices)
            tax_rate = 0.08  # 8% tax rate
            tax_amount = round(subtotal * tax_rate, 2)
            shipping_amount = round(random.uniform(5.0, 50.0), 2)
            order_total = subtotal + tax_amount + shipping_amount
            
            stmt = insert(orders).values(order_id=order_id,
                                         customer_id=random.choice(customer_ids),
                                         order_date=order_date,
                                         status=random.choice(statuses),
                                         shipping_address=fake.street_address(),
                                         shipping_city=fake.city(),
                                         shipping_state_id=random.choice(state_ids),
                                         shipping_zip=fake.zipcode(),
                                         payment_method=random.choice(payment_methods),
                                         order_total=order_total,
                                         tax_amount=tax_amount,
                                         shipping_amount=shipping_amount
                                         )
            result = self.connection.execute(stmt)
            results.append(result)
        
        # Update the increment for next batch
        self._order_increment = start_id + amount
        # Add new IDs to cache
        if self._order_ids is not None:
            self._order_ids.extend(range(start_id, start_id + amount))
        return results

    def insert_order_items(self, amount):
        """Insert order item records"""
        results = []
        start_id = self._get_order_item_increment()
        order_ids = self._get_order_ids()
        product_ids = self._get_product_ids()
        
        # Create a dictionary to track items per order for realistic order composition
        items_per_order = {}
        
        for i in range(amount):
            order_item_id = start_id + i
            
            # Select an order, preferring orders with fewer items
            order_id = random.choice(order_ids)
            items_per_order[order_id] = items_per_order.get(order_id, 0) + 1
            
            # Get product info including price
            product_id = random.choice(product_ids)
            product_query = select(products.c.price).where(products.c.product_id == product_id)
            product_price_result = self.connection.execute(product_query).fetchone()
            
            # Use the actual product price if available, otherwise generate one
            if product_price_result:
                unit_price = product_price_result[0]
            else:
                unit_price = round(random.uniform(10.0, 500.0), 2)
                
            quantity = random.randint(1, 10)
            line_total = quantity * unit_price
            
            stmt = insert(order_items).values(order_item_id=order_item_id,
                                              order_id=order_id,
                                              product_id=product_id,
                                              quantity=quantity,
                                              unit_price=unit_price,
                                              line_total=line_total
                                              )
            result = self.connection.execute(stmt)
            results.append(result)
            
            # Update order total to match sum of line items
            self._update_order_total(order_id)
        
        # Update the increment for next batch
        self._order_item_increment = start_id + amount
        return results
    
    def _update_order_total(self, order_id):
        """Update order total based on sum of line items"""
        # Get sum of line items
        query = select(func.sum(order_items.c.line_total)).where(order_items.c.order_id == order_id)
        subtotal = self.connection.execute(query).scalar() or 0
        
        # Calculate tax and shipping
        tax_rate = 0.08  # 8% tax
        tax_amount = round(subtotal * tax_rate, 2)
        
        # Get current shipping amount
        shipping_query = select(orders.c.shipping_amount).where(orders.c.order_id == order_id)
        shipping_amount = self.connection.execute(shipping_query).scalar() or 0
        
        # Calculate new total
        order_total = subtotal + tax_amount + shipping_amount
        
        # Update order
        update_stmt = orders.update().where(orders.c.order_id == order_id).values(
            order_total=order_total,
            tax_amount=tax_amount
        )
        self.connection.execute(update_stmt)

    def insert_employees(self, amount):
        """Insert employee records"""
        results = []
        start_id = self._get_employee_increment()
        positions = ['Sales Associate', 'Manager', 'Director', 'Analyst', 'Customer Support']
        departments = ['Sales', 'Marketing', 'Operations', 'Finance', 'IT', 'HR']
        
        # Get existing employee IDs for manager relationships
        existing_employee_ids = self._get_employee_ids()
        
        # Track new employees for manager assignments within this batch
        new_employee_ids = []
        
        for i in range(amount):
            employee_id = start_id + i
            new_employee_ids.append(employee_id)
            
            # For manager_id, use existing employees or None for top-level managers
            manager_id = None
            if i >= 5:  # Not one of the first 5 employees in this batch
                # Try to assign a manager from existing employees or earlier in this batch
                manager_candidates = existing_employee_ids + new_employee_ids[:i]
                if manager_candidates:
                    manager_id = random.choice(manager_candidates)
            
            hire_date = fake.date_between(start_date='-5y', end_date='today')
            
            stmt = insert(employees).values(employee_id=employee_id,
                                            first_name=fake.first_name(),
                                            last_name=fake.last_name(),
                                            email=fake.company_email(),
                                            hire_date=hire_date,
                                            position=random.choice(positions),
                                            department=random.choice(departments),
                                            salary=random.randint(30000, 150000),
                                            manager_id=manager_id
                                            )
            result = self.connection.execute(stmt)
            results.append(result)
        
        # Update the increment for next batch
        self._employee_increment = start_id + amount
        # Add new IDs to cache
        if self._employee_ids is not None:
            self._employee_ids.extend(new_employee_ids)
        return results

    def insert_suppliers(self, amount):
        """Insert supplier records"""
        results = []
        start_id = self._get_supplier_increment()
        state_ids = self._get_state_ids()
        
        for i in range(amount):
            supplier_id = start_id + i
            stmt = insert(suppliers).values(supplier_id=supplier_id,
                                            name=fake.company(),
                                            contact_name=fake.name(),
                                            email=fake.company_email(),
                                            phone=fake.phone_number(),
                                            address=fake.street_address(),
                                            city=fake.city(),
                                            state_id=random.choice(state_ids),
                                            zip_code=fake.zipcode()
                                            )
            result = self.connection.execute(stmt)
            results.append(result)
        
        # Update the increment for next batch
        self._supplier_increment = start_id + amount
        # Add new IDs to cache
        if self._supplier_ids is not None:
            self._supplier_ids.extend(range(start_id, start_id + amount))
        return results

    def insert_inventory_transactions(self, amount):
        """Insert inventory transaction records"""
        results = []
        start_id = self._get_transaction_increment()
        transaction_types = ['purchase', 'sale', 'adjustment']
        product_ids = self._get_product_ids()
        order_ids = self._get_order_ids()
        
        for i in range(amount):
            transaction_id = start_id + i
            product_id = random.choice(product_ids)
            transaction_type = random.choice(transaction_types)
            
            # Set quantity and reference based on transaction type
            if transaction_type == 'purchase':
                quantity = random.randint(1, 100)  # Positive for purchases
                reference_id = random.randint(1, 1000)  # Purchase order ID
            elif transaction_type == 'sale':
                quantity = -random.randint(1, 10)  # Negative for sales
                reference_id = random.choice(order_ids) if order_ids else 1  # Order ID
            else:  # adjustment
                quantity = random.randint(-20, 20)  # Can be positive or negative
                reference_id = None
            
            stmt = insert(inventory_transactions).values(transaction_id=transaction_id,
                                                         product_id=product_id,
                                                         transaction_type=transaction_type,
                                                         quantity=quantity,
                                                         transaction_date=fake.date_time_this_year(),
                                                         reference_id=reference_id,
                                                         notes=fake.sentence()
                                                         )
            result = self.connection.execute(stmt)
            results.append(result)
            
            # Update product inventory quantity
            self._update_product_inventory(product_id, quantity)
        
        # Update the increment for next batch
        self._transaction_increment = start_id + amount
        return results
    
    def _update_product_inventory(self, product_id, quantity_change):
        """Update product inventory based on transaction"""
        # Get current inventory
        query = select(products.c.inventory_quantity).where(products.c.product_id == product_id)
        current_quantity = self.connection.execute(query).scalar() or 0
        
        # Calculate new quantity
        new_quantity = current_quantity + quantity_change
        
        # Update product
        update_stmt = products.update().where(products.c.product_id == product_id).values(
            inventory_quantity=new_quantity,
            updated_at=datetime.now()
        )
        self.connection.execute(update_stmt)

    def insert_payments(self, amount):
        """Insert payment records"""
        results = []
        start_id = self._get_payment_increment()
        payment_methods = ['credit_card', 'paypal', 'bank_transfer', 'cash']
        statuses = ['completed', 'pending', 'failed', 'refunded']
        order_ids = self._get_order_ids()
        
        for i in range(amount):
            payment_id = start_id + i
            order_id = random.choice(order_ids)
            
            # Get order total for realistic payment amount
            order_query = select(orders.c.order_total).where(orders.c.order_id == order_id)
            order_total = self.connection.execute(order_query).scalar()
            
            # Use order total if available, otherwise generate random amount
            if order_total:
                amount_paid = order_total
            else:
                amount_paid = round(random.uniform(20.0, 2000.0), 2)
                
            payment_date = fake.date_time_this_year()
            status = random.choice(statuses)
            
            stmt = insert(payments).values(payment_id=payment_id,
                                           order_id=order_id,
                                           payment_date=payment_date,
                                           amount=amount_paid,
                                           payment_method=random.choice(payment_methods),
                                           transaction_id=fake.uuid4(),
                                           status=status
                                           )
            result = self.connection.execute(stmt)
            results.append(result)
            
            # Update order status based on payment status
            if status == 'completed':
                self._update_order_status(order_id, 'completed')
            elif status == 'failed':
                self._update_order_status(order_id, 'pending')
            elif status == 'refunded':
                self._update_order_status(order_id, 'cancelled')
        
        # Update the increment for next batch
        self._payment_increment = start_id + amount
        return results
    
    def _update_order_status(self, order_id, status):
        """Update order status based on payment status"""
        update_stmt = orders.update().where(orders.c.order_id == order_id).values(
            status=status
        )
        self.connection.execute(update_stmt)
        
    def insert_states(self):
        """Insert all 50 US states"""
        states = [
            {"id": 1, "name": "Alabama"}, {"id": 2, "name": "Alaska"}, 
            {"id": 3, "name": "Arizona"}, {"id": 4, "name": "Arkansas"},
            {"id": 5, "name": "California"}, {"id": 6, "name": "Colorado"},
            {"id": 7, "name": "Connecticut"}, {"id": 8, "name": "Delaware"},
            {"id": 9, "name": "Florida"}, {"id": 10, "name": "Georgia"},
            {"id": 11, "name": "Hawaii"}, {"id": 12, "name": "Idaho"},
            {"id": 13, "name": "Illinois"}, {"id": 14, "name": "Indiana"},
            {"id": 15, "name": "Iowa"}, {"id": 16, "name": "Kansas"},
            {"id": 17, "name": "Kentucky"}, {"id": 18, "name": "Louisiana"},
            {"id": 19, "name": "Maine"}, {"id": 20, "name": "Maryland"},
            {"id": 21, "name": "Massachusetts"}, {"id": 22, "name": "Michigan"},
            {"id": 23, "name": "Minnesota"}, {"id": 24, "name": "Mississippi"},
            {"id": 25, "name": "Missouri"}, {"id": 26, "name": "Montana"},
            {"id": 27, "name": "Nebraska"}, {"id": 28, "name": "Nevada"},
            {"id": 29, "name": "New Hampshire"}, {"id": 30, "name": "New Jersey"},
            {"id": 31, "name": "New Mexico"}, {"id": 32, "name": "New York"},
            {"id": 33, "name": "North Carolina"}, {"id": 34, "name": "North Dakota"},
            {"id": 35, "name": "Ohio"}, {"id": 36, "name": "Oklahoma"},
            {"id": 37, "name": "Oregon"}, {"id": 38, "name": "Pennsylvania"},
            {"id": 39, "name": "Rhode Island"}, {"id": 40, "name": "South Carolina"},
            {"id": 41, "name": "South Dakota"}, {"id": 42, "name": "Tennessee"},
            {"id": 43, "name": "Texas"}, {"id": 44, "name": "Utah"},
            {"id": 45, "name": "Vermont"}, {"id": 46, "name": "Virginia"},
            {"id": 47, "name": "Washington"}, {"id": 48, "name": "West Virginia"},
            {"id": 49, "name": "Wisconsin"}, {"id": 50, "name": "Wyoming"}
        ]
        
        results = []
        for state in states:
            # Check if state already exists
            check_query = select(States).where(States.c.id == state["id"])
            existing = self.connection.execute(check_query).fetchone()
            
            if not existing:
                stmt = insert(States).values(id=state["id"], name=state["name"])
                result = self.connection.execute(stmt)
                results.append(result)
        
        # Update state IDs cache
        self._state_ids = list(range(1, 51))
        return results
    
    def close_connection(self):
        """Close the database connection"""
        try:
            # Commit any pending transaction if it's still active
            if self.transaction and self.transaction.is_active:
                self.transaction.commit()
                print("Transaction committed successfully")
        except Exception as e:
            # Rollback on error
            if self.transaction and self.transaction.is_active:
                self.transaction.rollback()
            print(f"Error committing transaction: {e}")
        finally:
            # Close the connection
            if self.connection:
                self.connection.close()
                print("Database connection closed")
