from sqlalchemy import Table, Column, MetaData, Integer, String, Float, DateTime, ForeignKey, Date, Boolean, Text
import sqlalchemy as sa
metadata = MetaData()

engine = sa.create_engine('sqlite:///ingest.dbthero.db')

# OLTP Tables for Sales System

# Customer table
customers = Table('customers',
                 metadata,
                 Column("customer_id", Integer, primary_key=True),
                 Column("first_name", String(50)),
                 Column("last_name", String(50)),
                 Column("email", String(100)),
                 Column("phone", String(20)),
                 Column("address", String(200)),
                 Column("city", String(50)),
                 Column("state_id", Integer, ForeignKey("states.id")),
                 Column("zip_code", String(10)),
                 Column("created_at", DateTime),
                 Column("updated_at", DateTime),
                 )

# Product table
products = Table('products',
                metadata,
                Column("product_id", Integer, primary_key=True),
                Column("name", String(100)),
                Column("description", Text),
                Column("category_id", Integer, ForeignKey("product_categories.category_id")),
                Column("price", Float),
                Column("cost", Float),
                Column("sku", String(50)),
                Column("inventory_quantity", Integer),
                Column("created_at", DateTime),
                Column("updated_at", DateTime),
                )

# Product Categories
product_categories = Table('product_categories',
                          metadata,
                          Column("category_id", Integer, primary_key=True),
                          Column("name", String(150)),
                          Column("description", String(200)),
                          )

# Orders table
orders = Table('orders',
              metadata,
              Column("order_id", Integer, primary_key=True),
              Column("customer_id", Integer, ForeignKey("customers.customer_id")),
              Column("order_date", DateTime),
              Column("status", String(200)),  # pending, completed, shipped, cancelled
              Column("shipping_address", String(200)),
              Column("shipping_city", String(150)),
              Column("shipping_state_id", Integer, ForeignKey("states.id")),
              Column("shipping_zip", String(100)),
              Column("payment_method", String(150)),
              Column("order_total", Float),
              Column("tax_amount", Float),
              Column("shipping_amount", Float),
              )

# Order Items (order details)
order_items = Table('order_items',
                   metadata,
                   Column("order_item_id", Integer, primary_key=True),
                   Column("order_id", Integer, ForeignKey("orders.order_id")),
                   Column("product_id", Integer, ForeignKey("products.product_id")),
                   Column("quantity", Integer),
                   Column("unit_price", Float),
                   Column("line_total", Float),
                   )

# Employees
employees = Table('employees',
                 metadata,
                 Column("employee_id", Integer, primary_key=True),
                 Column("first_name", String(150)),
                 Column("last_name", String(150)),
                 Column("email", String(100)),
                 Column("hire_date", Date),
                 Column("position", String(150)),
                 Column("department", String(150)),
                 Column("salary", Float),
                 Column("manager_id", Integer, ForeignKey("employees.employee_id")),
                 )

# States table (already defined, keeping it)
States = Table('states',
               metadata,
               Column("id", Integer, primary_key=True),
               Column("name", String(255)),
               )

# Suppliers
suppliers = Table('suppliers',
                 metadata,
                 Column("supplier_id", Integer, primary_key=True),
                 Column("name", String(100)),
                 Column("contact_name", String(100)),
                 Column("email", String(100)),
                 Column("phone", String(120)),
                 Column("address", String(200)),
                 Column("city", String(150)),
                 Column("state_id", Integer, ForeignKey("states.id")),
                 Column("zip_code", String(110)),
                 )

# Inventory Transactions
inventory_transactions = Table('inventory_transactions',
                              metadata,
                              Column("transaction_id", Integer, primary_key=True),
                              Column("product_id", Integer, ForeignKey("products.product_id")),
                              Column("transaction_type", String(120)),  # purchase, sale, adjustment
                              Column("quantity", Integer),
                              Column("transaction_date", DateTime),
                              Column("reference_id", Integer),  # order_id or purchase_id
                              Column("notes", String(200)),
                              )

# Payments
payments = Table('payments',
                metadata,
                Column("payment_id", Integer, primary_key=True),
                Column("order_id", Integer, ForeignKey("orders.order_id")),
                Column("payment_date", DateTime),
                Column("amount", Float),
                Column("payment_method", String(150)),
                Column("transaction_id", String(100)),
                Column("status", String(120)),
                )

