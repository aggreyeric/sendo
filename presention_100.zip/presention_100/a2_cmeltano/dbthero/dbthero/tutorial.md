# DBT Hero Tutorial

This tutorial provides step-by-step instructions for setting up, running, and extending the DBT Hero project, which transforms sales OLTP data into a dimensional data warehouse.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Setup](#project-setup)
3. [Data Loading](#data-loading)
4. [Running dbt Models](#running-dbt-models)
5. [Understanding the Model Structure](#understanding-the-model-structure)
6. [Extending the Models](#extending-the-models)
7. [Testing and Validation](#testing-and-validation)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

Before starting, ensure you have:

- PostgreSQL database installed and running
- dbt installed (`pip install dbt-postgres`)
- Python 3.8+ with SQLAlchemy and Faker for data generation
- Podman (with Docker aliases configured in PowerShell)

## Project Setup

### 1. Configure dbt Profile

Create or update your `~/.dbt/profiles.yml` file with the following configuration:

```yaml
dbthero:
  target: dev
  outputs:
    dev:
      type: postgres
      host: localhost
      user: postgres
      password: your_password_here  # Replace with your actual password
      port: 5432
      dbname: dbthero
      schema: public
      threads: 4
      keepalives_idle: 0
      connect_timeout: 10
      retries: 1
```

### 2. Install Dependencies

Navigate to your project directory and run:

```bash
dbt deps
```

This will install the required dbt packages, including dbt_utils.

### 3. Create Database Schemas

Run the following command to create the necessary schemas:

```bash
dbt run-operation create_schemas
```

This will create the `staging`, `intermediate`, and `dwh` schemas in your database.

## Data Loading

### 1. Generate Test Data

The project includes a `LoadData` class in `tables/data_load_helpers.py` for generating realistic test data:

```python
from tables.data_load_helpers import LoadData
from tables.tables import create_tables

# Create tables and load data
loader = LoadData(connection_string="postgresql://postgres:password@localhost:5432/dbthero")
create_tables(loader.engine)

# Load data incrementally
loader.load_in_order(
    num_customers=100,
    num_products=50,
    num_suppliers=10,
    num_employees=20,
    num_orders=200
)

# Close connection
loader.close_connection()
```

### 2. Verify Data Loading

Check that your tables are populated in the `public` schema:

```sql
SELECT COUNT(*) FROM public.customers;
SELECT COUNT(*) FROM public.orders;
SELECT COUNT(*) FROM public.products;
```

## Running dbt Models

### 1. Run the Complete Project

For convenience, you can use the provided PowerShell script:

```powershell
.\setup_and_run.ps1
```

### 2. Run Models by Layer

Alternatively, you can run each layer separately:

```bash
# Staging models
dbt run --models staging

# Intermediate models
dbt run --models intermediate

# Marts models
dbt run --models marts
```

### 3. Run Specific Models

To run specific models:

```bash
# Run a specific model
dbt run --models dim_customer

# Run models with a specific tag
dbt run --models tag:daily
```

## Understanding the Model Structure

### Source Layer

The source layer is defined in `models/sources.yml` and connects to your database tables:

```yaml
sources:
  - name: sales_oltp
    schema: public
    tables:
      - name: customers
      - name: products
      # etc.
```

### Staging Layer

Staging models perform minimal transformations and standardize naming:

```sql
-- models/staging/sales_oltp/stg_sales_oltp__customers.sql
select
    customer_id,
    first_name,
    last_name,
    -- etc.
from {{ source('sales_oltp', 'customers') }}
```

### Intermediate Layer

Intermediate models join staging models and apply business logic:

```sql
-- models/intermediate/int_customers_with_states.sql
select
    c.*,
    s.name as state_name
from {{ ref('stg_sales_oltp__customers') }} c
left join {{ ref('stg_sales_oltp__states') }} s on c.state_id = s.state_id
```

### Marts Layer

Marts models create the final dimensional model:

```sql
-- models/marts/core/dim_customer.sql
select
    customer_id,
    first_name,
    last_name,
    full_name,
    -- etc.
from {{ ref('int_customers_with_states') }}
```

## Extending the Models

### Adding a New Source Table

1. Update your database schema with the new table
2. Add the table to `models/sources.yml`
3. Create a staging model for the table

### Creating a New Dimension

1. Create a staging model if needed
2. Create intermediate models for any required joins
3. Create the dimension model in the marts layer
4. Update `schema.yml` with documentation and tests

### Creating a New Fact Table

1. Identify the required dimensions and measures
2. Create intermediate models to join the relevant staging models
3. Create the fact model in the marts layer
4. Update `schema.yml` with documentation and tests

## Testing and Validation

### Running Tests

Run all tests with:

```bash
dbt test
```

Or test specific models:

```bash
dbt test --models dim_customer
```

### Adding Tests

Add tests in the `schema.yml` files:

```yaml
models:
  - name: dim_customer
    columns:
      - name: customer_id
        tests:
          - unique
          - not_null
      - name: email
        tests:
          - unique
```

### Custom Tests

Create custom tests in the `tests` directory:

```sql
-- tests/assert_customer_count_above_threshold.sql
select *
from {{ ref('dim_customer') }}
having count(*) < 10
```

## Troubleshooting

### Common Issues

1. **Connection errors**: Verify your database credentials in `profiles.yml`
2. **Missing tables**: Ensure data loading completed successfully
3. **Schema conflicts**: Run `dbt clean` and try again
4. **Package errors**: Verify `packages.yml` and run `dbt deps`

### Debugging Tips

1. Use `dbt compile` to check SQL generation without running
2. Check logs in the `target/` directory
3. Use `--debug` flag for verbose output: `dbt run --debug`
4. Verify schema permissions in your database

---

This tutorial covers the basics of working with the DBT Hero project. For more advanced dbt features, refer to the [official dbt documentation](https://docs.getdbt.com/).
