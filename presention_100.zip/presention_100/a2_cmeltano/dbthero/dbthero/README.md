# DBT Hero - Sales Data Warehouse

This dbt project transforms OLTP sales system data into a dimensional data warehouse model for analytics.

## Project Structure

The project follows a layered architecture approach:

### Sources
- Defined in `models/sources.yml`
- Two main sources:
  - `sales_oltp`: Source OLTP tables in the `public` schema
  - `sales_dwh`: Target data warehouse tables in the `dwh` schema

### Staging Layer
- Located in `models/staging/sales_oltp/`
- One-to-one mapping with source tables
- Minimal transformations (renaming, type casting)
- All materialized as views

### Intermediate Layer
- Located in `models/intermediate/`
- Joins between staging models
- Business logic and transformations
- All materialized as views

### Marts Layer
- Located in `models/marts/core/`
- Dimensional model with facts and dimensions
- Materialized as tables for query performance
- Located in the `dwh` schema

## Dimensional Model

### Dimension Tables
- `dim_customer`: Customer information with state details
- `dim_product`: Product information with categories and suppliers
- `dim_employee`: Employee information with manager hierarchy
- `dim_supplier`: Supplier information with state details
- `dim_date`: Date dimension for time-based analysis

### Fact Tables
- `fact_sales`: Sales transactions with order and order item details
- `fact_inventory`: Inventory transactions with product details

## Getting Started

1. Install dependencies:
```
dbt deps
```

2. Run the models:
```
dbt run
```

3. Test the models:
```
dbt test
```

4. Generate documentation:
```
dbt docs generate
dbt docs serve
```

## Development Workflow

1. Make changes to source tables in the `public` schema
2. Run staging models: `dbt run --models staging`
3. Run intermediate models: `dbt run --models intermediate`
4. Run mart models: `dbt run --models marts`
5. Run tests: `dbt test`

## Resources

- Learn more about dbt [in the docs](https://docs.getdbt.com/docs/introduction)
- Check out [Discourse](https://discourse.getdbt.com/) for commonly asked questions and answers
- Join the [chat](https://community.getdbt.com/) on Slack for live discussions and support
- Find [dbt events](https://events.getdbt.com) near you
- Check out [the blog](https://blog.getdbt.com/) for the latest news on dbt's development and best practices
