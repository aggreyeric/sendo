with employees as (
    select * from {{ ref('stg_sales_oltp__employees') }}
),

managers as (
    select * from {{ ref('stg_sales_oltp__employees') }}
),

employees_with_managers as (
    select
        e.employee_id,
        e.first_name,
        e.last_name,
        e.first_name || ' ' || e.last_name as full_name,
        e.email,
        e.hire_date,
        e.position,
        e.department,
        e.salary,
        e.manager_id,
        m.first_name as manager_first_name,
        m.last_name as manager_last_name,
        m.first_name || ' ' || m.last_name as manager_full_name,
        m.position as manager_position,
        
        -- Derived fields
        extract(year from age(current_date, e.hire_date)) as years_employed,
        case
            when m.employee_id is null then 1
            else 0
        end as is_top_level
    from employees e
    left join managers m on e.manager_id = m.employee_id
)

select * from employees_with_managers
