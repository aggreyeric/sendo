with order_items as (
    select * from {{ ref('stg_sales_oltp__order_items') }}
),

products as (
    select * from {{ ref('stg_sales_oltp__products') }}
),

product_categories as (
    select * from {{ ref('stg_sales_oltp__product_categories') }}
),

order_items_with_products as (
    select
        oi.order_item_id,
        oi.order_id,
        oi.product_id,
        oi.quantity,
        oi.unit_price,
        oi.line_total,
        
        -- Product details
        p.product_name,
        p.product_description,
        pc.category_id,
        pc.name as category_name,
        
        -- Derived fields
        (oi.unit_price * oi.quantity) as calculated_line_total,
        case
            when oi.quantity > 10 then 'Large Order'
            when oi.quantity > 5 then 'Medium Order'
            else 'Small Order'
        end as order_size
    from order_items oi
    left join products p on oi.product_id = p.product_id
    left join product_categories pc on p.category_id = pc.category_id
)

select * from order_items_with_products
