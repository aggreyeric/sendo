with suppliers as (
    select * from {{ ref('stg_sales_oltp__suppliers') }}
),

states as (
    select * from {{ ref('stg_sales_oltp__states') }}
),

suppliers_with_states as (
    select
        s.supplier_id,
        s.name,
        s.contact_name,
        s.email,
        s.phone,
        s.address,
        s.city,
        st.name as state_name,
        s.zip_code
    from suppliers s
    left join states st on s.state_id = st.state_id
)

select * from suppliers_with_states
