with customers as (
    select * from {{ ref('stg_sales_oltp__customers') }}
),

states as (
    select * from {{ ref('stg_sales_oltp__states') }}
),

customers_with_states as (
    select
        c.customer_id,
        c.first_name,
        c.last_name,
        c.email,
        c.phone,
        c.address,
        c.city,
        s.name as state_name,
        c.zip_code,
        c.created_at,
        c.updated_at
    from customers c
    left join states s on c.state_id = s.state_id
)

select * from customers_with_states
