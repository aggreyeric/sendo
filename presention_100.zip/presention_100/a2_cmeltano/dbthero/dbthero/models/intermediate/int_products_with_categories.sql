with products as (
    select * from {{ ref('stg_sales_oltp__products') }}
),

categories as (
    select * from {{ ref('stg_sales_oltp__product_categories') }}
),

products_with_details as (
    select
        p.product_id,
        p.product_name,
        p.product_description,
        p.unit_price,
        p.stock_quantity,
        p.cost,
        p.sku,
        c.category_id,
        c.name as category_name,
        p.created_at,
        p.updated_at
    from products p
    left join categories c on p.category_id = c.category_id
)

select * from products_with_details
