with orders as (
    select * from {{ ref('stg_sales_oltp__orders') }}
),

customers as (
    select * from {{ ref('stg_sales_oltp__customers') }}
),

states as (
    select * from {{ ref('stg_sales_oltp__states') }}
),

orders_with_details as (
    select
        o.order_id,
        o.order_date,
        o.order_status,
        o.order_total,
        o.tax_amount,
        o.shipping_amount,
        o.payment_method,
        
        -- Customer details
        c.customer_id,
        c.first_name as customer_first_name,
        c.last_name as customer_last_name,
        c.first_name || ' ' || c.last_name as customer_full_name,
        c.email as customer_email,
        
        -- Shipping details
        o.address as shipping_address,
        o.city as shipping_city,
        s.name as shipping_state,
        o.zip_code as shipping_zip,
        
        -- Derived fields
        case
            when o.order_status = 'Completed' then 1
            else 0
        end as is_completed
    from orders o
    left join customers c on o.customer_id = c.customer_id
    left join states s on o.state_id = s.state_id
)

select * from orders_with_details
