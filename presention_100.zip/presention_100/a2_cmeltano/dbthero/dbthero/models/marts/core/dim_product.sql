{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with products_with_details as (
    select * from {{ ref('int_products_with_categories') }}
),

final as (
    select
        product_id,
        product_name,
        product_description,
        unit_price,
        stock_quantity,
        cost,
        sku,
        category_id,
        category_name,
        created_at,
        updated_at,
        
        -- Add derived fields
        case
            when stock_quantity = 0 then 'Out of Stock'
            when stock_quantity < 10 then 'Low Stock'
            when stock_quantity < 50 then 'Medium Stock'
            else 'High Stock'
        end as stock_status,
        
        case
            when unit_price < 10 then 'Budget'
            when unit_price < 50 then 'Standard'
            when unit_price < 100 then 'Premium'
            else 'Luxury'
        end as price_tier
    from products_with_details
)

select * from final
