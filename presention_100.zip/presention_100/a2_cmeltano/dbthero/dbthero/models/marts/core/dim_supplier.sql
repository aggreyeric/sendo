{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with suppliers_with_states as (
    select * from {{ ref('int_suppliers_with_states') }}
),

final as (
    select
        supplier_id,
        name as supplier_name,
        contact_name,
        email,
        phone,
        address,
        city,
        state_name,
        zip_code
    from suppliers_with_states
)

select * from final
