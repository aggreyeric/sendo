{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with orders as (
    select * from {{ ref('int_orders_with_details') }}
),

order_items as (
    select * from {{ ref('int_order_items_with_products') }}
),

payments as (
    select * from {{ ref('stg_sales_oltp__payments') }}
),

sales_fact as (
    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['oi.order_item_id', 'o.order_id']) }} as sales_key,
        
        -- Foreign keys to dimensions
        o.order_id,
        oi.order_item_id,
        o.customer_id,
        oi.product_id,
        
        -- Date information
        o.order_date,
        
        -- Sales metrics
        oi.quantity,
        oi.unit_price,
        oi.line_total,
        o.tax_amount,
        o.shipping_amount,
        o.order_total,
        
        -- Order information
        o.order_status,
        o.is_completed,
        
        -- Payment information
        o.payment_method,
        
        -- Product information
        oi.product_name,
        oi.category_id,
        oi.category_name,
        
        -- Customer information
        o.customer_full_name,
        
        -- Shipping information
        o.shipping_address,
        o.shipping_city,
        o.shipping_state,
        o.shipping_zip
    from order_items oi
    inner join orders o on oi.order_id = o.order_id
)

select * from sales_fact
