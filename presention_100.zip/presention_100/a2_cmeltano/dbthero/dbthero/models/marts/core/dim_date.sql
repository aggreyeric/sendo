{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with date_spine as (
    select
        date_day::date as date_day
    from
        generate_series(
            '2020-01-01'::date,
            (current_date + interval '5 years')::date,
            interval '1 day'
        ) as date_day
),

dates as (
    select
        date_day as date_key,
        date_day as full_date,
        extract(year from date_day) as year,
        extract(month from date_day) as month,
        extract(day from date_day) as day,
        extract(quarter from date_day) as quarter,
        extract(dow from date_day) + 1 as day_of_week,
        extract(doy from date_day) as day_of_year,
        
        -- Month names
        to_char(date_day, 'MMMM') as month_name,
        to_char(date_day, 'MON') as month_short_name,
        
        -- Day names
        to_char(date_day, 'DAY') as day_name,
        to_char(date_day, 'DY') as day_short_name,
        
        -- Fiscal periods (assuming fiscal year starts July 1)
        case
            when extract(month from date_day) >= 7 then extract(year from date_day) + 1
            else extract(year from date_day)
        end as fiscal_year,
        
        case
            when extract(month from date_day) >= 7 then extract(month from date_day) - 6
            else extract(month from date_day) + 6
        end as fiscal_month,
        
        -- Flags for special days
        case when extract(month from date_day) = 1 and extract(day from date_day) = 1 then 1 else 0 end as is_new_year,
        case when to_char(date_day, 'MM-DD') = '07-04' then 1 else 0 end as is_independence_day,
        case when to_char(date_day, 'MM-DD') = '12-25' then 1 else 0 end as is_christmas,
        
        -- Weekend flag
        case
            when extract(dow from date_day) in (0, 6) then 1
            else 0
        end as is_weekend,
        
        -- Current date flags
        case when date_day = current_date then 1 else 0 end as is_current_day,
        case when extract(year from date_day) = extract(year from current_date) and 
                  extract(month from date_day) = extract(month from current_date) 
             then 1 else 0 end as is_current_month,
        case when extract(year from date_day) = extract(year from current_date) 
             then 1 else 0 end as is_current_year
    from date_spine
)

select * from dates
