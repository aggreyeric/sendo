{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with customer_with_states as (
    select * from {{ ref('int_customers_with_states') }}
),

final as (
    select
        customer_id,
        first_name,
        last_name,
        first_name || ' ' || last_name as full_name,
        email,
        phone,
        address,
        city,
        state_name,
        zip_code,
        created_at,
        updated_at,
        
        -- Add derived fields
        case
            when created_at > (current_timestamp - interval '3 months') then 'New'
            when created_at > (current_timestamp - interval '1 year') then 'Regular'
            else 'Established'
        end as customer_category
    from customer_with_states
)

select * from final
