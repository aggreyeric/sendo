{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with inventory_transactions as (
    select * from {{ ref('stg_sales_oltp__inventory_transactions') }}
),

products as (
    select * from {{ ref('int_products_with_categories') }}
),

inventory_fact as (
    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['it.transaction_id']) }} as inventory_key,
        
        -- Foreign keys to dimensions
        it.transaction_id,
        it.product_id,
        it.reference_id,
        
        -- Transaction information
        it.transaction_type,
        it.quantity,
        it.transaction_date,
        it.notes,
        
        -- Product information
        p.product_name,
        p.category_id,
        p.category_name,
        p.unit_price,
        p.cost,
        
        -- Derived metrics
        case
            when it.transaction_type = 'purchase' then it.quantity
            when it.transaction_type = 'sale' then -it.quantity
            else it.quantity
        end as quantity_change,
        
        case
            when it.transaction_type = 'purchase' then it.quantity * p.cost
            when it.transaction_type = 'sale' then -it.quantity * p.cost
            else 0
        end as inventory_cost_change,
        
        case
            when it.transaction_type = 'purchase' then it.quantity * p.unit_price
            when it.transaction_type = 'sale' then -it.quantity * p.unit_price
            else 0
        end as inventory_value_change,
        
        extract(year from it.transaction_date) as transaction_year,
        extract(month from it.transaction_date) as transaction_month,
        extract(day from it.transaction_date) as transaction_day
    from inventory_transactions it
    left join products p on it.product_id = p.product_id
)

select * from inventory_fact
