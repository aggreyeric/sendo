{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with employees_with_managers as (
    select * from {{ ref('int_employees_with_managers') }}
),

final as (
    select
        employee_id,
        first_name,
        last_name,
        full_name,
        email,
        hire_date,
        position,
        department,
        salary,
        manager_id,
        manager_first_name,
        manager_last_name,
        manager_full_name,
        manager_position,
        years_employed,
        is_top_level,
        
        -- Add derived fields
        case
            when years_employed < 1 then 'New Hire'
            when years_employed < 3 then 'Junior'
            when years_employed < 7 then 'Mid-level'
            else 'Senior'
        end as tenure_category,
        
        case
            when position like '%Manager%' or position like '%Director%' then 1
            else 0
        end as is_management
    from employees_with_managers
)

select * from final
