{{ config(
    materialized='incremental',
    unique_key='PRODUCT_ID',
    on_schema_change='sync_all_columns'
) }}

with source as (
    select * from {{ source('bootcamp_snowflake', 'SINGERDB-MARTS-PRODUCTS') }}
),

renamed as (
    select
        PRODUCT_ID,
        PRODUCT_NAME,
        CATEGORY,
        PRICE,
        STOCK_QUANTITY,
        CREATED_AT,
        UPDATED_AT,
        current_timestamp() as _loaded_at
    from source
)

select * from renamed

{% if is_incremental() %}
    where _loaded_at > (select max(_loaded_at) from {{ this }})
{% endif %}
