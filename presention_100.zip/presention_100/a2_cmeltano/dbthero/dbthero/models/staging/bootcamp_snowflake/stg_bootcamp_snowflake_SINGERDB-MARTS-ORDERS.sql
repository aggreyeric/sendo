{{ config(
    materialized='incremental',
    unique_key='ORDER_ID',
    on_schema_change='sync_all_columns'
) }}

with source as (
    select * from {{ source('bootcamp_snowflake', 'SINGERDB-MARTS-ORDERS') }}
),

renamed as (
    select
        ORDER_ID,
        CUSTOMER_ID,
        ORDER_DATE,
        STATUS,
        TOTAL_AMOUNT,
        CREATED_AT,
        UPDATED_AT,
        current_timestamp() as _loaded_at
    from source
)

select * from renamed

{% if is_incremental() %}
    where _loaded_at > (select max(_loaded_at) from {{ this }})
{% endif %}
