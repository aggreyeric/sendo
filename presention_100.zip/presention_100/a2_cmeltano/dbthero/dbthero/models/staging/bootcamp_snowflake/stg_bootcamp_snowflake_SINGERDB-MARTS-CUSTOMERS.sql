{{ config(
    materialized='incremental',
    unique_key='CUSTOMER_ID',
    on_schema_change='sync_all_columns'
) }}

with source as (
    select * from {{ source('bootcamp_snowflake', 'SINGERDB-MARTS-CUSTOMERS') }}
),

renamed as (
    select
        CUSTOMER_ID,
        FIRST_NAME,
        LAST_NAME,
        EMAIL,
        PHONE,
        CITY,
        STATE,
        COUNTRY,
        CREATED_AT,
        UPDATED_AT,
        current_timestamp() as _loaded_at
    from source
)

select * from renamed

{% if is_incremental() %}
    where _loaded_at > (select max(_loaded_at) from {{ this }})
{% endif %}
