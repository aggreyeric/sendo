with source as (
    select * from {{ source('sales_oltp', 'products') }}
),

renamed as (
    select
        product_id,
        name as product_name,
        description as product_description,
        category_id,
        price as unit_price,
        cost,
        sku,
        inventory_quantity as stock_quantity,
        created_at,
        updated_at
    from source
)

select * from renamed
