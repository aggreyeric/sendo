with source as (
    select * from {{ source('sales_oltp', 'inventory_transactions') }}
),

renamed as (
    select
        transaction_id,
        product_id,
        transaction_type,
        quantity,
        transaction_date,
        reference_id,
        notes
    from source
)

select * from renamed
