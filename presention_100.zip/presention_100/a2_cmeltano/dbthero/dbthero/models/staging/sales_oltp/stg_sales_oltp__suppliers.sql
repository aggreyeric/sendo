with source as (
    select * from {{ source('sales_oltp', 'suppliers') }}
),

renamed as (
    select
        supplier_id,
        name,
        contact_name,
        email,
        phone,
        address,
        city,
        state_id,
        zip_code
    from source
)

select * from renamed
