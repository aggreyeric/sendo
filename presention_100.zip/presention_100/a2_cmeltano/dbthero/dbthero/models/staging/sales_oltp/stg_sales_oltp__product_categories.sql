with source as (
    select * from {{ source('sales_oltp', 'product_categories') }}
),

renamed as (
    select
        category_id,
        name,
        description
    from source
)

select * from renamed
