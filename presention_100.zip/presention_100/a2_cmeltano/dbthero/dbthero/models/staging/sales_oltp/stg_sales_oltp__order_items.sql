with source as (
    select * from {{ source('sales_oltp', 'order_items') }}
),

renamed as (
    select
        order_item_id,
        order_id,
        product_id,
        quantity,
        unit_price,
        line_total
    from source
)

select * from renamed
