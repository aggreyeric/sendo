with source as (
    select * from {{ source('sales_oltp', 'payments') }}
),

renamed as (
    select
        payment_id,
        order_id,
        payment_date,
        payment_method,
        amount,
        status
    from source
)

select * from renamed
