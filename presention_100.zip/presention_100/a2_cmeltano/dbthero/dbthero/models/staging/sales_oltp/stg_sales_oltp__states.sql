with source as (
    select * from {{ source('sales_oltp', 'states') }}
),

renamed as (
    select
        id as state_id,
        name
    from source
)

select * from renamed
