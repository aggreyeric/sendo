with source as (
    select * from {{ source('sales_oltp', 'orders') }}
),

renamed as (
    select
        order_id,
        customer_id,
        order_date,
        status as order_status,
        shipping_address as address,
        shipping_city as city,
        shipping_state_id as state_id,
        shipping_zip as zip_code,
        payment_method,
        order_total,
        tax_amount,
        shipping_amount
    from source
)

select * from renamed
