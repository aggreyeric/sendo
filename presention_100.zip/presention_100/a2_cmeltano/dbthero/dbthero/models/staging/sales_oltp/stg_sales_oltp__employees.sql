with source as (
    select * from {{ source('sales_oltp', 'employees') }}
),

renamed as (
    select
        employee_id,
        first_name,
        last_name,
        email,
        hire_date,
        position,
        department,
        salary,
        manager_id
    from source
)

select * from renamed
