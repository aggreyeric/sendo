# PowerShell script to set up and run dbt project

# Install dependencies
Write-Host "Installing dbt dependencies..." -ForegroundColor Green
dbt deps

# Create schemas
Write-Host "Creating schemas..." -ForegroundColor Green
dbt run-operation create_schemas

# Run the models in order
Write-Host "Running staging models..." -ForegroundColor Green
dbt run --models staging

Write-Host "Running intermediate models..." -ForegroundColor Green
dbt run --models intermediate

Write-Host "Running mart models..." -ForegroundColor Green
dbt run --models marts

# Run tests
Write-Host "Running tests..." -ForegroundColor Green
dbt test

Write-Host "Setup and run complete!" -ForegroundColor Green
