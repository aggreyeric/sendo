{% macro create_schemas() %}

-- Create the staging schema if it doesn't exist
{% if execute %}
    {% do run_query('CREATE SCHEMA IF NOT EXISTS staging') %}
    {{ log('Created schema "staging" if it did not exist', info=True) }}
{% endif %}

-- Create the intermediate schema if it doesn't exist
{% if execute %}
    {% do run_query('CREATE SCHEMA IF NOT EXISTS intermediate') %}
    {{ log('Created schema "intermediate" if it did not exist', info=True) }}
{% endif %}

-- Create the dwh schema if it doesn't exist
{% if execute %}
    {% do run_query('CREATE SCHEMA IF NOT EXISTS dwh') %}
    {{ log('Created schema "dwh" if it did not exist', info=True) }}
{% endif %}

{% endmacro %}
