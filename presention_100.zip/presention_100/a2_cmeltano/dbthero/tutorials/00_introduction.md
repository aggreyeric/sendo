# DBT Hero: Building a Data Warehouse with dbt
## Introduction: What is DBT Hero?

### Welcome to DBT Hero!

Welcome to the DBT Hero tutorial series! In this comprehensive guide, you'll learn how to transform an OLTP (Online Transaction Processing) database into a dimensional data warehouse using dbt (data build tool).

### What You'll Learn

By the end of this tutorial series, you will:
- Set up a complete dbt project from scratch
- Transform normalized OLTP data into a dimensional model
- Create staging, intermediate, and mart layers
- Implement tests and documentation
- Build fact and dimension tables
- Handle common data modeling challenges
- Deploy and run your dbt project

### Project Overview

DBT Hero is a project that transforms a sales system database into a dimensional data warehouse. The source system contains:

- Customers and their orders
- Products and inventory
- Suppliers and employees
- Sales transactions and payments

We'll transform this into a star schema with fact and dimension tables that make analytics queries simpler and more efficient.

### Prerequisites

To follow along with this tutorial, you should have:
- Basic SQL knowledge
- PostgreSQL installed (or Docker/Podman to run it)
- Python 3.8+ installed
- Basic understanding of data warehousing concepts

### What Makes This Project Special

Unlike many tutorials that use simplified examples, DBT Hero:
1. Uses realistic data with proper relationships
2. Implements a complete layered architecture
3. Includes incremental loading of test data
4. Handles common challenges like schema changes
5. Provides comprehensive documentation and tests
6. Shows PostgreSQL-specific implementation details

### Tutorial Structure

This tutorial is divided into episodes, each focusing on a specific aspect of building a data warehouse with dbt:

1. Setting Up Your Environment
2. Understanding the Data Model
3. Loading Test Data
4. dbt Project Configuration
5. Building Staging Models
6. Creating Intermediate Models
7. Developing Dimensional Models
8. Building Fact Tables
9. Documentation and Testing
10. Running the Complete Pipeline
11. Extending the Project
12. Troubleshooting and Best Practices

Let's get started with setting up your environment in the next section!
