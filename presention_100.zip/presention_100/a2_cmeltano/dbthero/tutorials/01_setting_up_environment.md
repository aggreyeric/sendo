# Episode 1: Setting Up Your Environment

## Introduction

Before we can start building our data warehouse, we need to set up our development environment. This episode covers everything you need to get started with the DBT Hero project.

## Prerequisites

- A computer with Windows, macOS, or Linux
- Administrative access to install software
- Internet connection to download packages

## Installing PostgreSQL

PostgreSQL is our database of choice for this project. Here's how to set it up:

### Windows Installation

1. Download the installer from [postgresql.org](https://www.postgresql.org/download/windows/)
2. Run the installer and follow the prompts
3. Set a password for the 'postgres' user
4. Keep the default port (5432)
5. Complete the installation

### Using Docker/Podman

If you prefer containers, you can use this command:

```bash
# For Docker
docker run -d --name postgres -e POSTGRES_PASSWORD=password -p 5432:5432 postgres:14

# For Podman
podman run -d --name postgres -e POSTGRES_PASSWORD=password -p 5432:5432 postgres:14
```

### Verifying Installation

Test your PostgreSQL installation:

```bash
# For direct installation
psql -U postgres -c "SELECT version();"

# For Docker/Podman
docker exec -it postgres psql -U postgres -c "SELECT version();"
```

## Installing dbt

Now let's install dbt with the PostgreSQL adapter:

```bash
# Create a virtual environment (recommended)
python -m venv dbt-env
source dbt-env/bin/activate  # On Windows: dbt-env\Scripts\activate

# Install dbt
pip install dbt-postgres==1.9.0
```

Verify the installation:

```bash
dbt --version
```

You should see output showing dbt Core version 1.10.5 and the PostgreSQL adapter.

## Setting Up the Project

### Cloning the Repository

Clone the DBT Hero repository:

```bash
git clone https://github.com/yourusername/dbthero.git
cd dbthero
```

### Project Structure

Let's explore the project structure:

```
dbthero/
├── dbthero/              # dbt project directory
│   ├── dbt_project.yml   # Project configuration
│   ├── packages.yml      # Package dependencies
│   ├── models/           # SQL models
│   │   ├── staging/      # Staging models
│   │   ├── intermediate/ # Intermediate models
│   │   └── marts/        # Dimensional models
│   ├── macros/          # Reusable SQL snippets
│   └── tests/           # Custom tests
└── tables/              # Data loading utilities
```

## Configuring dbt Profiles

dbt needs to know how to connect to your database. Create a profiles.yml file:

1. Copy the template:

```bash
mkdir -p ~/.dbt
cp dbthero/profiles_template.yml ~/.dbt/profiles.yml
```

2. Edit ~/.dbt/profiles.yml to match your database settings:

```yaml
dbthero:
  target: dev
  outputs:
    dev:
      type: postgres
      host: localhost
      user: postgres
      password: your_password_here
      port: 5432
      dbname: dbthero
      schema: public
      threads: 4
```

## Creating the Database

Create the dbthero database:

```bash
psql -U postgres -c "CREATE DATABASE dbthero;"
```

## Testing the Setup

Let's make sure everything is working:

```bash
cd dbthero
dbt debug
```

If everything is configured correctly, you should see all checks passing.

Install dependencies:

```bash
dbt deps
```

## Common Issues and Solutions

### Connection Errors

If you see connection errors:
- Check that PostgreSQL is running
- Verify your username and password
- Ensure the database exists
- Check your firewall settings

### dbt Installation Issues

If dbt installation fails:
- Make sure you have Python 3.8+
- Try upgrading pip: `pip install --upgrade pip`
- Check for conflicting packages

## Next Steps

Congratulations! You now have a fully configured environment for the DBT Hero project. In the next episode, we'll explore the data model and understand how we'll transform our OLTP data into a dimensional data warehouse.

## Code Example: Testing Your Setup

Create a file called `test_connection.sql` in your project:

```sql
-- test_connection.sql
select 
    current_database() as database_name,
    current_user as username,
    version() as postgres_version
```

Run it with dbt:

```bash
dbt run-operation run_query --args '{query: "select current_database(), current_user, version()"}'
```

You should see output confirming your connection to the dbthero database.
