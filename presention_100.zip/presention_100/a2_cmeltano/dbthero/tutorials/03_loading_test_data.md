# Episode 3: Loading Test Data

## Introduction

To build and test our data warehouse, we need realistic data. In this episode, we'll explore the data loading utility included with DBT Hero that generates and loads test data into our PostgreSQL database.

## The LoadData Utility

DBT Hero includes a Python-based data loading utility that generates realistic fake data with proper relationships. Let's examine how it works.

### Understanding the LoadData Class

The LoadData class is located in `tables/load.py`. It handles:
- Creating database tables
- Generating realistic fake data
- Maintaining referential integrity
- Incremental loading

Let's look at the key components:

```python
class LoadData:
    def __init__(self, engine):
        self.engine = engine
        self.fake = Faker()
        self.session = sessionmaker(bind=engine)()
        
    def load_states(self, count=50):
        # Generate state data
        
    def load_customers(self, count=200):
        # Generate customer data with references to states
        
    def load_product_categories(self, count=10):
        # Generate product categories
        
    def load_products(self, count=100):
        # Generate products with references to categories
        
    # Additional methods for other entities
```

## Setting Up the Database

Before loading data, we need to set up our database:

```python
from sqlalchemy import create_engine
from tables.models import metadata

# Create database engine
engine = create_engine('postgresql://postgres:password@localhost:5432/dbthero')

# Create tables
metadata.create_all(engine)
```

## Loading Test Data

Now let's load data using our utility:

```python
from tables.load import LoadData

# Initialize data loader
loader = LoadData(engine)

# Load reference data
loader.load_states(50)
loader.load_product_categories(10)

# Load entity data
loader.load_customers(200)
loader.load_products(100)
loader.load_suppliers(30)
loader.load_employees(40)

# Load transaction data
loader.load_orders(300)
loader.load_order_items(1000)
loader.load_inventory_transactions(200)
loader.load_payments(300)
```

## Running the Data Loader

To run the data loader:

1. Navigate to the project directory:
```bash
cd F:\dbtProjects\dbthero
```

2. Run the loader script:
```bash
python -m tables.load
```

## Verifying the Data

After loading, let's verify our data:

```sql
-- Check customer count
SELECT COUNT(*) FROM customers;

-- Check product count
SELECT COUNT(*) FROM products;

-- Check order count
SELECT COUNT(*) FROM orders;

-- Check relationships
SELECT 
    c.first_name || ' ' || c.last_name AS customer_name,
    COUNT(o.order_id) AS order_count
FROM 
    customers c
    LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY 
    c.customer_id, c.first_name, c.last_name
ORDER BY 
    order_count DESC
LIMIT 10;
```

## Understanding the Generated Data

The LoadData utility creates realistic data with these characteristics:

1. **Realistic Values**: Names, addresses, emails, and phone numbers look real
2. **Proper Relationships**: Foreign keys maintain referential integrity
3. **Reasonable Distributions**: Order quantities, prices, and dates have realistic distributions
4. **Consistent State**: Data is internally consistent (e.g., order totals match line items)

## Handling Data Loading Issues

### Common Issues and Solutions

1. **Connection Errors**:
   - Verify PostgreSQL is running
   - Check connection string parameters

2. **Duplicate Key Errors**:
   - Clear existing data before reloading
   - Use the truncate option in the loader

3. **Missing Dependencies**:
   - Install required Python packages:
   ```bash
   pip install sqlalchemy faker psycopg2-binary
   ```

### Truncating Data for Fresh Start

If you need to clear existing data:

```python
# Drop all tables and recreate
metadata.drop_all(engine)
metadata.create_all(engine)
```

## Important Database Schema Details

When working with the loaded data, be aware of these specific details:

1. The orders table doesn't have employee_id, required_date, or shipped_date columns
2. The products table doesn't have a supplier_id column but has cost and sku columns
3. The states table uses 'id' as the primary key instead of 'state_id'

## Next Steps

Now that we have data loaded, in the next episode we'll configure our dbt project to transform this OLTP data into a dimensional data warehouse.

## Code Example: Custom Data Generation

If you want to customize the data generation, you can extend the LoadData class:

```python
class CustomLoadData(LoadData):
    def load_products(self, count=100):
        """Override to create specialized product data"""
        products = []
        categories = self.session.query(ProductCategory).all()
        
        for _ in range(count):
            product = Product(
                name=f"{self.fake.color()} {self.fake.word()} {random.choice(['Pro', 'Max', 'Ultra', 'Basic'])}",
                description=self.fake.paragraph(),
                category_id=random.choice(categories).category_id,
                price=round(random.uniform(10, 1000), 2),
                cost=round(random.uniform(5, 800), 2),
                sku=f"SKU-{self.fake.bothify('???-####')}",
                inventory_quantity=random.randint(0, 100),
                created_at=self.fake.date_time_between(start_date="-1y"),
                updated_at=self.fake.date_time_between(start_date="-6m")
            )
            products.append(product)
            
        self.session.add_all(products)
        self.session.commit()
        return products
```
