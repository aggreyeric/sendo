# Episode 8: Building Fact Tables

## Introduction

Fact tables are the heart of our dimensional model, containing the measures and metrics that drive business analysis. In this episode, we'll create fact tables that connect to our dimension tables and provide a comprehensive view of our business processes.

## Understanding Fact Tables

Fact tables have these key characteristics:

1. **Measures**: Numerical values that can be aggregated (sums, averages, counts)
2. **Foreign Keys**: References to dimension tables
3. **Grain**: The level of detail represented by each row
4. **Additive**: Values that can be summed across dimensions
5. **Materialized as Tables**: Usually materialized as tables for query performance

## Creating the Sales Fact Table

Let's create a sales fact table that captures order transactions:

```sql
-- models/marts/core/fact_sales.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with orders as (
    select * from {{ ref('int_orders_with_details') }}
),

order_items as (
    select * from {{ ref('int_order_items_with_products') }}
),

-- Generate date key for joining to date dimension
order_dates as (
    select
        order_id,
        to_char(order_date, 'YYYYMMDD')::int as order_date_key
    from orders
),

final as (
    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['oi.order_item_id']) }} as sales_key,
        
        -- Foreign keys to dimensions
        oi.order_id,
        oi.product_id,
        o.customer_id,
        od.order_date_key,
        
        -- Transaction details
        o.order_date,
        o.order_status,
        o.payment_method,
        
        -- Measures
        oi.quantity,
        oi.unit_price,
        oi.line_total,
        
        -- Additional measures
        (oi.unit_price * oi.quantity) as gross_amount,
        
        -- Shipping and tax (allocated proportionally to each line item)
        (o.shipping_amount * (oi.line_total / o.order_total)) as allocated_shipping_amount,
        (o.tax_amount * (oi.line_total / o.order_total)) as allocated_tax_amount,
        
        -- Total amount
        (oi.line_total + 
         (o.shipping_amount * (oi.line_total / o.order_total)) + 
         (o.tax_amount * (oi.line_total / o.order_total))) as total_amount
    from order_items oi
    inner join orders o on oi.order_id = o.order_id
    inner join order_dates od on o.order_id = od.order_id
)

select * from final
```

Notice that we're using `dbt_utils.generate_surrogate_key()` to create a unique key for each sales record. We're also allocating shipping and tax amounts proportionally to each line item.

## Creating the Inventory Fact Table

Let's create an inventory fact table that captures inventory movements:

```sql
-- models/marts/core/fact_inventory.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with inventory_transactions as (
    select * from {{ ref('stg_sales_oltp__inventory_transactions') }}
),

products as (
    select * from {{ ref('dim_product') }}
),

-- Generate date key for joining to date dimension
transaction_dates as (
    select
        transaction_id,
        to_char(transaction_date, 'YYYYMMDD')::int as transaction_date_key
    from inventory_transactions
),

final as (
    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['it.transaction_id']) }} as inventory_key,
        
        -- Foreign keys to dimensions
        it.transaction_id,
        it.product_id,
        td.transaction_date_key,
        
        -- Transaction details
        it.transaction_date,
        it.transaction_type,
        
        -- Measures
        it.quantity,
        
        -- Additional measures with product cost
        p.cost as unit_cost,
        (p.cost * it.quantity) as total_cost,
        
        -- Movement direction
        case
            when it.transaction_type = 'purchase' then 1
            when it.transaction_type = 'sale' then -1
            when it.transaction_type = 'return' then 1
            when it.transaction_type = 'adjustment' then 
                case when it.quantity > 0 then 1 else -1 end
            else 0
        end as movement_direction,
        
        -- Adjusted quantity (positive for inflow, negative for outflow)
        case
            when it.transaction_type = 'purchase' then it.quantity
            when it.transaction_type = 'sale' then -1 * it.quantity
            when it.transaction_type = 'return' then it.quantity
            else it.quantity
        end as adjusted_quantity,
        
        -- Adjusted cost value
        case
            when it.transaction_type = 'purchase' then p.cost * it.quantity
            when it.transaction_type = 'sale' then -1 * p.cost * it.quantity
            when it.transaction_type = 'return' then p.cost * it.quantity
            else p.cost * it.quantity
        end as adjusted_cost_value
    from inventory_transactions it
    inner join products p on it.product_id = p.product_id
    inner join transaction_dates td on it.transaction_id = td.transaction_id
)

select * from final
```

Notice that we're calculating adjusted quantities and cost values based on the transaction type. We're also using the product cost from the product dimension to calculate the total cost of each transaction.

## Creating the Payment Fact Table

Let's create a payment fact table that captures payment transactions:

```sql
-- models/marts/core/fact_payments.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with payments as (
    select * from {{ ref('stg_sales_oltp__payments') }}
),

orders as (
    select * from {{ ref('stg_sales_oltp__orders') }}
),

-- Generate date key for joining to date dimension
payment_dates as (
    select
        payment_id,
        to_char(payment_date, 'YYYYMMDD')::int as payment_date_key
    from payments
),

final as (
    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['p.payment_id']) }} as payment_key,
        
        -- Foreign keys to dimensions
        p.payment_id,
        p.order_id,
        o.customer_id,
        pd.payment_date_key,
        
        -- Transaction details
        p.payment_date,
        p.payment_method,
        p.payment_status,
        
        -- Measures
        p.amount,
        
        -- Additional measures
        case
            when p.payment_status = 'Completed' then p.amount
            else 0
        end as completed_amount,
        
        case
            when p.payment_status = 'Failed' then p.amount
            else 0
        end as failed_amount,
        
        case
            when p.payment_status = 'Pending' then p.amount
            else 0
        end as pending_amount
    from payments p
    inner join orders o on p.order_id = o.order_id
    inner join payment_dates pd on p.payment_id = pd.payment_id
)

select * from final
```

## Documenting Fact Tables

Add documentation for your fact tables in a schema.yml file:

```yaml
# models/marts/core/schema.yml

version: 2

models:
  - name: fact_sales
    description: Sales fact table at the order line item grain
    columns:
      - name: sales_key
        description: Primary key
        tests:
          - unique
          - not_null
      - name: order_id
        description: Foreign key to orders
      - name: product_id
        description: Foreign key to products
        tests:
          - relationships:
              to: ref('dim_product')
              field: product_id
      - name: customer_id
        description: Foreign key to customers
        tests:
          - relationships:
              to: ref('dim_customer')
              field: customer_id
      - name: order_date_key
        description: Foreign key to date dimension
        tests:
          - relationships:
              to: ref('dim_date')
              field: date_key

  - name: fact_inventory
    description: Inventory movement fact table
    columns:
      - name: inventory_key
        description: Primary key
        tests:
          - unique
          - not_null
      - name: product_id
        description: Foreign key to products
        tests:
          - relationships:
              to: ref('dim_product')
              field: product_id

  # Additional model definitions...
```

## Running Fact Models

Run your fact models with:

```bash
dbt run --select marts.core.fact_*
```

Or run a specific model:

```bash
dbt run --select fact_sales
```

## Best Practices for Fact Tables

1. **Define Clear Grain**: Specify the level of detail for each fact table
2. **Use Surrogate Keys**: Generate unique keys for each fact record
3. **Include Foreign Keys**: Reference all relevant dimension tables
4. **Document Measures**: Explain what each measure represents
5. **Test Relationships**: Ensure foreign keys match dimension primary keys
6. **Materialize as Tables**: Fact tables should be materialized as tables
7. **Consider Incremental Loads**: For large fact tables, use incremental materialization

## Incremental Fact Tables

For large fact tables that grow over time, consider using incremental materialization:

```sql
-- models/marts/core/fact_sales_incremental.sql

{{
    config(
        materialized='incremental',
        schema='dwh',
        unique_key='sales_key',
        incremental_strategy='delete+insert'
    )
}}

with orders as (
    select * from {{ ref('int_orders_with_details') }}
    {% if is_incremental() %}
    where order_date > (select max(order_date) from {{ this }})
    {% endif %}
),

-- Rest of the model remains the same...
```

This approach only processes new records since the last run, making builds much faster.

## Next Steps

With our fact and dimension tables complete, in the next episode we'll learn how to test our models to ensure data quality and integrity.

## Code Example: Analyzing Sales Data

After creating your fact tables, you can analyze them with this query:

```sql
-- Query to analyze sales by product category and month
SELECT
    d.year,
    d.month,
    d.month_name,
    p.category_name,
    SUM(f.quantity) AS total_quantity,
    SUM(f.line_total) AS total_sales
FROM
    {{ ref('fact_sales') }} f
    JOIN {{ ref('dim_product') }} p ON f.product_id = p.product_id
    JOIN {{ ref('dim_date') }} d ON f.order_date_key = d.date_key
GROUP BY
    d.year, d.month, d.month_name, p.category_name
ORDER BY
    d.year, d.month, total_sales DESC
```
