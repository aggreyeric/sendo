# Episode 4: dbt Project Configuration

## Introduction

A well-configured dbt project is the foundation for successful data transformations. In this episode, we'll explore the configuration files that define how our DBT Hero project works.

## The dbt_project.yml File

The `dbt_project.yml` file is the heart of any dbt project. It defines project settings, model configurations, and materialization strategies.

Let's examine our project configuration:

```yaml
# dbt_project.yml

name: 'dbthero'
version: '1.0.0'
config-version: 2

# This setting configures which "profile" dbt uses for this project.
profile: 'dbthero'

# These directories tell dbt where to find different types of files
model-paths: ["models"]
analysis-paths: ["analyses"]
test-paths: ["tests"]
seed-paths: ["seeds"]
macro-paths: ["macros"]
snapshot-paths: ["snapshots"]

target-path: "target"  # directory which will store compiled SQL files
clean-targets:         # directories to be removed by `dbt clean`
  - "target"
  - "dbt_packages"

# Configuring models
models:
  dbthero:
    # Staging models configuration
    staging:
      +materialized: view
      +schema: staging
    
    # Intermediate models configuration
    intermediate:
      +materialized: view
      +schema: intermediate
      
    # Marts models configuration
    marts:
      +materialized: table
      +schema: dwh
```

### Key Configuration Elements

1. **Project Name and Version**: Identifies your project
2. **Profile**: Connects to the profile in `~/.dbt/profiles.yml`
3. **Directory Paths**: Tells dbt where to find different file types
4. **Model Configurations**: Sets materialization strategy and schema for each model layer

## Understanding Materialization Strategies

dbt supports different materialization strategies:

1. **View**: Creates a SQL view (no data storage)
   - Good for: Staging and intermediate models
   - Benefits: Always up-to-date, no storage cost
   - Drawbacks: Can be slower for complex queries

2. **Table**: Creates a physical table with data
   - Good for: Final dimensional models (facts and dimensions)
   - Benefits: Better query performance
   - Drawbacks: Needs to be refreshed to update data

3. **Incremental**: Updates only new/changed data
   - Good for: Large fact tables with frequent updates
   - Benefits: Faster builds after initial load
   - Drawbacks: More complex to implement

4. **Ephemeral**: Exists only as a CTE in other models
   - Good for: Simple transformations used in only one model
   - Benefits: Simplifies dependency tree
   - Drawbacks: Can't be directly queried

In our project, we use views for staging and intermediate models and tables for our final dimensional models.

## The packages.yml File

The `packages.yml` file defines external packages that our project depends on:

```yaml
# packages.yml

packages:
  - package: dbt-labs/dbt_utils
    version: 1.1.1
```

We're using the `dbt_utils` package, which provides helpful macros like:
- `generate_surrogate_key()`: Creates surrogate keys for dimension tables
- `date_spine()`: Generates date dimension tables
- Various test macros for data validation

## Creating Custom Macros

Macros are reusable SQL snippets that make your dbt code more maintainable. Let's look at our schema creation macro:

```sql
-- macros/create_schemas.sql

{% macro create_schemas() %}
    {% set create_staging_schema %}
        CREATE SCHEMA IF NOT EXISTS staging;
    {% endset %}
    
    {% set create_intermediate_schema %}
        CREATE SCHEMA IF NOT EXISTS intermediate;
    {% endset %}
    
    {% set create_dwh_schema %}
        CREATE SCHEMA IF NOT EXISTS dwh;
    {% endset %}
    
    {% do run_query(create_staging_schema) %}
    {% do run_query(create_intermediate_schema) %}
    {% do run_query(create_dwh_schema) %}
    
    {{ log("Created schemas if they didn't exist", info=True) }}
{% endmacro %}
```

## Using On-Run Hooks

On-run hooks execute code at specific points in the dbt run lifecycle:

```sql
-- macros/on_run_start.sql

{% macro on_run_start() %}
    {{ create_schemas() }}
{% endmacro %}
```

This macro creates our schemas automatically at the start of each dbt run.

## Setting Up Profiles

The `profiles.yml` file contains database connection information:

```yaml
# ~/.dbt/profiles.yml

dbthero:
  target: dev
  outputs:
    dev:
      type: postgres
      host: localhost
      user: postgres
      password: your_password_here
      port: 5432
      dbname: dbthero
      schema: public
      threads: 4
```

We provide a template (`profiles_template.yml`) that users can customize:

```yaml
# profiles_template.yml

dbthero:
  target: dev
  outputs:
    dev:
      type: postgres
      host: localhost
      user: postgres
      password: <your-password>
      port: 5432
      dbname: dbthero
      schema: public
      threads: 4
```

## Automation with setup_and_run.ps1

We've created a PowerShell script to automate common tasks:

```powershell
# setup_and_run.ps1

# Install dependencies
Write-Host "Installing dependencies..." -ForegroundColor Green
dbt deps

# Create schemas
Write-Host "Creating schemas..." -ForegroundColor Green
dbt run-operation create_schemas

# Run models by layer
Write-Host "Running staging models..." -ForegroundColor Green
dbt run --select staging

Write-Host "Running intermediate models..." -ForegroundColor Green
dbt run --select intermediate

Write-Host "Running mart models..." -ForegroundColor Green
dbt run --select marts

# Run tests
Write-Host "Running tests..." -ForegroundColor Green
dbt test

Write-Host "Setup and run complete!" -ForegroundColor Green
```

## Adapting for Podman Instead of Docker

If you're using Podman instead of Docker, you can create PowerShell aliases to map Docker commands to Podman:

```powershell
# Add to your PowerShell profile
function Docker-To-Podman {
    param (
        [Parameter(ValueFromRemainingArguments = $true)]
        $arguments
    )
    
    $cmdLine = $arguments -join " "
    
    # Handle 'docker compose' vs 'podman compose'
    if ($cmdLine -like "compose*") {
        $cmdLine = $cmdLine -replace "^compose", ""
        $finalCmd = "podman compose$cmdLine"
    } else {
        $finalCmd = "podman $cmdLine"
    }
    
    Invoke-Expression $finalCmd
}

Set-Alias -Name docker -Value Docker-To-Podman -Option AllScope
Write-Host "Docker commands are now mapped to Podman via PowerShell alias" -ForegroundColor Green
```

## Next Steps

With our project properly configured, in the next episode we'll start building our staging models to transform the raw source data.

## Code Example: Custom Configuration

Here's how to add custom configurations for specific models:

```yaml
# dbt_project.yml

models:
  dbthero:
    # Special configuration for large fact tables
    marts:
      core:
        fact_sales:
          +materialized: incremental
          +incremental_strategy: delete+insert
          +unique_key: sales_key
```
