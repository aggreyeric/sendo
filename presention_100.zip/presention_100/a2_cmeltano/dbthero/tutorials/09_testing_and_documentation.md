# Episode 9: Testing and Documentation

## Introduction

Data quality is crucial for a successful data warehouse. In this episode, we'll explore how to test and document our dbt models to ensure accuracy and reliability.

## Understanding dbt Tests

dbt provides two types of tests:

1. **Schema Tests**: Generic tests applied to columns in your models
2. **Custom Tests**: SQL queries that return failing records

Tests help you:
- Validate data quality
- Catch errors early
- Document assumptions
- Build trust in your data

## Adding Schema Tests

Schema tests are defined in YAML files. Let's add tests to our models:

```yaml
# models/marts/core/schema.yml

version: 2

models:
  - name: dim_customer
    description: Customer dimension table
    columns:
      - name: customer_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: email
        description: Customer email address
        tests:
          - unique
          - not_null

  - name: fact_sales
    description: Sales fact table at the order line item grain
    columns:
      - name: sales_key
        description: Primary key
        tests:
          - unique
          - not_null
      - name: product_id
        description: Foreign key to products
        tests:
          - relationships:
              to: ref('dim_product')
              field: product_id
      - name: customer_id
        description: Foreign key to customers
        tests:
          - relationships:
              to: ref('dim_customer')
              field: customer_id
      - name: quantity
        description: Quantity sold
        tests:
          - not_null
          - positive_values
```

## Common Schema Tests

dbt includes these built-in schema tests:

1. **unique**: Ensures values in a column are unique
2. **not_null**: Ensures a column contains no NULL values
3. **relationships**: Ensures referential integrity between tables
4. **accepted_values**: Ensures values are from a specified list

## Creating Custom Tests

Custom tests are SQL queries that return failing records. Let's create a test to ensure order totals match line item totals:

```sql
-- tests/assert_order_totals_match_line_items.sql

-- This test checks that order totals match the sum of line items
with order_totals as (
    select
        order_id,
        order_total
    from {{ ref('stg_sales_oltp__orders') }}
),

line_item_totals as (
    select
        order_id,
        sum(line_total) as calculated_total
    from {{ ref('stg_sales_oltp__order_items') }}
    group by order_id
),

final as (
    select
        ot.order_id,
        ot.order_total,
        lit.calculated_total,
        abs(ot.order_total - lit.calculated_total) as difference
    from order_totals ot
    inner join line_item_totals lit on ot.order_id = lit.order_id
    where abs(ot.order_total - lit.calculated_total) > 0.01
)

select * from final
```

This test will fail if any order's total doesn't match the sum of its line items (allowing for small rounding differences).

## Creating a Custom Generic Test

You can also create reusable generic tests as macros:

```sql
-- macros/test_positive_values.sql

{% test positive_values(model, column_name) %}

select
    *
from {{ model }}
where {{ column_name }} <= 0

{% endtest %}
```

This creates a `positive_values` test that you can apply to any numeric column.

## Running Tests

Run all tests with:

```bash
dbt test
```

Run tests for specific models:

```bash
dbt test --select dim_customer
```

## Documenting Your Models

Documentation helps users understand your data warehouse. dbt supports two types of documentation:

1. **YAML Documentation**: Structured descriptions in schema.yml files
2. **Markdown Documentation**: Detailed explanations in .md files

Let's create comprehensive documentation:

```yaml
# models/marts/core/schema.yml

version: 2

models:
  - name: dim_customer
    description: |
      Customer dimension table containing all customer attributes.
      This dimension uses Type 1 SCD (overwrite) for all attributes.
    columns:
      - name: customer_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: full_name
        description: Customer's full name (first name + last name)
      - name: email
        description: Customer's email address
      - name: customer_category
        description: |
          Customer categorization based on tenure:
          - New: Less than 3 months
          - Regular: 3 months to 1 year
          - Established: More than 1 year
```

## Adding Detailed Documentation

Create a markdown file with detailed documentation:

```markdown
<!-- models/marts/core/dim_customer.md -->

{% docs dim_customer %}

# Customer Dimension

This table contains all customer attributes in a denormalized format.

## Business Rules

- Customer categories are determined by tenure:
  - New: Less than 3 months
  - Regular: 3 months to 1 year
  - Established: More than 1 year
- All customer attributes use Type 1 SCD (overwrite) methodology
- Email addresses are unique per customer

## Common Joins

This dimension is commonly joined to:
- `fact_sales` on `customer_id`
- `fact_payments` on `customer_id`

## Example Query

```sql
SELECT
    c.full_name,
    c.state_name,
    COUNT(s.order_id) AS order_count,
    SUM(s.total_amount) AS total_spent
FROM
    dim_customer c
    LEFT JOIN fact_sales s ON c.customer_id = s.customer_id
GROUP BY
    c.full_name, c.state_name
ORDER BY
    total_spent DESC
```

{% enddocs %}
```

Reference this documentation in your schema.yml:

```yaml
# models/marts/core/schema.yml

version: 2

models:
  - name: dim_customer
    description: "{{ doc('dim_customer') }}"
    # Rest of the model definition...
```

## Generating Documentation Site

Generate a documentation site with:

```bash
dbt docs generate
```

Serve the documentation locally:

```bash
dbt docs serve
```

This creates an interactive website with:
- Model lineage graphs
- Column descriptions
- Test information
- Markdown documentation

## Best Practices for Testing and Documentation

1. **Test Critical Assumptions**: Focus on key business rules and data integrity
2. **Document Business Context**: Explain business rules, not just technical details
3. **Use Consistent Naming**: Follow a naming convention for tests and docs
4. **Include Example Queries**: Show how to use your models
5. **Keep Documentation Updated**: Update docs when models change
6. **Test Across Layers**: Test at staging, intermediate, and marts layers
7. **Document Data Sources**: Include information about source systems

## Next Steps

With our models tested and documented, in the next episode we'll explore how to optimize our dbt project for performance and maintainability.

## Code Example: Creating a Data Quality Dashboard

You can create a data quality dashboard by querying dbt test results:

```sql
-- Query to create a data quality dashboard
SELECT
    test_name,
    model_name,
    status,
    message,
    failures
FROM
    {{ ref('dbt_test_results') }}
WHERE
    status = 'fail'
ORDER BY
    failures DESC
```

Note: This requires setting up a test results table, which can be done with a custom macro.
