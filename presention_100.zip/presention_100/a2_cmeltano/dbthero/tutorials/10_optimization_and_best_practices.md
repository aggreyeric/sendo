# Episode 10: Optimization and Best Practices

## Introduction

A well-optimized dbt project runs efficiently and is easy to maintain. In this episode, we'll explore best practices for optimizing your dbt project's performance, structure, and maintainability.

## Optimizing Model Materialization

Choosing the right materialization strategy is crucial for performance:

### View vs. Table vs. Incremental

```yaml
# models/marts/core/dim_customer.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}
```

Guidelines for choosing materializations:

1. **Views**:
   - Use for: Staging models, simple transformations
   - Pros: Always up-to-date, no storage cost
   - Cons: Can be slower for complex queries

2. **Tables**:
   - Use for: Dimension tables, small fact tables
   - Pros: Better query performance
   - Cons: Needs full refresh to update

3. **Incremental**:
   - Use for: Large fact tables with frequent updates
   - Pros: Faster builds after initial load
   - Cons: More complex to implement

Example of incremental model:

```sql
-- models/marts/core/fact_sales_incremental.sql

{{
    config(
        materialized='incremental',
        unique_key='sales_key',
        incremental_strategy='delete+insert'
    )
}}

with orders as (
    select * from {{ ref('int_orders_with_details') }}
    {% if is_incremental() %}
    where order_date > (select max(order_date) from {{ this }})
    {% endif %}
),

-- Rest of the model remains the same...
```

## Optimizing Query Performance

### Using Indexes

For materialized tables, consider adding indexes:

```sql
-- models/marts/core/dim_customer.sql

{{
    config(
        materialized='table',
        schema='dwh',
        post_hook=[
            "CREATE INDEX IF NOT EXISTS idx_dim_customer_email ON {{ this }}(email)",
            "CREATE INDEX IF NOT EXISTS idx_dim_customer_state ON {{ this }}(state_name)"
        ]
    )
}}
```

### Partitioning Large Tables

For very large fact tables, consider partitioning:

```sql
-- models/marts/core/fact_sales.sql

{{
    config(
        materialized='table',
        schema='dwh',
        post_hook=[
            "CREATE INDEX IF NOT EXISTS idx_fact_sales_date ON {{ this }}(order_date)"
        ]
    )
}}
```

In PostgreSQL, you can use table partitioning for very large tables:

```sql
-- Example of PostgreSQL partitioning (would be implemented in a post-hook)
CREATE TABLE fact_sales_partitioned (
    sales_key text,
    order_id int,
    product_id int,
    customer_id int,
    order_date date,
    -- other columns...
) PARTITION BY RANGE (order_date);

CREATE TABLE fact_sales_y2023m01 PARTITION OF fact_sales_partitioned
    FOR VALUES FROM ('2023-01-01') TO ('2023-02-01');

CREATE TABLE fact_sales_y2023m02 PARTITION OF fact_sales_partitioned
    FOR VALUES FROM ('2023-02-01') TO ('2023-03-01');

-- Additional partitions...
```

## Project Structure Best Practices

### Organizing Models

Follow a consistent directory structure:

```
models/
├── staging/           # One directory per source
│   ├── sales_oltp/    # Source-specific staging models
│   └── marketing/     # Another source
├── intermediate/      # Joined and enriched models
└── marts/             # Final dimensional models
    ├── core/          # Core business concepts
    └── marketing/     # Department-specific models
```

### Naming Conventions

Follow consistent naming conventions:

1. **Staging Models**: `stg_[source]__[entity]`
2. **Intermediate Models**: `int_[entity]_[verb]`
3. **Dimension Tables**: `dim_[entity]`
4. **Fact Tables**: `fact_[business_process]`

## Code Reusability

### Creating Macros

Macros help you avoid repeating code:

```sql
-- macros/get_column_values.sql

{% macro get_column_values(table, column, max_records=none) %}

{% set query %}
select distinct
    {{ column }} as value
from {{ table }}
where {{ column }} is not null
{% if max_records is not none %}
limit {{ max_records }}
{% endif %}
{% endset %}

{% set results = run_query(query) %}

{% if execute %}
{% set results_list = results.columns[0].values() %}
{% else %}
{% set results_list = [] %}
{% endif %}

{{ return(results_list) }}

{% endmacro %}
```

Using the macro:

```sql
-- Example usage
{% set payment_methods = get_column_values(ref('stg_sales_oltp__orders'), 'payment_method') %}

{% for payment_method in payment_methods %}
    select
        '{{ payment_method }}' as payment_method,
        count(*) as order_count
    from {{ ref('stg_sales_oltp__orders') }}
    where payment_method = '{{ payment_method }}'
    {% if not loop.last %} union all {% endif %}
{% endfor %}
```

### Using Packages

Leverage community packages to avoid reinventing the wheel:

```yaml
# packages.yml

packages:
  - package: dbt-labs/dbt_utils
    version: 1.1.1
  - package: calogica/dbt_expectations
    version: 0.8.0
  - package: dbt-labs/audit_helper
    version: 0.6.0
```

## Performance Monitoring

### Logging Query Performance

Create a macro to log query performance:

```sql
-- macros/log_query_performance.sql

{% macro log_query_performance() %}
  {% if execute %}
    {% set query_log %}
      insert into query_log (
        model_name,
        query_duration_seconds,
        rows_affected,
        run_at
      )
      values (
        '{{ this.name }}',
        {{ status.elapsed }},
        {{ status.rows_affected }},
        current_timestamp
      )
    {% endset %}
    {% do run_query(query_log) %}
  {% endif %}
{% endmacro %}
```

Add it to your model:

```sql
-- models/marts/core/dim_customer.sql

{{
    config(
        materialized='table',
        schema='dwh',
        post_hook="{{ log_query_performance() }}"
    )
}}
```

## CI/CD Integration

### Setting Up dbt in CI/CD

Create a GitHub Actions workflow:

```yaml
# .github/workflows/dbt.yml

name: dbt CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  dbt:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install dbt-postgres==1.9.0
    
    - name: Configure dbt profile
      run: |
        mkdir -p ~/.dbt
        cp ci/profiles.yml ~/.dbt/profiles.yml
    
    - name: Run dbt tests
      run: |
        dbt deps
        dbt compile
        dbt test
```

## Optimizing for PostgreSQL

### PostgreSQL-Specific Optimizations

1. **Use EXPLAIN ANALYZE**: Analyze query performance

```sql
EXPLAIN ANALYZE
SELECT * FROM {{ ref('fact_sales') }}
WHERE order_date BETWEEN '2023-01-01' AND '2023-01-31';
```

2. **Optimize Joins**: Ensure join columns have indexes

```sql
-- Add index to join columns
CREATE INDEX idx_fact_sales_customer_id ON {{ this }}(customer_id);
```

3. **Use VACUUM**: Regularly vacuum large tables

```sql
-- Add as a post-hook for large tables
{{ config(
    post_hook="VACUUM {{ this }}"
) }}
```

4. **Use ANALYZE**: Update statistics for the query planner

```sql
-- Add as a post-hook
{{ config(
    post_hook="ANALYZE {{ this }}"
) }}
```

## Best Practices Summary

1. **Choose Appropriate Materialization**:
   - Views for staging models
   - Tables for dimensions
   - Incremental for large facts

2. **Optimize Query Performance**:
   - Add indexes on join and filter columns
   - Partition very large tables
   - Use appropriate data types

3. **Follow Consistent Structure**:
   - Organize models by layer and domain
   - Use consistent naming conventions
   - Document models and tests

4. **Leverage Reusability**:
   - Create macros for repeated patterns
   - Use community packages
   - Create utility functions

5. **Monitor Performance**:
   - Log query execution times
   - Analyze slow-running models
   - Optimize based on usage patterns

## Next Steps

With our project optimized, in the next episode we'll explore advanced dbt features like exposures, analyses, and snapshots.

## Code Example: Performance Analysis

Create a query to analyze model performance:

```sql
-- analyses/model_performance.sql

with model_stats as (
    select
        model_name,
        avg(query_duration_seconds) as avg_duration,
        max(query_duration_seconds) as max_duration,
        min(query_duration_seconds) as min_duration,
        count(*) as run_count
    from query_log
    where run_at > current_date - interval '7 days'
    group by model_name
)

select
    model_name,
    avg_duration,
    max_duration,
    min_duration,
    run_count
from model_stats
order by avg_duration desc
limit 10
```
