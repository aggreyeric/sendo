# Episode 12: Deployment and Scheduling

## Introduction

A data warehouse is only valuable if it's regularly updated with fresh data. In this final episode, we'll explore how to deploy and schedule your dbt project for production use.

## Deployment Options

There are several ways to deploy dbt in production:

1. **Manual Execution**: Running dbt commands directly
2. **Scheduled Scripts**: Using task schedulers like cron or Windows Task Scheduler
3. **Orchestration Tools**: Using tools like Airflow, Dagster, or Prefect
4. **dbt Cloud**: Using dbt's managed service

Let's explore each option.

## Manual Execution with PowerShell Scripts

For simple deployments, you can create a PowerShell script:

```powershell
# run_production.ps1

# Set environment variables
$env:DBT_PROFILES_DIR = "~/.dbt"
$env:DBT_TARGET = "prod"

# Log start time
$startTime = Get-Date
Write-Host "Starting dbt run at $startTime" -ForegroundColor Green

# Install dependencies
Write-Host "Installing dependencies..." -ForegroundColor Green
dbt deps

# Run models
Write-Host "Running models..." -ForegroundColor Green
dbt run --target prod

# Run tests
Write-Host "Running tests..." -ForegroundColor Green
dbt test --target prod

# Log completion time
$endTime = Get-Date
$duration = $endTime - $startTime
Write-Host "Completed dbt run at $endTime (Duration: $($duration.TotalMinutes) minutes)" -ForegroundColor Green
```

## Scheduling with Windows Task Scheduler

On Windows, you can use Task Scheduler to run your dbt project:

1. Open Task Scheduler
2. Click "Create Basic Task"
3. Name it "DBT Daily Run"
4. Set the trigger (e.g., daily at 2:00 AM)
5. Action: Start a program
6. Program/script: `powershell.exe`
7. Arguments: `-File "F:\dbtProjects\dbthero\run_production.ps1"`

## Using Podman for Containerized Deployment

If you're using Podman instead of Docker, you can create a containerized deployment:

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /usr/src/app

# Install dependencies
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt

# Copy project files
COPY . .

# Set environment variables
ENV DBT_PROFILES_DIR=/usr/src/app/profiles

# Run dbt
CMD ["dbt", "run", "--target", "prod"]
```

Build and run with Podman:

```powershell
# Build the image
podman build -t dbthero .

# Run the container
podman run --name dbthero-run -v F:\dbtProjects\dbthero\profiles:/usr/src/app/profiles dbthero
```

## Orchestration with Airflow

For more complex workflows, you can use Apache Airflow:

```python
# dags/dbthero_dag.py
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'data_team',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'dbthero_daily',
    default_args=default_args,
    description='Daily DBT Hero run',
    schedule_interval='0 2 * * *',
    catchup=False
)

# Install dependencies
install_deps = BashOperator(
    task_id='install_deps',
    bash_command='cd /path/to/dbthero && dbt deps',
    dag=dag
)

# Run staging models
run_staging = BashOperator(
    task_id='run_staging',
    bash_command='cd /path/to/dbthero && dbt run --select staging --target prod',
    dag=dag
)

# Run intermediate models
run_intermediate = BashOperator(
    task_id='run_intermediate',
    bash_command='cd /path/to/dbthero && dbt run --select intermediate --target prod',
    dag=dag
)

# Run mart models
run_marts = BashOperator(
    task_id='run_marts',
    bash_command='cd /path/to/dbthero && dbt run --select marts --target prod',
    dag=dag
)

# Run tests
run_tests = BashOperator(
    task_id='run_tests',
    bash_command='cd /path/to/dbthero && dbt test --target prod',
    dag=dag
)

# Set task dependencies
install_deps >> run_staging >> run_intermediate >> run_marts >> run_tests
```

## Setting Up Multiple Environments

It's a best practice to have separate environments for development, testing, and production:

```yaml
# ~/.dbt/profiles.yml

dbthero:
  target: dev
  outputs:
    dev:
      type: postgres
      host: localhost
      user: postgres
      password: dev_password
      port: 5432
      dbname: dbthero_dev
      schema: public
      threads: 4
    
    test:
      type: postgres
      host: test-db.example.com
      user: postgres
      password: test_password
      port: 5432
      dbname: dbthero_test
      schema: public
      threads: 4
    
    prod:
      type: postgres
      host: prod-db.example.com
      user: postgres
      password: prod_password
      port: 5432
      dbname: dbthero_prod
      schema: public
      threads: 8
```

Run dbt with a specific target:

```bash
dbt run --target prod
```

## CI/CD Pipeline with GitHub Actions

Set up a CI/CD pipeline to test and deploy your dbt project:

```yaml
# .github/workflows/dbt.yml

name: dbt CI/CD

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install dbt-postgres==1.9.0
    
    - name: Configure dbt profile
      run: |
        mkdir -p ~/.dbt
        cp ci/profiles.yml ~/.dbt/profiles.yml
    
    - name: Run dbt tests
      run: |
        dbt deps
        dbt compile
        dbt test
  
  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install dbt-postgres==1.9.0
    
    - name: Configure dbt profile
      run: |
        mkdir -p ~/.dbt
        cp ci/profiles.yml ~/.dbt/profiles.yml
    
    - name: Deploy to production
      run: |
        dbt deps
        dbt run --target prod
        dbt test --target prod
```

## Monitoring and Alerting

Set up monitoring for your dbt runs:

### Creating a Run Status Table

```sql
-- models/admin/dbt_run_status.sql

{{
    config(
        materialized='incremental',
        unique_key='run_id'
    )
}}

{% if execute %}
    {% set run_id = modules.datetime.datetime.now().strftime('%Y%m%d%H%M%S') %}
{% else %}
    {% set run_id = '00000000000000' %}
{% endif %}

select
    '{{ run_id }}' as run_id,
    '{{ target.name }}' as target,
    '{{ modules.datetime.datetime.now() }}' as run_at,
    {{ modules.datetime.datetime.now().timestamp() }} as run_timestamp,
    'running' as status
```

### Updating Run Status

```sql
-- macros/on_run_end.sql

{% macro on_run_end() %}
    {% if execute %}
        {% set run_id = modules.datetime.datetime.now().strftime('%Y%m%d%H%M%S') %}
    {% else %}
        {% set run_id = '00000000000000' %}
    {% endif %}
    
    {% set update_status %}
        update {{ target.schema }}.dbt_run_status
        set status = 'completed'
        where run_id = '{{ run_id }}'
    {% endset %}
    
    {% do run_query(update_status) %}
    {{ log("Updated run status to completed", info=True) }}
{% endmacro %}
```

### Setting Up Email Alerts

Create a script to check run status and send alerts:

```python
# scripts/check_dbt_status.py
import psycopg2
import smtplib
from email.mime.text import MIMEText
from datetime import datetime, timedelta

# Connect to database
conn = psycopg2.connect(
    host="your-db-host",
    database="dbthero_prod",
    user="postgres",
    password="your-password"
)

# Check for failed or stalled runs
cur = conn.cursor()
cur.execute("""
    SELECT run_id, target, run_at, status
    FROM dbt_run_status
    WHERE (status = 'running' AND run_timestamp < %s)
    OR status = 'failed'
""", [(datetime.now() - timedelta(hours=1)).timestamp()])

failed_runs = cur.fetchall()

if failed_runs:
    # Send email alert
    msg = MIMEText("DBT Hero runs have failed or stalled:\n\n" + 
                  "\n".join([str(run) for run in failed_runs]))
    msg['Subject'] = "DBT Hero Alert: Failed or Stalled Runs"
    msg['From'] = "alerts@example.com"
    msg['To'] = "data_team@example.com"
    
    s = smtplib.SMTP('smtp.example.com')
    s.send_message(msg)
    s.quit()
```

## Handling Data Quality Issues

Create a process to handle data quality failures:

```sql
-- macros/handle_test_failures.sql

{% macro handle_test_failures(results) %}
    {% set failed_tests = [] %}
    
    {% for result in results if result.status == "fail" and result.node.resource_type == "test" %}
        {% do failed_tests.append(result) %}
    {% endfor %}
    
    {% if failed_tests | length > 0 %}
        {% set test_failure_log %}
            insert into {{ target.schema }}.dbt_test_failures (
                test_name,
                model_name,
                failures,
                run_at
            )
            values
            {% for result in failed_tests %}
                (
                    '{{ result.node.name }}',
                    '{{ result.node.refs[0][0] if result.node.refs }}',
                    {{ result.failures }},
                    current_timestamp
                ){% if not loop.last %},{% endif %}
            {% endfor %}
        {% endset %}
        
        {% do run_query(test_failure_log) %}
        {{ log("Logged " ~ failed_tests | length ~ " test failures", info=True) }}
    {% endif %}
{% endmacro %}
```

Add this to your `dbt_project.yml`:

```yaml
on-run-end: "{{ handle_test_failures(results) }}"
```

## Best Practices for Production Deployment

1. **Version Control**: Always use version control for your dbt project
2. **Environment Separation**: Maintain separate dev, test, and prod environments
3. **CI/CD Integration**: Automate testing and deployment
4. **Incremental Models**: Use incremental models for large fact tables
5. **Monitoring**: Set up monitoring and alerting for dbt runs
6. **Documentation**: Keep documentation up to date
7. **Backup Strategy**: Regularly backup your production database
8. **Access Control**: Implement proper access controls for your data warehouse

## Conclusion

Congratulations! You've completed the DBT Hero tutorial series. You now have a solid understanding of how to:

1. Set up a dbt project
2. Create staging, intermediate, and dimensional models
3. Test and document your data warehouse
4. Optimize for performance
5. Deploy and schedule your dbt project

With these skills, you're well-equipped to build robust, maintainable data warehouses using dbt.

## Next Steps

To continue your dbt journey:

1. Explore the [dbt documentation](https://docs.getdbt.com/)
2. Join the [dbt Community](https://www.getdbt.com/community/)
3. Contribute to [dbt packages](https://hub.getdbt.com/)
4. Attend [dbt events](https://www.getdbt.com/events/)

Happy data modeling!

## Code Example: Complete Production Run Script

Here's a complete PowerShell script for production runs:

```powershell
# run_production.ps1

param (
    [string]$Target = "prod",
    [switch]$FullRefresh = $false,
    [switch]$SkipTests = $false
)

# Set environment variables
$env:DBT_PROFILES_DIR = "~/.dbt"
$env:DBT_TARGET = $Target

# Log start time
$startTime = Get-Date
Write-Host "Starting dbt run at $startTime (Target: $Target)" -ForegroundColor Green

try {
    # Install dependencies
    Write-Host "Installing dependencies..." -ForegroundColor Green
    dbt deps
    if ($LASTEXITCODE -ne 0) { throw "Failed to install dependencies" }

    # Run models
    Write-Host "Running models..." -ForegroundColor Green
    if ($FullRefresh) {
        Write-Host "Performing FULL REFRESH..." -ForegroundColor Yellow
        dbt run --target $Target --full-refresh
    } else {
        dbt run --target $Target
    }
    if ($LASTEXITCODE -ne 0) { throw "Failed to run models" }

    # Run tests (unless skipped)
    if (-not $SkipTests) {
        Write-Host "Running tests..." -ForegroundColor Green
        dbt test --target $Target
        if ($LASTEXITCODE -ne 0) { throw "Tests failed" }
    } else {
        Write-Host "Skipping tests as requested" -ForegroundColor Yellow
    }

    # Generate docs
    Write-Host "Generating documentation..." -ForegroundColor Green
    dbt docs generate --target $Target
    if ($LASTEXITCODE -ne 0) { throw "Failed to generate documentation" }

    # Log completion time
    $endTime = Get-Date
    $duration = $endTime - $startTime
    Write-Host "Successfully completed dbt run at $endTime (Duration: $($duration.TotalMinutes) minutes)" -ForegroundColor Green
} catch {
    # Log error
    $endTime = Get-Date
    $duration = $endTime - $startTime
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Run failed after $($duration.TotalMinutes) minutes" -ForegroundColor Red
    
    # Send alert email
    $emailBody = @"
DBT Hero run failed at $endTime

Target: $Target
Duration: $($duration.TotalMinutes) minutes
Error: $($_.Exception.Message)

Please check the logs for more details.
"@
    
    # Uncomment and configure to enable email alerts
    # Send-MailMessage -From "alerts@example.com" -To "data_team@example.com" -Subject "DBT Hero Alert: Run Failed" -Body $emailBody -SmtpServer "smtp.example.com"
    
    exit 1
}
```
