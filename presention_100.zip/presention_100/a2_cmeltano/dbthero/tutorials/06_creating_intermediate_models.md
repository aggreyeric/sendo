# Episode 6: Creating Intermediate Models

## Introduction

Intermediate models form the middle layer of our dbt project, joining and enriching data from our staging models. In this episode, we'll create intermediate models that prepare our data for the final dimensional models.

## Understanding the Intermediate Layer

The intermediate layer serves several important purposes:

1. **Join Related Data**: Combine data from multiple staging models
2. **Add Business Logic**: Implement calculations and derived fields
3. **Prepare for Dimensional Models**: Structure data for final fact and dimension tables
4. **Reduce Redundancy**: Avoid repeating complex logic in multiple models

## Creating Customer-State Relationships

Let's create an intermediate model that joins customers with their states:

```sql
-- models/intermediate/int_customers_with_states.sql

with customers as (
    select * from {{ ref('stg_sales_oltp__customers') }}
),

states as (
    select * from {{ ref('stg_sales_oltp__states') }}
),

customers_with_states as (
    select
        c.customer_id,
        c.first_name,
        c.last_name,
        c.email,
        c.phone,
        c.address,
        c.city,
        s.name as state_name,
        c.zip_code,
        c.created_at,
        c.updated_at
    from customers c
    left join states s on c.state_id = s.state_id
)

select * from customers_with_states
```

Note how we're using the `ref()` function to reference our staging models. This creates dependencies that dbt uses to determine the correct build order.

## Handling Join Conditions Carefully

When joining tables, be careful with column names. For example, in our states table, we renamed `id` to `state_id` in the staging model:

```sql
-- INCORRECT join (would cause error)
left join states s on c.state_id = s.id

-- CORRECT join (using renamed column)
left join states s on c.state_id = s.state_id
```

## Creating Employee Hierarchy Models

Let's create a model for employee hierarchies with PostgreSQL date functions:

```sql
-- models/intermediate/int_employees_with_managers.sql

with employees as (
    select * from {{ ref('stg_sales_oltp__employees') }}
),

managers as (
    select * from {{ ref('stg_sales_oltp__employees') }}
),

employees_with_managers as (
    select
        e.employee_id,
        e.first_name,
        e.last_name,
        e.first_name || ' ' || e.last_name as full_name,
        e.email,
        e.hire_date,
        e.position,
        e.department,
        e.salary,
        e.manager_id,
        m.first_name as manager_first_name,
        m.last_name as manager_last_name,
        m.first_name || ' ' || m.last_name as manager_full_name,
        m.position as manager_position,
        
        -- Derived fields using PostgreSQL date functions
        extract(year from age(current_date, e.hire_date)) as years_employed,
        case
            when m.employee_id is null then 1
            else 0
        end as is_top_level
    from employees e
    left join managers m on e.manager_id = m.employee_id
)

select * from employees_with_managers
```

Notice how we're using PostgreSQL's `extract(year from age())` function instead of `datediff(year)` which isn't supported in PostgreSQL.

## Creating Order Details Models

Let's create a model that joins orders with customer details:

```sql
-- models/intermediate/int_orders_with_details.sql

with orders as (
    select * from {{ ref('stg_sales_oltp__orders') }}
),

customers as (
    select * from {{ ref('stg_sales_oltp__customers') }}
),

states as (
    select * from {{ ref('stg_sales_oltp__states') }}
),

orders_with_details as (
    select
        o.order_id,
        o.order_date,
        o.order_status,
        o.order_total,
        o.tax_amount,
        o.shipping_amount,
        o.payment_method,
        
        -- Customer details
        c.customer_id,
        c.first_name as customer_first_name,
        c.last_name as customer_last_name,
        c.first_name || ' ' || c.last_name as customer_full_name,
        c.email as customer_email,
        
        -- Shipping details
        o.address as shipping_address,
        o.city as shipping_city,
        s.name as shipping_state,
        o.zip_code as shipping_zip,
        
        -- Derived fields
        case
            when o.order_status = 'Completed' then 1
            else 0
        end as is_completed
    from orders o
    left join customers c on o.customer_id = c.customer_id
    left join states s on o.state_id = s.state_id
)

select * from orders_with_details
```

## Creating Product-Category Relationships

Let's create a model that joins products with their categories:

```sql
-- models/intermediate/int_products_with_categories.sql

with products as (
    select * from {{ ref('stg_sales_oltp__products') }}
),

categories as (
    select * from {{ ref('stg_sales_oltp__product_categories') }}
),

products_with_details as (
    select
        p.product_id,
        p.product_name,
        p.product_description,
        p.unit_price,
        p.stock_quantity,
        p.cost,
        p.sku,
        c.category_id,
        c.name as category_name,
        p.created_at,
        p.updated_at
    from products p
    left join categories c on p.category_id = c.category_id
)

select * from products_with_details
```

Notice that we don't include supplier information since our products table doesn't have a supplier_id column.

## Creating Order Items with Products

Let's create a model that joins order items with product details:

```sql
-- models/intermediate/int_order_items_with_products.sql

with order_items as (
    select * from {{ ref('stg_sales_oltp__order_items') }}
),

products as (
    select * from {{ ref('stg_sales_oltp__products') }}
),

product_categories as (
    select * from {{ ref('stg_sales_oltp__product_categories') }}
),

order_items_with_products as (
    select
        oi.order_item_id,
        oi.order_id,
        oi.product_id,
        oi.quantity,
        oi.unit_price,
        oi.line_total,
        
        -- Product details
        p.product_name,
        p.product_description,
        pc.category_id,
        pc.name as category_name,
        
        -- Derived fields
        (oi.unit_price * oi.quantity) as calculated_line_total,
        case
            when oi.quantity > 10 then 'Large Order'
            when oi.quantity > 5 then 'Medium Order'
            else 'Small Order'
        end as order_size
    from order_items oi
    left join products p on oi.product_id = p.product_id
    left join product_categories pc on p.category_id = pc.category_id
)

select * from order_items_with_products
```

## Testing Intermediate Models

Add tests to your intermediate models in a schema.yml file:

```yaml
# models/intermediate/schema.yml

version: 2

models:
  - name: int_customers_with_states
    description: Customers enriched with state information
    columns:
      - name: customer_id
        description: Primary key
        tests:
          - unique
          - not_null

  - name: int_orders_with_details
    description: Orders enriched with customer and shipping details
    columns:
      - name: order_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: customer_id
        description: Foreign key to customers
        tests:
          - relationships:
              to: ref('int_customers_with_states')
              field: customer_id

  # Additional model definitions...
```

## Running Intermediate Models

Run your intermediate models with:

```bash
dbt run --select intermediate
```

Or run a specific model:

```bash
dbt run --select int_customers_with_states
```

## Best Practices for Intermediate Models

1. **Keep Business Logic Clear**: Document complex transformations
2. **Use Consistent Naming**: Prefix with `int_` for clarity
3. **Reference Staging Models**: Use `ref()` to create proper dependencies
4. **Add Tests**: Test key relationships and business rules
5. **Materialize as Views**: Intermediate models should typically be views
6. **Document Assumptions**: Note any business rules or assumptions

## Next Steps

With our intermediate models complete, in the next episode we'll create dimensional models (fact and dimension tables) that will form our final data warehouse.

## Code Example: Exploring Intermediate Models

After creating your intermediate models, you can explore them with this query:

```sql
-- Query to explore customer orders with state information
SELECT
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.state_name,
    COUNT(o.order_id) AS order_count,
    SUM(o.order_total) AS total_spent
FROM
    {{ ref('int_customers_with_states') }} c
    LEFT JOIN {{ ref('int_orders_with_details') }} o ON c.customer_id = o.customer_id
GROUP BY
    c.customer_id, c.first_name, c.last_name, c.state_name
ORDER BY
    total_spent DESC
LIMIT 10
```
