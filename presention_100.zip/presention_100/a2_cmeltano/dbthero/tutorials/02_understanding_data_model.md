# Episode 2: Understanding the Data Model

## Introduction

Before diving into dbt transformations, it's crucial to understand both our source data structure and the target dimensional model we want to build. This episode explores the data model that powers our DBT Hero project.

## OLTP Source Schema Overview

Our source data comes from a sales system with a normalized OLTP (Online Transaction Processing) schema designed for efficient transaction processing. Let's examine the key tables:

### Source Tables

#### Customers
```sql
CREATE TABLE public.customers (
    customer_id serial PRIMARY KEY,
    first_name varchar(50),
    last_name varchar(50),
    email varchar(100),
    phone varchar(20),
    address varchar(100),
    city varchar(50),
    state_id int,
    zip_code varchar(10),
    created_at timestamp,
    updated_at timestamp
);
```

#### Products
```sql
CREATE TABLE public.products (
    product_id serial PRIMARY KEY,
    name varchar(100),
    description text,
    category_id int,
    price float8,
    cost float8,
    sku varchar(50),
    inventory_quantity int,
    created_at timestamp,
    updated_at timestamp
);
```

#### Orders
```sql
CREATE TABLE public.orders (
    order_id serial PRIMARY KEY,
    customer_id int,
    order_date timestamp,
    status varchar(20),
    shipping_address varchar(200),
    shipping_city varchar(50),
    shipping_state_id int,
    shipping_zip varchar(10),
    payment_method varchar(50),
    order_total float8,
    tax_amount float8,
    shipping_amount float8
);
```

#### Order Items
```sql
CREATE TABLE public.order_items (
    order_item_id serial PRIMARY KEY,
    order_id int,
    product_id int,
    quantity int,
    unit_price float8,
    line_total float8
);
```

And several other tables for inventory, employees, suppliers, etc.

## Dimensional Modeling Concepts

Dimensional modeling is a design technique optimized for data warehouse queries. The key components are:

1. **Fact Tables**: Contain business metrics and foreign keys to dimensions
2. **Dimension Tables**: Contain descriptive attributes about business entities
3. **Star Schema**: A fact table surrounded by dimension tables

### Benefits of Dimensional Modeling

- Simplified query structure
- Improved query performance
- Consistent reporting results
- Better understanding of business metrics

## Our Target Data Warehouse Model

We'll transform our OLTP schema into a dimensional model with these components:

### Dimension Tables

1. **dim_customer**: Customer attributes and categorization
2. **dim_product**: Product details with category and pricing tiers
3. **dim_supplier**: Supplier information
4. **dim_employee**: Employee details with hierarchy
5. **dim_date**: Calendar attributes for time-based analysis

### Fact Tables

1. **fact_sales**: Order transactions with revenue metrics
2. **fact_inventory**: Inventory movements with quantity and value changes

## Entity Relationships

Here's how our entities relate in the dimensional model:

```
                    +-------------+
                    | dim_date    |
                    +-------------+
                           |
                           |
+-------------+      +-------------+      +-------------+
| dim_customer|----->| fact_sales  |<-----| dim_product |
+-------------+      +-------------+      +-------------+
                           |                    |
                           |                    |
                    +-------------+      +-------------+
                    | dim_employee|      |fact_inventory|
                    +-------------+      +-------------+
                                               |
                                               |
                                        +-------------+
                                        | dim_supplier|
                                        +-------------+
```

## dbt Transformation Approach

To transform our OLTP data into this dimensional model, we'll use a layered approach in dbt:

1. **Staging Layer**: Clean and standardize source data
2. **Intermediate Layer**: Join related entities and add business logic
3. **Marts Layer**: Create final fact and dimension tables

This modular approach makes our transformations easier to understand, test, and maintain.

## Important Schema Considerations

When implementing this model, be aware of these specific details:

1. The orders table doesn't have employee_id, required_date, or shipped_date columns
2. The products table doesn't have a supplier_id column but has cost and sku columns
3. The states table uses 'id' as the primary key instead of 'state_id'
4. PostgreSQL requires specific date functions (using interval syntax and extract)

## Next Steps

Now that we understand our data model, in the next episode we'll learn how to load test data into our database to work with as we build our dbt project.

## Code Example: Exploring Table Relationships

Here's a query to explore the relationships between our key tables:

```sql
-- Explore relationships between orders, customers, and products
SELECT 
    o.order_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    p.name AS product_name,
    oi.quantity,
    oi.unit_price,
    oi.line_total
FROM 
    public.orders o
    JOIN public.customers c ON o.customer_id = c.customer_id
    JOIN public.order_items oi ON o.order_id = oi.order_id
    JOIN public.products p ON oi.product_id = p.product_id
LIMIT 10;
```
