# Episode 11: Advanced dbt Features

## Introduction

Now that we have a solid foundation for our data warehouse, let's explore some advanced dbt features that can enhance our project. In this episode, we'll cover snapshots, exposures, analyses, and other powerful dbt capabilities.

## Implementing Slowly Changing Dimensions

Slowly Changing Dimensions (SCDs) track changes to dimension attributes over time. dbt's snapshot feature makes it easy to implement Type 2 SCDs:

### Creating a Snapshot

```sql
-- snapshots/customer_snapshot.sql

{% snapshot customer_snapshot %}

{{
    config(
      target_schema='snapshots',
      strategy='timestamp',
      unique_key='customer_id',
      updated_at='updated_at',
      invalidate_hard_deletes=True,
    )
}}

select * from {{ source('sales_oltp', 'customers') }}

{% endsnapshot %}
```

This creates a Type 2 SCD for customers, tracking changes based on the `updated_at` timestamp.

### Using Snapshots in Models

```sql
-- models/marts/core/dim_customer_scd.sql

with customer_snapshot as (
    select * from {{ ref('customer_snapshot') }}
),

final as (
    select
        customer_id,
        first_name,
        last_name,
        first_name || ' ' || last_name as full_name,
        email,
        phone,
        address,
        city,
        state_id,
        zip_code,
        dbt_valid_from,
        dbt_valid_to,
        case
            when dbt_valid_to is null then 'Current'
            else 'Historical'
        end as record_status
    from customer_snapshot
)

select * from final
```

## Creating Analyses

Analyses are SQL files that don't create models but are useful for ad-hoc analysis:

```sql
-- analyses/customer_cohort_analysis.sql

with first_orders as (
    select
        customer_id,
        min(order_date) as first_order_date,
        date_trunc('month', min(order_date)) as cohort_month
    from {{ ref('fact_sales') }}
    group by customer_id
),

monthly_orders as (
    select
        date_trunc('month', order_date) as order_month,
        customer_id,
        sum(total_amount) as monthly_spend
    from {{ ref('fact_sales') }}
    group by date_trunc('month', order_date), customer_id
),

cohort_data as (
    select
        fo.cohort_month,
        mo.order_month,
        extract(year from age(mo.order_month, fo.cohort_month)) * 12 +
        extract(month from age(mo.order_month, fo.cohort_month)) as months_since_first_order,
        count(distinct fo.customer_id) as cohort_size,
        count(distinct mo.customer_id) as active_customers,
        sum(mo.monthly_spend) as total_spend
    from first_orders fo
    left join monthly_orders mo on fo.customer_id = mo.customer_id
    where mo.order_month >= fo.cohort_month
    group by fo.cohort_month, mo.order_month
)

select
    cohort_month,
    order_month,
    months_since_first_order,
    cohort_size,
    active_customers,
    total_spend,
    round(100.0 * active_customers / cohort_size, 2) as retention_rate,
    round(total_spend / active_customers, 2) as average_spend_per_customer
from cohort_data
order by cohort_month, months_since_first_order
```

To run this analysis:

```bash
dbt compile --select analyses/customer_cohort_analysis.sql
```

Then find the compiled SQL in the target directory.

## Defining Exposures

Exposures document how your dbt models are used in downstream tools:

```yaml
# models/exposures.yml

version: 2

exposures:
  - name: sales_dashboard
    type: dashboard
    maturity: high
    url: https://your-bi-tool.com/dashboards/sales
    description: Executive Sales Dashboard
    
    depends_on:
      - ref('fact_sales')
      - ref('dim_customer')
      - ref('dim_product')
      - ref('dim_date')
    
    owner:
      name: Analytics Team
      email: analytics@example.com

  - name: inventory_report
    type: report
    maturity: medium
    url: https://your-bi-tool.com/reports/inventory
    description: Weekly Inventory Status Report
    
    depends_on:
      - ref('fact_inventory')
      - ref('dim_product')
    
    owner:
      name: Supply Chain Team
      email: supply.chain@example.com
```

Exposures appear in your documentation and lineage graphs, showing how your models connect to business outputs.

## Using Seeds for Static Data

Seeds are CSV files that dbt loads into your database:

```csv
# seeds/product_categories_mapping.csv
category_id,category_name,category_group
1,Electronics,Technology
2,Computers,Technology
3,Phones,Technology
4,Clothing,Apparel
5,Shoes,Apparel
6,Accessories,Apparel
```

Configure seeds in your `dbt_project.yml`:

```yaml
seeds:
  dbthero:
    product_categories_mapping:
      +column_types:
        category_id: int
        category_name: varchar(50)
        category_group: varchar(50)
```

Load seeds with:

```bash
dbt seed
```

Reference seeds in models:

```sql
-- models/marts/core/dim_product_extended.sql

with products as (
    select * from {{ ref('dim_product') }}
),

category_mapping as (
    select * from {{ ref('product_categories_mapping') }}
),

final as (
    select
        p.*,
        cm.category_group
    from products p
    left join category_mapping cm on p.category_id = cm.category_id
)

select * from final
```

## Using Hooks for Database Management

Hooks let you execute SQL at different points in the dbt run lifecycle:

### On-Run-Start Hook

```sql
-- macros/on_run_start.sql

{% macro on_run_start() %}
    {{ create_schemas() }}
    
    {% set vacuum_staging %}
        VACUUM ANALYZE {{ target.schema }}.stg_sales_oltp__orders;
    {% endset %}
    
    {% do run_query(vacuum_staging) %}
    {{ log("Vacuumed staging tables", info=True) }}
{% endmacro %}
```

### On-Run-End Hook

```sql
-- macros/on_run_end.sql

{% macro on_run_end() %}
    {% set grant_permissions %}
        GRANT USAGE ON SCHEMA dwh TO reporting_role;
        GRANT SELECT ON ALL TABLES IN SCHEMA dwh TO reporting_role;
    {% endset %}
    
    {% do run_query(grant_permissions) %}
    {{ log("Granted permissions to reporting role", info=True) }}
{% endmacro %}
```

## Using Variables for Flexibility

Variables make your project more flexible:

```yaml
# dbt_project.yml

vars:
  start_date: '2023-01-01'
  end_date: '2023-12-31'
  include_canceled_orders: false
```

Use variables in models:

```sql
-- models/marts/core/fact_sales_filtered.sql

with sales as (
    select * from {{ ref('fact_sales') }}
    where order_date >= '{{ var("start_date") }}'
    and order_date <= '{{ var("end_date") }}'
    {% if not var('include_canceled_orders') %}
    and order_status != 'Canceled'
    {% endif %}
)

select * from sales
```

Override variables when running dbt:

```bash
dbt run --select fact_sales_filtered --vars '{"start_date": "2023-06-01", "include_canceled_orders": true}'
```

## Using Tags for Selective Runs

Tags help you organize and run specific groups of models:

```sql
-- models/marts/core/fact_sales.sql

{{
    config(
        materialized='table',
        tags=['sales', 'daily']
    )
}}
```

Run models with specific tags:

```bash
dbt run --select tag:daily
```

## Creating Custom Materializations

For advanced needs, you can create custom materializations:

```sql
-- macros/materialization_upsert_table.sql

{% materialization upsert_table, adapter='postgres' %}
  {%- set target_relation = this %}
  {%- set temp_relation = make_temp_relation(target_relation) %}
  
  -- Setup
  {{ run_hooks(pre_hooks) }}
  
  -- Build the temp table
  {% call statement('main') %}
    {{ create_table_as(False, temp_relation, sql) }}
  {% endcall %}
  
  -- Perform the upsert
  {% call statement('upsert') %}
    INSERT INTO {{ target_relation }}
    SELECT * FROM {{ temp_relation }}
    ON CONFLICT ({{ config.get('unique_key') }})
    DO UPDATE SET
      {% for column in adapter.get_columns_in_relation(target_relation) %}
        {% if column.name != config.get('unique_key') %}
          {{ column.name }} = EXCLUDED.{{ column.name }}
          {{ "," if not loop.last }}
        {% endif %}
      {% endfor %}
  {% endcall %}
  
  -- Cleanup
  {% call statement('cleanup') %}
    DROP TABLE {{ temp_relation }}
  {% endcall %}
  
  {{ run_hooks(post_hooks) }}
  
  {{ return({'relations': [target_relation]}) }}
{% endmaterialization %}
```

Use your custom materialization:

```sql
-- models/marts/core/dim_product_upsert.sql

{{
    config(
        materialized='upsert_table',
        unique_key='product_id'
    )
}}

select * from {{ ref('int_products_with_categories') }}
```

## Next Steps

With these advanced features, you can take your dbt project to the next level. In our final episode, we'll explore how to deploy and schedule your dbt project in production.

## Code Example: Advanced Analysis

Here's an example of an advanced analysis using multiple dbt features:

```sql
-- analyses/product_performance_analysis.sql

{% set date_range = [
    ('2023-01-01', '2023-03-31', 'Q1'),
    ('2023-04-01', '2023-06-30', 'Q2'),
    ('2023-07-01', '2023-09-30', 'Q3'),
    ('2023-10-01', '2023-12-31', 'Q4')
] %}

with 

{% for start_date, end_date, quarter in date_range %}
quarter_{{ quarter }} as (
    select
        p.category_name,
        sum(s.quantity) as total_quantity,
        sum(s.line_total) as total_sales,
        '{{ quarter }}' as quarter
    from {{ ref('fact_sales') }} s
    join {{ ref('dim_product') }} p on s.product_id = p.product_id
    where s.order_date between '{{ start_date }}' and '{{ end_date }}'
    group by p.category_name
){% if not loop.last %},{% endif %}
{% endfor %}

{% for start_date, end_date, quarter in date_range %}
select * from quarter_{{ quarter }}
{% if not loop.last %}union all{% endif %}
{% endfor %}

order by quarter, total_sales desc
```
