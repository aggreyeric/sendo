# Episode 5: Building Staging Models

## Introduction

Staging models are the foundation of your dbt project. They serve as a clean interface between raw source data and your transformation logic. In this episode, we'll build staging models for our sales system data.

## Understanding the Staging Layer

The staging layer has several important purposes:

1. **Standardize Source Data**: Rename columns and apply consistent formatting
2. **Isolate Source Changes**: Shield downstream models from source schema changes
3. **Minimal Transformations**: Keep transformations simple at this layer
4. **Create a Clean Interface**: Provide a consistent way to access source data

## Defining Sources

Before creating staging models, we define our sources in a YAML file:

```yaml
# models/staging/sales_oltp/sources.yml

version: 2

sources:
  - name: sales_oltp
    database: dbthero
    schema: public
    tables:
      - name: customers
        description: Customer information
        columns:
          - name: customer_id
            description: Primary key
            tests:
              - unique
              - not_null
          # Additional column definitions...

      - name: products
        description: Product catalog
        # Column definitions...

      # Additional table definitions...
```

This file tells dbt where to find our source tables and adds documentation and tests.

## Creating a Basic Staging Model

Let's create a staging model for the customers table:

```sql
-- models/staging/sales_oltp/stg_sales_oltp__customers.sql

with source as (
    select * from {{ source('sales_oltp', 'customers') }}
),

renamed as (
    select
        customer_id,
        first_name,
        last_name,
        email,
        phone,
        address,
        city,
        state_id,
        zip_code,
        created_at,
        updated_at
    from source
)

select * from renamed
```

This model follows a consistent pattern:
1. Source CTE: Selects from the source table using the `source()` function
2. Renamed CTE: Selects and renames columns as needed
3. Final SELECT: Returns the transformed data

## Handling Schema Differences

One challenge in real projects is dealing with schema differences. For example, our orders table structure is:

```sql
-- Actual orders table structure
CREATE TABLE public.orders (
    order_id serial4 NOT NULL,
    customer_id int4 NULL,
    order_date timestamp NULL,
    status varchar(20) NULL,
    shipping_address varchar(200) NULL,
    shipping_city varchar(50) NULL,
    shipping_state_id int4 NULL,
    shipping_zip varchar(10) NULL,
    payment_method varchar(50) NULL,
    order_total float8 NULL,
    tax_amount float8 NULL,
    shipping_amount float8 NULL,
    CONSTRAINT orders_pkey null
);
```

Our staging model needs to match this structure:

```sql
-- models/staging/sales_oltp/stg_sales_oltp__orders.sql

with source as (
    select * from {{ source('sales_oltp', 'orders') }}
),

renamed as (
    select
        order_id,
        customer_id,
        order_date,
        status as order_status,
        shipping_address as address,
        shipping_city as city,
        shipping_state_id as state_id,
        shipping_zip as zip_code,
        payment_method,
        order_total,
        tax_amount,
        shipping_amount
    from source
)

select * from renamed
```

Notice that we're renaming some columns for consistency and clarity.

## PostgreSQL-Specific Considerations

When working with PostgreSQL, be aware of these specific considerations:

1. **Date Functions**: PostgreSQL uses different date functions than other databases
   - Use `interval` syntax instead of `DATEADD`
   - Use `extract` instead of `DATEDIFF`

2. **Case Sensitivity**: PostgreSQL treats unquoted identifiers as lowercase
   - Be consistent with your casing in models

3. **Data Types**: PostgreSQL has specific data types
   - Use `timestamp` for datetime values
   - Use `numeric` for precise decimal values

## Creating Staging Models for All Source Tables

Let's create a staging model for the products table, which has a different structure than we might initially expect:

```sql
-- models/staging/sales_oltp/stg_sales_oltp__products.sql

with source as (
    select * from {{ source('sales_oltp', 'products') }}
),

renamed as (
    select
        product_id,
        name as product_name,
        description as product_description,
        category_id,
        price as unit_price,
        cost,
        sku,
        inventory_quantity as stock_quantity,
        created_at,
        updated_at
    from source
)

select * from renamed
```

Note that we're renaming fields for clarity and consistency across models.

## Handling Primary Keys in Source Tables

Some tables might have different primary key column names than expected. For example, the states table:

```sql
-- models/staging/sales_oltp/stg_sales_oltp__states.sql

with source as (
    select * from {{ source('sales_oltp', 'states') }}
),

renamed as (
    select
        id as state_id,
        name
    from source
)

select * from renamed
```

Here we're renaming `id` to `state_id` for clarity and consistency.

## Testing Staging Models

Add tests to your staging models in a schema.yml file:

```yaml
# models/staging/sales_oltp/schema.yml

version: 2

models:
  - name: stg_sales_oltp__customers
    description: Staged customer data
    columns:
      - name: customer_id
        description: Primary key
        tests:
          - unique
          - not_null

  - name: stg_sales_oltp__orders
    description: Staged order data
    columns:
      - name: order_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: customer_id
        description: Foreign key to customers
        tests:
          - relationships:
              to: ref('stg_sales_oltp__customers')
              field: customer_id

  # Additional model definitions...
```

## Running Staging Models

Run your staging models with:

```bash
dbt run --select staging
```

Or run a specific model:

```bash
dbt run --select stg_sales_oltp__customers
```

## Best Practices for Staging Models

1. **One Model Per Source Table**: Keep a 1:1 relationship between source tables and staging models
2. **Consistent Naming**: Use a consistent prefix like `stg_[source]__[table]`
3. **Minimal Transformations**: Keep transformations simple at this layer
4. **Use Source() Function**: Always reference source tables with the `source()` function
5. **Document and Test**: Add descriptions and tests for all models
6. **Materialize as Views**: Staging models should typically be views, not tables

## Next Steps

With our staging models complete, in the next episode we'll create intermediate models that join these staging models together to create more complex transformations.

## Code Example: Exploring Staging Models

After creating your staging models, you can explore them with this query:

```sql
-- Query to explore staged customer orders
SELECT
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    COUNT(o.order_id) AS order_count,
    SUM(o.order_total) AS total_spent
FROM
    {{ ref('stg_sales_oltp__customers') }} c
    LEFT JOIN {{ ref('stg_sales_oltp__orders') }} o ON c.customer_id = o.customer_id
GROUP BY
    c.customer_id, c.first_name, c.last_name
ORDER BY
    total_spent DESC
LIMIT 10
```
