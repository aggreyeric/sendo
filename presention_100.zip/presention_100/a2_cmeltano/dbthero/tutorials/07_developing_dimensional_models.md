# Episode 7: Developing Dimensional Models

## Introduction

Dimensional models are the final output of our data warehouse. In this episode, we'll create dimension tables that describe the key business entities in our sales system.

## Understanding Dimension Tables

Dimension tables contain descriptive attributes about business entities. They have these characteristics:

1. **Descriptive Attributes**: Text and categorical fields that describe entities
2. **Surrogate Keys**: Unique identifiers that don't depend on source systems
3. **Slowly Changing Dimensions**: Track changes to attributes over time (if needed)
4. **Hierarchies**: Represent hierarchical relationships within dimensions
5. **Materialized as Tables**: Usually materialized as tables for query performance

## Creating the Customer Dimension

Let's create a customer dimension table:

```sql
-- models/marts/core/dim_customer.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with customer_with_states as (
    select * from {{ ref('int_customers_with_states') }}
),

final as (
    select
        customer_id,
        first_name,
        last_name,
        first_name || ' ' || last_name as full_name,
        email,
        phone,
        address,
        city,
        state_name,
        zip_code,
        created_at,
        updated_at,
        
        -- Add derived fields
        case
            when created_at > (current_timestamp - interval '3 months') then 'New'
            when created_at > (current_timestamp - interval '1 year') then 'Regular'
            else 'Established'
        end as customer_category
    from customer_with_states
)

select * from final
```

Notice how we're using PostgreSQL's interval syntax for date calculations instead of `dateadd()` which isn't supported in PostgreSQL.

## Creating the Product Dimension

Let's create a product dimension table:

```sql
-- models/marts/core/dim_product.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with products_with_details as (
    select * from {{ ref('int_products_with_categories') }}
),

final as (
    select
        product_id,
        product_name,
        product_description,
        unit_price,
        stock_quantity,
        cost,
        sku,
        category_id,
        category_name,
        created_at,
        updated_at,
        
        -- Add derived fields
        case
            when stock_quantity = 0 then 'Out of Stock'
            when stock_quantity < 10 then 'Low Stock'
            when stock_quantity < 50 then 'Medium Stock'
            else 'High Stock'
        end as stock_status,
        
        case
            when unit_price < 10 then 'Budget'
            when unit_price < 50 then 'Standard'
            when unit_price < 100 then 'Premium'
            else 'Luxury'
        end as price_tier
    from products_with_details
)

select * from final
```

Notice that we include `cost` and `sku` fields that are present in our actual products table, but we don't include supplier information since our products table doesn't have a supplier_id column.

## Creating the Employee Dimension

Let's create an employee dimension table:

```sql
-- models/marts/core/dim_employee.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with employees_with_managers as (
    select * from {{ ref('int_employees_with_managers') }}
),

final as (
    select
        employee_id,
        first_name,
        last_name,
        full_name,
        email,
        hire_date,
        position,
        department,
        salary,
        manager_id,
        manager_first_name,
        manager_last_name,
        manager_full_name,
        manager_position,
        years_employed,
        is_top_level,
        
        -- Add derived fields
        case
            when years_employed < 1 then 'New'
            when years_employed < 3 then 'Junior'
            when years_employed < 7 then 'Mid-level'
            else 'Senior'
        end as tenure_category
    from employees_with_managers
)

select * from final
```

## Creating the Date Dimension

A date dimension is essential for time-based analysis. Let's create one using PostgreSQL's `generate_series` function:

```sql
-- models/marts/core/dim_date.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with date_spine as (
    -- Generate dates from 2 years ago to 5 years in the future
    select 
        cast(date_day as date) as date_day
    from 
        unnest(
            array(
                select generate_series(
                    cast('2023-01-01' as date),
                    cast('2030-12-31' as date),
                    interval '1 day'
                )
            )
        ) as date_day
),

date_dim as (
    select
        -- Date key (YYYYMMDD format)
        to_char(date_day, 'YYYYMMDD')::int as date_key,
        
        -- Date fields
        date_day as calendar_date,
        extract(year from date_day) as year,
        extract(month from date_day) as month,
        extract(day from date_day) as day_of_month,
        
        -- Month names
        to_char(date_day, 'Month') as month_name,
        to_char(date_day, 'Mon') as month_short_name,
        
        -- Quarter
        'Q' || extract(quarter from date_day) as quarter_name,
        extract(quarter from date_day) as quarter,
        
        -- Week
        extract(week from date_day) as week_of_year,
        
        -- Day of week
        extract(isodow from date_day) as day_of_week,
        to_char(date_day, 'Day') as day_name,
        to_char(date_day, 'Dy') as day_short_name,
        
        -- Fiscal periods (assuming fiscal year starts in July)
        case 
            when extract(month from date_day) >= 7 then extract(year from date_day) + 1
            else extract(year from date_day)
        end as fiscal_year,
        
        case 
            when extract(month from date_day) >= 7 then extract(month from date_day) - 6
            else extract(month from date_day) + 6
        end as fiscal_month,
        
        -- Special flags
        case 
            when extract(isodow from date_day) in (6, 7) then 1
            else 0
        end as is_weekend,
        
        case 
            when date_day = date_trunc('month', date_day) then 1
            else 0
        end as is_first_day_of_month,
        
        case 
            when date_day = (date_trunc('month', date_day) + interval '1 month' - interval '1 day') then 1
            else 0
        end as is_last_day_of_month
    from date_spine
)

select * from date_dim
order by calendar_date
```

This creates a comprehensive date dimension with various date attributes for reporting and analysis.

## Creating the Supplier Dimension

Let's create a supplier dimension table:

```sql
-- models/marts/core/dim_supplier.sql

{{
    config(
        materialized='table',
        schema='dwh'
    )
}}

with suppliers_with_states as (
    select * from {{ ref('int_suppliers_with_states') }}
),

final as (
    select
        supplier_id,
        name as supplier_name,
        contact_name,
        email,
        phone,
        address,
        city,
        state_name,
        zip_code,
        
        -- Add derived fields
        case
            when email like '%gmail.com' then 'Gmail'
            when email like '%yahoo.com' then 'Yahoo'
            when email like '%hotmail.com' then 'Hotmail'
            else split_part(email, '@', 2)
        end as email_domain
    from suppliers_with_states
)

select * from final
```

## Documenting Dimension Tables

Add documentation for your dimension tables in a schema.yml file:

```yaml
# models/marts/core/schema.yml

version: 2

models:
  - name: dim_customer
    description: Customer dimension table
    columns:
      - name: customer_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: full_name
        description: Customer's full name
      - name: customer_category
        description: Customer categorization based on tenure
        tests:
          - accepted_values:
              values: ['New', 'Regular', 'Established']

  - name: dim_product
    description: Product dimension table
    columns:
      - name: product_id
        description: Primary key
        tests:
          - unique
          - not_null
      - name: product_name
        description: Product name
      - name: category_name
        description: Product category name
      - name: price_tier
        description: Price tier categorization
        tests:
          - accepted_values:
              values: ['Budget', 'Standard', 'Premium', 'Luxury']

  # Additional model definitions...
```

## Running Dimension Models

Run your dimension models with:

```bash
dbt run --select marts.core.dim_*
```

Or run a specific model:

```bash
dbt run --select dim_customer
```

## Best Practices for Dimension Tables

1. **Add Business Context**: Include derived fields that add business meaning
2. **Use Consistent Naming**: Prefix with `dim_` for clarity
3. **Include Surrogate Keys**: For slowly changing dimensions (if needed)
4. **Add Hierarchies**: Represent hierarchical relationships
5. **Document Business Rules**: Explain categorizations and calculations
6. **Materialize as Tables**: Dimension tables should be materialized as tables
7. **Add Tests**: Test unique keys and categorical values

## Next Steps

With our dimension tables complete, in the next episode we'll create fact tables that contain the measures and metrics for our business processes.

## Code Example: Analyzing Customer Dimensions

After creating your dimension tables, you can analyze them with this query:

```sql
-- Query to analyze customer distribution by category and state
SELECT
    d.state_name,
    d.customer_category,
    COUNT(*) AS customer_count
FROM
    {{ ref('dim_customer') }} d
GROUP BY
    d.state_name, d.customer_category
ORDER BY
    d.state_name, d.customer_category
```
