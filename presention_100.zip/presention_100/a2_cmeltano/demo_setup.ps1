# ============================================================================
# SINGER FRAMEWORK - COMPLETE DEMO SETUP
# Run this before your presentation for a flawless demo
# ============================================================================

param(
    [int]$Customers = 50,
    [int]$Products = 30,
    [int]$Orders = 100,
    [switch]$SkipInstall,
    [switch]$SkipDiscovery,
    [switch]$SkipDbtGen
)

$ErrorActionPreference = "Stop"

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║        Singer Framework - Complete Demo Setup             ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan

$ProjectRoot = "F:\presention_100\a2_cmeltano"
$Config = "snowflake_auto.yml"
$TapConfig = "tap_snowflake_config.json"
$DbtProject = "$ProjectRoot\dbthero\dbthero"

Set-Location $ProjectRoot

try { [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new() } catch {}
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

# ============================================================================
# Step 1: Activate Virtual Environment
# ============================================================================
Write-Host "`n[1/7] 🔌 Activating Virtual Environment..." -ForegroundColor Yellow

if (Test-Path "venv\Scripts\Activate.ps1") {
    & "venv\Scripts\Activate.ps1"
    Write-Host "   ✓ Virtual environment activated" -ForegroundColor Green
} else {
    Write-Host "   ✗ Virtual environment not found" -ForegroundColor Red
    Write-Host "   → Creating virtual environment..." -ForegroundColor Cyan
    python -m venv venv
    & "venv\Scripts\Activate.ps1"
    Write-Host "   ✓ Virtual environment created and activated" -ForegroundColor Green
}

# ============================================================================
# Step 2: Install All Dependencies (skips if already installed)
# ============================================================================
Write-Host "`n[2/7] 📦 Installing Dependencies..." -ForegroundColor Yellow
if ($SkipInstall) {
    Write-Host "   ⊘ Skipping installation (per flag)" -ForegroundColor Yellow
} else {
    function Ensure-PipPackage {
        param(
            [string]$Package,
            [string]$InstallArgs
        )
        $null = & pip show $Package 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "   ✓ $Package already installed" -ForegroundColor Green
        } else {
            Write-Host "   → Installing $Package..." -ForegroundColor Cyan
            & pip install $InstallArgs --quiet 2>$null
            Write-Host "   ✓ $Package installed" -ForegroundColor Green
        }
    }

    Write-Host "   → Installing framework..." -ForegroundColor Cyan
    & pip install -e . --quiet 2>$null
    Write-Host "   ✓ Framework installed" -ForegroundColor Green

    Ensure-PipPackage -Package "snowflake-connector-python" -InstallArgs "snowflake-connector-python"
    Ensure-PipPackage -Package "pipelinewise-tap-snowflake" -InstallArgs "pipelinewise-tap-snowflake"
    Ensure-PipPackage -Package "faker" -InstallArgs "faker"

    $numpyVer = (& pip show numpy 2>$null | Select-String '^Version:' | ForEach-Object { $_.ToString().Split(':')[1].Trim() })
    if ($numpyVer -and $numpyVer -like '2*') {
        Write-Host "   → Downgrading numpy to <2 for compatibility..." -ForegroundColor Cyan
        & pip install "numpy<2" --quiet 2>$null
        Write-Host "   ✓ numpy aligned" -ForegroundColor Green
    } elseif (-not $numpyVer) {
        Write-Host "   → Installing numpy<2..." -ForegroundColor Cyan
        & pip install "numpy<2" --quiet 2>$null
        Write-Host "   ✓ numpy installed" -ForegroundColor Green
    } else {
        Write-Host "   ✓ numpy version OK ($numpyVer)" -ForegroundColor Green
    }

    $dbtVer = (& dbt --version 2>$null)
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   ✓ dbt already installed" -ForegroundColor Green
    } else {
        Write-Host "   → Installing dbt..." -ForegroundColor Cyan
        & pip install dbt-core dbt-duckdb --quiet 2>$null
        Write-Host "   ✓ dbt installed" -ForegroundColor Green
    }
}

# ============================================================================
# Step 3: Generate Test Data in Snowflake
# ============================================================================
Write-Host "`n[3/7] 🏗️  Generating Test Data in Snowflake..." -ForegroundColor Yellow

Write-Host "   → Creating tables and inserting data..." -ForegroundColor Cyan
$output = python generate_snowflake_data.py --config $Config --customers $Customers --products $Products --orders $Orders 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "   ✓ Generated $Customers customers, $Products products, $Orders orders" -ForegroundColor Green
} else {
    Write-Host "   ✗ Data generation failed" -ForegroundColor Red
    Write-Host $output -ForegroundColor Red
    exit 1
}

# ============================================================================
# Step 4: Discover Snowflake Schema (skip if requested and file exists)
# ============================================================================
Write-Host "`n[4/7] 🔍 Discovering Snowflake Schema..." -ForegroundColor Yellow
if ($SkipDiscovery -and (Test-Path catalog.json)) {
    Write-Host "   ⊘ Skipping discovery (per flag)" -ForegroundColor Yellow
} else {
    if (-not (Test-Path $TapConfig)) {
        Write-Host "   → Creating tap config..." -ForegroundColor Cyan
        $cfg = Get-Content $Config -Raw
        $account   = ($cfg | Select-String '^account:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $user      = ($cfg | Select-String '^user:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $password  = ($cfg | Select-String '^password:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $role      = ($cfg | Select-String '^role:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $warehouse = ($cfg | Select-String '^warehouse:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $dbname    = ($cfg | Select-String '^database:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $schema    = ($cfg | Select-String '^schema:\s*(.+)$').Matches.Groups[1].Value.Trim()
        $tapJson = @{
            account=$account; user=$user; password=$password; role=$role;
            warehouse=$warehouse; dbname=$dbname; schema=$schema;
            tables="${dbname}.${schema}.CUSTOMERS,${dbname}.${schema}.PRODUCTS,${dbname}.${schema}.ORDERS"
        } | ConvertTo-Json -Compress
        $tapJson | Out-File -FilePath $TapConfig -Encoding UTF8
    }

    Write-Host "   → Running tap-snowflake discovery..." -ForegroundColor Cyan
    tap-snowflake --config $TapConfig --discover > catalog.json 2>$null
    if (Test-Path catalog.json) {
        try {
            $catalog = Get-Content catalog.json -Raw | ConvertFrom-Json
            $streamCount = $catalog.streams.Count
            Write-Host "   ✓ Discovered $streamCount streams" -ForegroundColor Green
        } catch {
            Write-Host "   ⚠ Discovery completed but catalog may have warnings" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   ✗ Discovery failed" -ForegroundColor Red
        exit 1
    }
}

# ============================================================================
# Step 5: Generate dbt Sources (skip if requested and files exist)
# ============================================================================
Write-Host "`n[5/7] 📝 Generating dbt Sources..." -ForegroundColor Yellow
$sourcesFile = "$DbtProject\models\sources\bootcamp_snowflake_sources.yml"
$stagingDir  = "$DbtProject\models\staging\bootcamp_snowflake"

if ($SkipDbtGen -and (Test-Path $sourcesFile) -and (Test-Path $stagingDir)) {
    Write-Host "   ⊘ Skipping dbt generation (per flag)" -ForegroundColor Yellow
} else {
    Write-Host "   → Creating dbt source definitions..." -ForegroundColor Cyan
    $dbtOutput = singer-framework generate-sources catalog.json $Config --dbt-project $DbtProject --generate-models 2>&1
    if ($dbtOutput -match "✅ Source file created" -and $dbtOutput -match "✅ Generated") {
        Write-Host "   ✓ dbt sources and models generated" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ dbt generation had warnings" -ForegroundColor Yellow
        Write-Host $dbtOutput -ForegroundColor Gray
    }
}

# ============================================================================
# Step 6: Verify Generated Files
# ============================================================================
Write-Host "`n[6/7] ✅ Verifying Generated Files..." -ForegroundColor Yellow
if (Test-Path $sourcesFile) {
    Write-Host "   ✓ dbt sources file created" -ForegroundColor Green
} else {
    Write-Host "   ✗ dbt sources file not found" -ForegroundColor Red
}

if (Test-Path $stagingDir) {
    $modelCount = (Get-ChildItem $stagingDir -Filter *.sql).Count
    Write-Host "   ✓ $modelCount staging models created" -ForegroundColor Green
} else {
    Write-Host "   ✗ Staging models directory not found" -ForegroundColor Red
}

# ============================================================================
# Step 7: Test dbt Connection (Optional)
# ============================================================================
Write-Host "`n[7/7] 🧪 Testing dbt Setup..." -ForegroundColor Yellow

Set-Location $DbtProject
Write-Host "   → Running dbt debug..." -ForegroundColor Cyan
dbt debug --quiet 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "   ✓ dbt is configured correctly" -ForegroundColor Green
} else {
    Write-Host "   ⚠ dbt debug had warnings (may be normal)" -ForegroundColor Yellow
}
Set-Location $ProjectRoot

# ============================================================================
# SUMMARY
# ============================================================================
Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║              ✅ DEMO SETUP COMPLETE!                       ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`n📊 What's Ready:" -ForegroundColor Cyan
Write-Host "   ✓ Snowflake database populated ($Customers customers, $Products products, $Orders orders)" -ForegroundColor White
Write-Host "   ✓ Schema discovered (catalog.json)" -ForegroundColor White
Write-Host "   ✓ dbt sources generated" -ForegroundColor White
Write-Host "   ✓ dbt staging models created" -ForegroundColor White

Write-Host "`n📁 Key Files:" -ForegroundColor Cyan
Write-Host "   • $Config - Snowflake configuration" -ForegroundColor White
Write-Host "   • catalog.json - Discovered schema" -ForegroundColor White
Write-Host "   • dbthero\dbthero\models\sources\bootcamp_snowflake_sources.yml" -ForegroundColor White
Write-Host "   • dbthero\dbthero\models\staging\bootcamp_snowflake\*.sql" -ForegroundColor White

Write-Host "`n🎤 Presentation Flow:" -ForegroundColor Yellow
Write-Host "   1. Show config:" -ForegroundColor White
Write-Host "      cat $Config" -ForegroundColor Gray
Write-Host ""
Write-Host "   2. Show discovered catalog:" -ForegroundColor White
Write-Host "      cat catalog.json | ConvertFrom-Json | Select-Object -ExpandProperty streams | Select-Object tap_stream_id" -ForegroundColor Gray
Write-Host ""
Write-Host "   3. Show generated dbt sources:" -ForegroundColor White
Write-Host "      cat dbthero\dbthero\models\sources\bootcamp_snowflake_sources.yml" -ForegroundColor Gray
Write-Host ""
Write-Host "   4. Run dbt models:" -ForegroundColor White
Write-Host "      cd dbthero\dbthero" -ForegroundColor Gray
Write-Host "      dbt run --models staging.bootcamp_snowflake.*" -ForegroundColor Gray
Write-Host ""
Write-Host "   5. Test dbt sources:" -ForegroundColor White
Write-Host "      dbt test --models source:bootcamp_snowflake" -ForegroundColor Gray

Write-Host "`n💡 Tips:" -ForegroundColor Yellow
Write-Host "   • Run .\demo_cleanup.ps1 to reset for another demo" -ForegroundColor White
Write-Host "   • Customize data: -Customers 100 -Products 50 -Orders 200" -ForegroundColor White

Write-Host "`n✨ Ready to present! Break a leg! 🎭" -ForegroundColor Green
Write-Host ""
