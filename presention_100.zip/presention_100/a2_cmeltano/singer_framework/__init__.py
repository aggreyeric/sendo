"""
Pydantic-Based Singer Framework

A modern, type-safe abstraction layer over Singer taps and targets using Pydantic 
for configuration management and dbt integration.
"""

__version__ = "0.1.0"
__author__ = "Singer Pydantic Framework Team"

# Core framework components
from .config import BaseConnectorConfig, ConnectorRegistry
from .discovery import SchemaDiscovery, TapRegistry
from .state import StateManager
from .singer_integration import SingerTap, SingerTarget

# dbt integration (optional import)
try:
    from .dbt.plugin import IngestionPlugin
    HAS_DBT = True
except ImportError:
    HAS_DBT = False

__all__ = [
    "__version__",
    "BaseConnectorConfig",
    "ConnectorRegistry", 
    "SchemaDiscovery",
    "TapRegistry",
    "StateManager",
    "SingerTap",
    "SingerTarget",
]

if HAS_DBT:
    __all__.append("IngestionPlugin")
