"""
Main CLI interface for the Singer Pydantic Framework.

This module provides the command-line interface that matches the documented
patterns and integrates with the framework components.
"""

import json
import yaml
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, Confirm

from . import __version__
from .config import (
    ConnectorRegistry, 
    load_yaml_config, 
    save_yaml_config,
    parse_connector_config
)
from .discovery import SchemaDiscovery, TapRegistry
from .singer_integration import (
    SingerTap, 
    create_catalog_with_selection,
    validate_catalog
)
from .state import StateManager
from .interactive import InteractiveSetup

app = typer.Typer(
    name="singer-framework",
    help="Pydantic-Based Singer Framework - A modern data integration framework",
    add_completion=False,
)
console = Console()


@app.command()
def version():
    """Show the framework version."""
    console.print(f"Singer Pydantic Framework v{__version__}", style="bold green")


@app.command()
def init(
    source_type: Optional[str] = typer.Option(None, "--source-type", "-s", help="Source type (postgresql, mysql, api, etc.)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output configuration file"),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Use interactive setup"),
):
    """Initialize a new ingestion configuration."""
    
    # Initialize registries
    connector_registry = ConnectorRegistry()
    discovery = SchemaDiscovery()
    tap_registry = TapRegistry()
    
    # Discover available taps
    console.print("[blue]Discovering available Singer taps...[/blue]")
    discovered_taps = discovery.discover_taps()
    
    # Register discovered taps
    for connector_type, tap_info in discovered_taps.items():
        config_model = discovery.generate_config_model(tap_info.name, tap_info.config_schema)
        tap_registry.register_tap(connector_type, tap_info, config_model)
    
    # Show available source types if none specified
    if not source_type:
        available_types = list(set(
            list(connector_registry.list_connector_types()) + 
            list(tap_registry.list_connector_types())
        ))
        
        if not available_types:
            console.print("[red]No source types available. Please install Singer taps.[/red]")
            raise typer.Exit(1)
        
        console.print("\n[bold]Available source types:[/bold]")
        for i, conn_type in enumerate(available_types, 1):
            status = "✓ Tap available" if tap_registry.is_registered(conn_type) else "⚠ Built-in only"
            console.print(f"  {i}. {conn_type} ({status})")
        
        if interactive:
            choice = Prompt.ask(
                "\nSelect source type",
                choices=[str(i) for i in range(1, len(available_types) + 1)]
            )
            source_type = available_types[int(choice) - 1]
        else:
            console.print("\n[red]Please specify --source-type[/red]")
            raise typer.Exit(1)
    
    # Determine output file
    if not output:
        output = Path(f"{source_type}_config.yml")
    
    if output.exists() and not Confirm.ask(f"Configuration file {output} exists. Overwrite?"):
        raise typer.Exit(0)
    
    # Run interactive setup
    if interactive:
        setup = InteractiveSetup(connector_registry, tap_registry, discovery)
        config = setup.run_setup(source_type)
    else:
        # Create basic configuration for non-interactive mode
        try:
            config_class = connector_registry.get_config_class(source_type)
            config = {
                "name": f"my_{source_type}_source",
                "type": source_type,
                "enabled": True,
            }
            
            # Add source-specific required fields with placeholder values
            if source_type in ["postgresql", "mysql"]:
                config.update({
                    "host": "localhost",
                    "port": 5432 if source_type == "postgresql" else 3306,
                    "database": "mydb",
                    "username": "user",
                    "password": "password",
                })
                if source_type == "postgresql":
                    config["schema"] = "public"
            elif source_type == "sqlite":
                config["database_path"] = "./data.db"
            elif source_type == "duckdb":
                config["database_path"] = "./data.duckdb"
            elif source_type == "snowflake":
                config["account"] = "your_account"
                config["user"] = "your_user"
                config["password"] = "your_password"
                config["role"] = "your_role"
                config["database"] = "your_database"
                config["warehouse"] = "your_warehouse"
                config["schema"] = "public"
                config["threads"] = 4
                config["keepalives_idle"] = 240
            elif source_type == "api":
                config["base_url"] = "https://api.example.com"
                config["api_key"] = "your_api_key_here"
            
            # Add common extraction settings
            config["incremental"] = True
            config["batch_size"] = 1000
            config["start_date"] = "2024-01-01T00:00:00Z"
            
        except ValueError:
            console.print(f"[red]Unknown source type: {source_type}[/red]")
            console.print(f"[yellow]Available types: {', '.join(connector_registry.list_connector_types())}[/yellow]")
            raise typer.Exit(1)
    
    # Save configuration
    save_yaml_config(config, output)
    
    console.print(f"\n[green]✅ Configuration saved to {output}[/green]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print(f"1. Edit {output} with your connection details")
    console.print(f"2. Run: singer-framework discover --config {output}")
    console.print(f"3. Run: singer-framework select --config {output} --all")
    console.print(f"4. Run: singer-framework sync --config {output} --catalog catalog.json")


@app.command()
def discover(
    config: Path = typer.Argument(..., help="Path to configuration file"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output catalog file"),
):
    """Discover the available tables and columns."""
    
    if not config.exists():
        console.print(f"[red]Configuration file not found: {config}[/red]")
        raise typer.Exit(1)
    
    try:
        # Load configuration
        config_data = load_yaml_config(config)
        
        # Parse connector configuration
        connector_registry = ConnectorRegistry()
        connector_config = parse_connector_config(config_data, connector_registry)
        
        # Initialize discovery
        discovery = SchemaDiscovery()
        tap_registry = TapRegistry()
        
        # Discover available taps
        discovered_taps = discovery.discover_taps()
        
        # Find the appropriate tap
        tap_info = discovered_taps.get(connector_config.type)
        if not tap_info:
            console.print(f"[red]No Singer tap found for {connector_config.type}[/red]")
            console.print("[yellow]Available taps:[/yellow]")
            for tap_type in discovered_taps.keys():
                console.print(f"  - {tap_type}")
            raise typer.Exit(1)
        
        # Create Singer tap wrapper
        singer_tap = SingerTap(
            tap_name=tap_info.name,
            executable=tap_info.executable,
            config=connector_config
        )
        
        # Run discovery
        console.print(f"[blue]Running discovery for {connector_config.name}...[/blue]")
        streams = singer_tap.discover()
        
        if not streams:
            console.print("[red]No streams discovered[/red]")
            raise typer.Exit(1)
        
        # Create catalog
        catalog = create_catalog_with_selection(streams)
        
        # Output catalog
        if output:
            with open(output, 'w') as f:
                json.dump(catalog, f, indent=2)
            console.print(f"[green]Catalog saved to {output}[/green]")
        else:
            console.print(json.dumps(catalog, indent=2))
        
        # Show summary
        console.print(f"\n[green]✅ Discovered {len(streams)} streams[/green]")
        
        # Show streams table
        table = Table(title="Discovered Streams")
        table.add_column("Stream", style="cyan")
        table.add_column("Tables/Fields", style="magenta")
        table.add_column("Type", style="green")
        
        for stream in streams:
            field_count = len(stream.schema.get("properties", {}))
            stream_type = "Table" if field_count > 0 else "Unknown"
            table.add_row(stream.stream, str(field_count), stream_type)
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]Discovery failed: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def select(
    config: Path = typer.Argument(..., help="Path to configuration file"),
    catalog: Optional[Path] = typer.Option(None, "--catalog", "-c", help="Path to catalog file"),
    streams: Optional[str] = typer.Option(None, "--streams", help="Comma-separated list of streams to select"),
    all: bool = typer.Option(False, "--all", help="Select all streams"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output catalog file"),
):
    """Select which streams to sync."""
    
    if not config.exists():
        console.print(f"[red]Configuration file not found: {config}[/red]")
        raise typer.Exit(1)
    
    # Determine catalog file
    if not catalog:
        catalog = config.parent / "catalog.json"
    
    if not catalog.exists():
        console.print(f"[red]Catalog file not found: {catalog}[/red]")
        console.print(f"[yellow]Run discovery first: singer-framework discover --config {config}[/yellow]")
        raise typer.Exit(1)
    
    try:
        # Load catalog
        with open(catalog, 'r') as f:
            catalog_data = json.load(f)
        
        if not validate_catalog(catalog_data):
            console.print("[red]Invalid catalog format[/red]")
            raise typer.Exit(1)
        
        # Determine selected streams
        if all:
            selected_streams = None  # Select all
        elif streams:
            selected_streams = [s.strip() for s in streams.split(",")]
        else:
            # Interactive selection
            available_streams = [s["stream"] for s in catalog_data["streams"]]
            console.print("\n[bold]Available streams:[/bold]")
            for i, stream_name in enumerate(available_streams, 1):
                console.print(f"  {i}. {stream_name}")
            
            selection = Prompt.ask(
                "\nEnter stream numbers (comma-separated) or 'all'",
                default="all"
            )
            
            if selection.lower() == "all":
                selected_streams = None
            else:
                try:
                    indices = [int(x.strip()) - 1 for x in selection.split(",")]
                    selected_streams = [available_streams[i] for i in indices]
                except (ValueError, IndexError):
                    console.print("[red]Invalid selection[/red]")
                    raise typer.Exit(1)
        
        # Update catalog with selection
        for stream in catalog_data["streams"]:
            for meta in stream["metadata"]:
                if meta.get("breadcrumb") == []:
                    # Stream-level metadata
                    is_selected = (
                        selected_streams is None or 
                        stream["stream"] in selected_streams
                    )
                    meta["metadata"]["selected"] = is_selected
        
        # Save updated catalog
        output_file = output or catalog
        with open(output_file, 'w') as f:
            json.dump(catalog_data, f, indent=2)
        
        # Show selection summary
        selected_count = sum(
            1 for stream in catalog_data["streams"]
            for meta in stream["metadata"]
            if meta.get("breadcrumb") == [] and meta["metadata"].get("selected", False)
        )
        
        console.print(f"\n[green]✅ Selected {selected_count} streams[/green]")
        console.print(f"[green]Updated catalog saved to {output_file}[/green]")
        
    except Exception as e:
        console.print(f"[red]Selection failed: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def sync(
    config: Path = typer.Argument(..., help="Path to configuration file"),
    catalog: Optional[Path] = typer.Option(None, "--catalog", "-c", help="Path to catalog file"),
    state: Optional[Path] = typer.Option(None, "--state", "-s", help="Path to state file"),
    state_dir: Optional[Path] = typer.Option(None, "--state-dir", help="Directory for state files"),
):
    """Sync the data."""
    
    if not config.exists():
        console.print(f"[red]Configuration file not found: {config}[/red]")
        raise typer.Exit(1)
    
    # Determine catalog file
    if not catalog:
        catalog = config.parent / "catalog.json"
    
    if not catalog.exists():
        console.print(f"[red]Catalog file not found: {catalog}[/red]")
        console.print(f"[yellow]Run selection first: singer-framework select --config {config} --all[/yellow]")
        raise typer.Exit(1)
    
    try:
        # Load configuration
        config_data = load_yaml_config(config)
        
        # Parse connector configuration
        connector_registry = ConnectorRegistry()
        connector_config = parse_connector_config(config_data, connector_registry)
        
        # Load catalog
        with open(catalog, 'r') as f:
            catalog_data = json.load(f)
        
        # Load state if provided
        state_data = None
        if state and state.exists():
            with open(state, 'r') as f:
                state_data = json.load(f)
        
        # Initialize state manager
        state_manager = None
        if state_dir:
            state_manager = StateManager(state_dir)
        
        # Initialize discovery and find tap
        discovery = SchemaDiscovery()
        discovered_taps = discovery.discover_taps()
        
        tap_info = discovered_taps.get(connector_config.type)
        if not tap_info:
            console.print(f"[red]No Singer tap found for {connector_config.type}[/red]")
            raise typer.Exit(1)
        
        # Create Singer tap wrapper
        singer_tap = SingerTap(
            tap_name=tap_info.name,
            executable=tap_info.executable,
            config=connector_config,
            state_manager=state_manager
        )
        
        # Run sync
        console.print(f"[blue]Starting sync for {connector_config.name}...[/blue]")
        
        # Start the tap process
        tap_process = singer_tap.sync(catalog_data, state_data)
        
        # Stream output to stdout (Singer format)
        try:
            for line in tap_process.stdout:
                print(line.rstrip())
            
            # Wait for process to complete
            return_code = tap_process.wait()
            
            if return_code == 0:
                console.print("[green]✅ Sync completed successfully[/green]")
            else:
                console.print(f"[red]❌ Sync failed with code {return_code}[/red]")
                if tap_process.stderr:
                    stderr_output = tap_process.stderr.read()
                    console.print(f"[red]Error: {stderr_output}[/red]")
                raise typer.Exit(return_code)
                
        except KeyboardInterrupt:
            console.print("\n[yellow]Sync interrupted by user[/yellow]")
            tap_process.terminate()
            raise typer.Exit(1)
        
    except Exception as e:
        console.print(f"[red]Sync failed: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def list_sources():
    """List available source types."""
    
    # Initialize registries
    connector_registry = ConnectorRegistry()
    discovery = SchemaDiscovery()
    
    console.print("[blue]Discovering available Singer taps...[/blue]")
    discovered_taps = discovery.discover_taps()
    
    # Create table
    table = Table(title="Available Source Types")
    table.add_column("Type", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Description", style="magenta")
    
    # Built-in connectors
    for conn_type in connector_registry.list_connector_types():
        status = "✓ Tap available" if conn_type in discovered_taps else "⚠ Built-in only"
        description = f"Built-in {conn_type} connector"
        table.add_row(conn_type, status, description)
    
    # Discovered taps
    for conn_type, tap_info in discovered_taps.items():
        if conn_type not in connector_registry.list_connector_types():
            table.add_row(conn_type, "✓ Tap available", tap_info.description or "Singer tap")
    
    console.print(table)


@app.command()
def generate_sources(
    catalog: Path = typer.Argument(..., help="Path to Singer catalog.json"),
    config: Path = typer.Argument(..., help="Path to Singer config.yml"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output sources.yml file"),
    dbt_project: Optional[Path] = typer.Option(None, "--dbt-project", help="Path to dbt project"),
    generate_models: bool = typer.Option(False, "--generate-models", help="Generate staging models"),
):
    """Generate dbt sources from Singer catalog."""
    
    from datetime import datetime
    
    if not catalog.exists():
        console.print(f"[red]Catalog file not found: {catalog}[/red]")
        raise typer.Exit(1)
    
    if not config.exists():
        console.print(f"[red]Config file not found: {config}[/red]")
        raise typer.Exit(1)
    
    try:
        # Load catalog
        console.print(f"[blue]📖 Loading catalog from {catalog}...[/blue]")
        with open(catalog, 'r') as f:
            catalog_data = json.load(f)
        
        # Load config
        console.print(f"[blue]📖 Loading config from {config}...[/blue]")
        config_data = load_yaml_config(config)
        
        # Generate source
        console.print("[blue]🔨 Generating dbt source definition...[/blue]")
        source_name = config_data.get('name', 'singer_source')
        source_type = config_data.get('type', 'unknown')
        
        tables = []
        for stream in catalog_data.get('streams', []):
            stream_name = stream.get('tap_stream_id') or stream.get('stream')
            schema = stream.get('schema', {})
            properties = schema.get('properties', {})
            metadata = stream.get('metadata', [])
            
            # Find primary keys
            primary_keys = []
            for meta in metadata:
                if meta.get('breadcrumb') == [] and 'table-key-properties' in meta.get('metadata', {}):
                    primary_keys = meta['metadata']['table-key-properties']
                    break
            
            # Build columns
            columns = []
            for col_name, col_schema in properties.items():
                col_type = col_schema.get('type', 'string')
                
                # Convert Singer type to dbt type
                if isinstance(col_type, list):
                    col_type = [t for t in col_type if t != "null"][0] if len([t for t in col_type if t != "null"]) > 0 else "string"
                
                type_map = {
                    "string": "varchar", "integer": "integer", "number": "decimal",
                    "boolean": "boolean", "object": "json", "array": "json",
                    "date-time": "timestamp", "date": "date", "time": "time"
                }
                dbt_type = type_map.get(col_type, "varchar")
                
                column_def = {
                    'name': col_name,
                    'data_type': dbt_type,
                    'description': col_schema.get('description', f'{col_name} column')
                }
                
                if col_name in primary_keys:
                    column_def['tests'] = ['unique', 'not_null']
                
                columns.append(column_def)
            
            tables.append({
                'name': stream_name,
                'description': f'{stream_name} from {source_type}',
                'columns': columns
            })
        
        # Build source definition
        source = {
            'version': 2,
            'sources': [{
                'name': source_name,
                'description': f'Data from {source_type} via Singer Framework',
                'loader': 'singer_framework',
                'tables': tables,
                'meta': {
                    'generated_at': datetime.now().isoformat(),
                    'source_type': source_type
                }
            }]
        }
        
        # Determine output path
        if dbt_project:
            dbt_path = Path(dbt_project)
            sources_dir = dbt_path / 'models' / 'sources'
            sources_dir.mkdir(parents=True, exist_ok=True)
            output_path = sources_dir / f'{source_name}_sources.yml'
        elif output:
            output_path = output
        else:
            output_path = Path(f'{source_name}_sources.yml')
        
        # Write source file
        console.print(f"[blue]💾 Writing source to {output_path}...[/blue]")
        with open(output_path, 'w') as f:
            yaml.dump(source, f, default_flow_style=False, sort_keys=False, indent=2)
        
        console.print(f"[green]✅ Source file created: {output_path}[/green]")
        
        # Generate staging models if requested
        if generate_models and dbt_project:
            models_dir = Path(dbt_project) / 'models' / 'staging' / source_name
            models_dir.mkdir(parents=True, exist_ok=True)
            
            console.print(f"[blue]🔨 Generating staging models...[/blue]")
            
            for table in tables:
                table_name = table['name']
                model_name = f"stg_{source_name}_{table_name}"
                model_path = models_dir / f"{model_name}.sql"
                
                # Generate SQL
                columns_str = ",\n".join([f"        {col['name']}" for col in table['columns']])
                sql = f"""{{{{ config(
    materialized='incremental',
    unique_key='{table['columns'][0]['name']}',
    on_schema_change='sync_all_columns'
) }}}}

with source as (
    select * from {{{{ source('{source_name}', '{table_name}') }}}}
),

renamed as (
    select
{columns_str},
        current_timestamp() as _loaded_at
    from source
)

select * from renamed

{{% if is_incremental() %}}
    where _loaded_at > (select max(_loaded_at) from {{{{ this }}}})
{{% endif %}}
"""
                
                with open(model_path, 'w') as f:
                    f.write(sql)
                
                console.print(f"   [green]✓ Created {model_name}.sql[/green]")
            
            console.print(f"[green]✅ Generated {len(tables)} staging models[/green]")
        
        # Print summary
        console.print(f"\n[cyan]📊 Summary:[/cyan]")
        console.print(f"   Source name: [yellow]{source_name}[/yellow]")
        console.print(f"   Tables: [yellow]{len(tables)}[/yellow]")
        console.print(f"   Output: [yellow]{output_path}[/yellow]")
        
        if generate_models and dbt_project:
            console.print(f"   Models: [yellow]{models_dir}[/yellow]")
        
        console.print(f"\n[cyan]🚀 Next steps:[/cyan]")
        if dbt_project:
            console.print(f"   1. cd {dbt_project}")
            console.print(f"   2. dbt run --models staging.{source_name}.*")
            console.print(f"   3. dbt test --models source:{source_name}")
        else:
            console.print(f"   1. Copy {output_path} to your dbt project")
            console.print(f"   2. dbt run")
        
    except Exception as e:
        console.print(f"[red]Failed to generate sources: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
