"""
Interactive setup utilities for the Singer Pydantic Framework.

This module provides interactive prompts for configuring data sources.
"""

from typing import Dict, Any, Optional
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from datetime import datetime

console = Console()


class InteractiveSetup:
    """Interactive setup wizard for data source configuration."""
    
    def __init__(self, connector_registry=None, tap_registry=None, discovery=None):
        """
        Initialize interactive setup.
        
        Args:
            connector_registry: Registry of connector types
            tap_registry: Registry of discovered Singer taps
            discovery: Schema discovery instance
        """
        self.console = Console()
        self.connector_registry = connector_registry
        self.tap_registry = tap_registry
        self.discovery = discovery
    
    def run_setup(self, connector_type: str) -> Dict[str, Any]:
        """
        Run complete interactive setup for a connector.
        
        Args:
            connector_type: Type of connector (e.g., 'postgresql', 'mysql', 'sqlite')
            
        Returns:
            Dictionary of configuration values
        """
        self.console.print(Panel.fit(
            f"[bold cyan]Singer Framework Configuration Setup[/bold cyan]\n"
            f"Source Type: [yellow]{connector_type}[/yellow]",
            border_style="cyan"
        ))
        
        config = self.setup_connector(connector_type)
        
        self.console.print("\n[green]✅ Configuration complete![/green]")
        return config
    
    def setup_connector(self, connector_type: str) -> Dict[str, Any]:
        """
        Run interactive setup for a connector.
        
        Args:
            connector_type: Type of connector (e.g., 'postgresql', 'mysql', 'sqlite')
            
        Returns:
            Dictionary of configuration values
        """
        self.console.print(f"\n[bold blue]📋 Basic Configuration[/bold blue]\n")
        
        config = {
            "type": connector_type,
            "name": Prompt.ask("Connector name", default=f"{connector_type}_source"),
            "enabled": Confirm.ask("Enable this connector?", default=True)
        }
        
        # SQLite-specific configuration
        if connector_type == "sqlite":
            self.console.print(f"\n[bold blue]🗄️  SQLite Configuration[/bold blue]\n")
            config["database_path"] = Prompt.ask(
                "Database file path",
                default="./data.db"
            )
        
        # PostgreSQL configuration
        elif connector_type == "postgresql":
            self.console.print(f"\n[bold blue]🐘 PostgreSQL Configuration[/bold blue]\n")
            config["host"] = Prompt.ask("Host", default="localhost")
            config["port"] = int(Prompt.ask("Port", default="5432"))
            config["database"] = Prompt.ask("Database name")
            config["username"] = Prompt.ask("Username", default="postgres")
            config["password"] = Prompt.ask("Password", password=True)
            config["schema"] = Prompt.ask("Schema", default="public")
        
        # MySQL configuration
        elif connector_type == "mysql":
            self.console.print(f"\n[bold blue]🐬 MySQL Configuration[/bold blue]\n")
            config["host"] = Prompt.ask("Host", default="localhost")
            config["port"] = int(Prompt.ask("Port", default="3306"))
            config["database"] = Prompt.ask("Database name")
            config["username"] = Prompt.ask("Username", default="root")
            config["password"] = Prompt.ask("Password", password=True)
        
        # API configuration
        elif connector_type == "api":
            self.console.print(f"\n[bold blue]🌐 API Configuration[/bold blue]\n")
            config["base_url"] = Prompt.ask("API Base URL")
            if Confirm.ask("Does the API require authentication?", default=True):
                config["api_key"] = Prompt.ask("API Key", password=True)
        
        # DuckDB configuration
        elif connector_type == "duckdb":
            self.console.print(f"\n[bold blue]🦆 DuckDB Configuration[/bold blue]\n")
            config["database_path"] = Prompt.ask(
                "Database file path",
                default="./data.duckdb"
            )
        
        # Snowflake configuration
        elif connector_type == "snowflake":
            self.console.print(f"\n[bold blue]❄️  Snowflake Configuration[/bold blue]\n")
            config["account"] = Prompt.ask("Account identifier")
            config["user"] = Prompt.ask("Username")
            config["password"] = Prompt.ask("Password", password=True)
            config["role"] = Prompt.ask("Role")
            config["database"] = Prompt.ask("Database")
            config["warehouse"] = Prompt.ask("Warehouse")
            config["schema"] = Prompt.ask("Schema", default="public")
            config["threads"] = int(Prompt.ask("Threads", default="4"))
            config["keepalives_idle"] = int(Prompt.ask("Keepalives idle", default="240"))
        
        # Common extraction settings
        self.console.print(f"\n[bold blue]⚙️  Extraction Settings[/bold blue]\n")
        config["incremental"] = Confirm.ask("Enable incremental extraction?", default=True)
        config["batch_size"] = int(Prompt.ask("Batch size (records per batch)", default="1000"))
        
        if config["incremental"]:
            config["start_date"] = Prompt.ask(
                "Start date (YYYY-MM-DD)",
                default=datetime.now().strftime("%Y-01-01")
            ) + "T00:00:00Z"
        
        return config
