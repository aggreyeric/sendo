"""
Schema discovery and tap registry for the Singer Pydantic Framework.

This module handles discovering available Singer taps, generating configuration
models, and managing the tap registry.
"""

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

import singer
from pydantic import BaseModel, Field, create_model
from rich.console import Console

from .config import BaseConnectorConfig, ConnectorRegistry

console = Console()


class TapInfo(BaseModel):
    """Information about a discovered Singer tap."""
    
    name: str = Field(..., description="Tap name")
    executable: str = Field(..., description="Executable command")
    connector_type: str = Field(..., description="Connector type")
    config_schema: Dict[str, Any] = Field(..., description="Configuration JSON schema")
    description: Optional[str] = Field(None, description="Tap description")
    version: Optional[str] = Field(None, description="Tap version")


class StreamInfo(BaseModel):
    """Information about a discovered stream."""
    
    tap_stream_id: str = Field(..., description="Stream ID")
    stream: str = Field(..., description="Stream name")
    schema: Dict[str, Any] = Field(..., description="JSON schema")
    metadata: List[Dict[str, Any]] = Field(default_factory=list, description="Stream metadata")


class TapRegistry:
    """Registry for Singer taps."""
    
    def __init__(self):
        self._taps: Dict[str, TapInfo] = {}
        self._config_models: Dict[str, Type[BaseConnectorConfig]] = {}
    
    def register_tap(
        self, 
        connector_type: str, 
        tap_info: TapInfo,
        config_model: Type[BaseConnectorConfig]
    ):
        """Register a Singer tap with its configuration model."""
        self._taps[connector_type] = tap_info
        self._config_models[connector_type] = config_model
    
    def get_tap_info(self, connector_type: str) -> Optional[TapInfo]:
        """Get tap information for a connector type."""
        return self._taps.get(connector_type)
    
    def get_config_model(self, connector_type: str) -> Optional[Type[BaseConnectorConfig]]:
        """Get configuration model for a connector type."""
        return self._config_models.get(connector_type)
    
    def list_connector_types(self) -> List[str]:
        """List all registered connector types."""
        return list(self._taps.keys())
    
    def is_registered(self, connector_type: str) -> bool:
        """Check if a connector type is registered."""
        return connector_type in self._taps


class SchemaDiscovery:
    """Discovers Singer taps and their schemas."""
    
    def __init__(self):
        self.console = Console()
    
    def discover_taps(self) -> Dict[str, TapInfo]:
        """
        Discover available Singer taps in the environment.
        
        Returns:
            Dictionary mapping connector types to tap information
        """
        discovered_taps = {}
        
        # List of known Singer taps to look for
        known_taps = [
            ("tap-postgres", "postgresql"),
            ("tap-mysql", "mysql"),
            ("tap-csv", "csv"),
            ("tap-salesforce", "salesforce"),
            ("tap-github", "github"),
            ("tap-stripe", "stripe"),
            ("tap-hubspot", "hubspot"),
            ("tap-google-analytics", "google_analytics"),
        ]
        
        for tap_executable, connector_type in known_taps:
            try:
                # Check if tap is available
                result = subprocess.run(
                    [tap_executable, "--help"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if result.returncode == 0:
                    # Try to get config schema
                    config_schema = self._get_tap_config_schema(tap_executable)
                    
                    tap_info = TapInfo(
                        name=tap_executable,
                        executable=tap_executable,
                        connector_type=connector_type,
                        config_schema=config_schema,
                        description=f"Singer tap for {connector_type}"
                    )
                    
                    discovered_taps[connector_type] = tap_info
                    
            except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
                # Tap not available or not working
                continue
        
        return discovered_taps
    
    def _get_tap_config_schema(self, tap_executable: str) -> Dict[str, Any]:
        """
        Get configuration schema for a Singer tap.
        
        Args:
            tap_executable: Tap executable name
            
        Returns:
            JSON schema for tap configuration
        """
        try:
            # Try to run tap with --config-schema flag (if supported)
            result = subprocess.run(
                [tap_executable, "--config-schema"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                return json.loads(result.stdout)
                
        except (subprocess.TimeoutExpired, json.JSONDecodeError, subprocess.SubprocessError):
            pass
        
        # Return basic schema if we can't get the real one
        return {
            "type": "object",
            "properties": {
                "host": {"type": "string", "description": "Host address"},
                "port": {"type": "integer", "description": "Port number"},
                "username": {"type": "string", "description": "Username"},
                "password": {"type": "string", "description": "Password"},
                "database": {"type": "string", "description": "Database name"},
            },
            "required": ["host"]
        }
    
    def discover_streams(
        self, 
        tap_executable: str, 
        config: Dict[str, Any]
    ) -> List[StreamInfo]:
        """
        Discover streams for a Singer tap.
        
        Args:
            tap_executable: Tap executable name
            config: Tap configuration
            
        Returns:
            List of discovered streams
        """
        try:
            # Create temporary config file
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump(config, f)
                config_file = f.name
            
            try:
                # Run discovery
                result = subprocess.run(
                    [tap_executable, "--config", config_file, "--discover"],
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if result.returncode == 0:
                    catalog = json.loads(result.stdout)
                    streams = []
                    
                    for stream_data in catalog.get("streams", []):
                        stream_info = StreamInfo(
                            tap_stream_id=stream_data["tap_stream_id"],
                            stream=stream_data["stream"],
                            schema=stream_data["schema"],
                            metadata=stream_data.get("metadata", [])
                        )
                        streams.append(stream_info)
                    
                    return streams
                else:
                    console.print(f"[red]Discovery failed: {result.stderr}[/red]")
                    return []
                    
            finally:
                # Clean up temp file
                Path(config_file).unlink(missing_ok=True)
                
        except Exception as e:
            console.print(f"[red]Error during discovery: {e}[/red]")
            return []
    
    def generate_config_model(
        self, 
        tap_name: str, 
        config_schema: Dict[str, Any]
    ) -> Type[BaseConnectorConfig]:
        """
        Generate a Pydantic configuration model from JSON schema.
        
        Args:
            tap_name: Name of the tap
            config_schema: JSON schema for configuration
            
        Returns:
            Pydantic model class
        """
        # Extract properties from schema
        properties = config_schema.get("properties", {})
        required_fields = set(config_schema.get("required", []))
        
        # Build field definitions
        field_definitions = {}
        
        for field_name, field_schema in properties.items():
            field_type = self._json_type_to_python_type(field_schema)
            field_description = field_schema.get("description", f"{field_name} configuration")
            
            # Determine if field is required
            if field_name in required_fields:
                field_definitions[field_name] = (field_type, Field(..., description=field_description))
            else:
                default_value = field_schema.get("default")
                field_definitions[field_name] = (
                    Optional[field_type], 
                    Field(default_value, description=field_description)
                )
        
        # Create dynamic model class
        model_name = f"{tap_name.replace('-', '_').title()}Config"
        
        # Create the model with BaseConnectorConfig as base
        config_model = create_model(
            model_name,
            __base__=BaseConnectorConfig,
            **field_definitions
        )
        
        return config_model
    
    def _json_type_to_python_type(self, field_schema: Dict[str, Any]) -> Type:
        """Convert JSON schema type to Python type."""
        json_type = field_schema.get("type", "string")
        
        type_mapping = {
            "string": str,
            "integer": int,
            "number": float,
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        
        return type_mapping.get(json_type, str)
    
    def test_connection(
        self, 
        tap_executable: str, 
        config: Dict[str, Any]
    ) -> bool:
        """
        Test connection for a Singer tap.
        
        Args:
            tap_executable: Tap executable name
            config: Tap configuration
            
        Returns:
            True if connection successful, False otherwise
        """
        try:
            # Create temporary config file
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump(config, f)
                config_file = f.name
            
            try:
                # Run discovery as connection test
                result = subprocess.run(
                    [tap_executable, "--config", config_file, "--discover"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                
                return result.returncode == 0
                
            finally:
                # Clean up temp file
                Path(config_file).unlink(missing_ok=True)
                
        except Exception:
            return False
