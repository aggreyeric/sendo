"""
Singer integration layer for the Pydantic Framework.

This module provides wrappers around Singer taps and targets with
configuration validation and state management.
"""

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import singer
from rich.console import Console

from .config import BaseConnectorConfig, load_yaml_config
from .discovery import StreamInfo
from .state import StateManager

console = Console()


class SingerTap:
    """Wrapper for Singer taps with configuration validation."""
    
    def __init__(
        self, 
        tap_name: str, 
        executable: str,
        config: BaseConnectorConfig,
        state_manager: Optional[StateManager] = None
    ):
        """
        Initialize Singer tap wrapper.
        
        Args:
            tap_name: Name of the tap
            executable: Tap executable command
            config: Validated configuration
            state_manager: Optional state manager
        """
        self.tap_name = tap_name
        self.executable = executable
        self.config = config
        self.state_manager = state_manager
        self.console = Console()
    
    def discover(self) -> List[StreamInfo]:
        """
        Run discovery to get available streams.
        
        Returns:
            List of discovered streams
        """
        try:
            # Create temporary config file
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                # Convert Pydantic config to dict
                config_dict = self.config.dict(exclude_unset=True)
                json.dump(config_dict, f)
                config_file = f.name
            
            try:
                # Run discovery
                result = subprocess.run(
                    [self.executable, "--config", config_file, "--discover"],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
                
                if result.returncode != 0:
                    self.console.print(f"[red]Discovery failed: {result.stderr}[/red]")
                    return []
                
                # Parse catalog
                catalog = json.loads(result.stdout)
                streams = []
                
                for stream_data in catalog.get("streams", []):
                    stream_info = StreamInfo(
                        tap_stream_id=stream_data["tap_stream_id"],
                        stream=stream_data["stream"],
                        schema=stream_data["schema"],
                        metadata=stream_data.get("metadata", [])
                    )
                    streams.append(stream_info)
                
                self.console.print(f"[green]Discovered {len(streams)} streams[/green]")
                return streams
                
            finally:
                # Clean up temp file
                Path(config_file).unlink(missing_ok=True)
                
        except Exception as e:
            self.console.print(f"[red]Error during discovery: {e}[/red]")
            return []
    
    def sync(
        self, 
        catalog: Dict[str, Any], 
        state: Optional[Dict[str, Any]] = None
    ) -> subprocess.Popen:
        """
        Run sync with the provided catalog.
        
        Args:
            catalog: Singer catalog
            state: Optional state for incremental sync
            
        Returns:
            Subprocess handle for the running tap
        """
        try:
            # Create temporary files
            import tempfile
            
            # Config file
            config_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
            config_dict = self.config.dict(exclude_unset=True)
            json.dump(config_dict, config_file)
            config_file.close()
            
            # Catalog file
            catalog_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
            json.dump(catalog, catalog_file)
            catalog_file.close()
            
            # State file (if provided)
            state_file = None
            if state:
                state_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
                json.dump(state, state_file)
                state_file.close()
            
            # Build command
            cmd = [
                self.executable,
                "--config", config_file.name,
                "--catalog", catalog_file.name
            ]
            
            if state_file:
                cmd.extend(["--state", state_file.name])
            
            # Start the tap process
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.console.print(f"[green]Started sync for {self.tap_name}[/green]")
            return process
            
        except Exception as e:
            self.console.print(f"[red]Error starting sync: {e}[/red]")
            raise
    
    def test_connection(self) -> bool:
        """
        Test connection to the data source.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            # Run discovery as a connection test
            streams = self.discover()
            return len(streams) > 0
        except Exception:
            return False


class SingerTarget:
    """Wrapper for Singer targets with configuration validation."""
    
    def __init__(
        self, 
        target_name: str, 
        executable: str,
        config: BaseConnectorConfig
    ):
        """
        Initialize Singer target wrapper.
        
        Args:
            target_name: Name of the target
            executable: Target executable command
            config: Validated configuration
        """
        self.target_name = target_name
        self.executable = executable
        self.config = config
        self.console = Console()
    
    def run(self, input_stream: Optional[subprocess.Popen] = None) -> subprocess.Popen:
        """
        Run the target.
        
        Args:
            input_stream: Optional input stream (from a tap)
            
        Returns:
            Subprocess handle for the running target
        """
        try:
            # Create temporary config file
            import tempfile
            config_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
            config_dict = self.config.dict(exclude_unset=True)
            json.dump(config_dict, config_file)
            config_file.close()
            
            # Build command
            cmd = [self.executable, "--config", config_file.name]
            
            # Start the target process
            stdin_source = input_stream.stdout if input_stream else sys.stdin
            
            process = subprocess.Popen(
                cmd,
                stdin=stdin_source,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.console.print(f"[green]Started target {self.target_name}[/green]")
            return process
            
        except Exception as e:
            self.console.print(f"[red]Error starting target: {e}[/red]")
            raise


class SingerPipeline:
    """Manages a complete Singer pipeline (tap -> target)."""
    
    def __init__(
        self, 
        tap: SingerTap, 
        target: SingerTarget,
        state_manager: Optional[StateManager] = None
    ):
        """
        Initialize Singer pipeline.
        
        Args:
            tap: Singer tap wrapper
            target: Singer target wrapper
            state_manager: Optional state manager
        """
        self.tap = tap
        self.target = target
        self.state_manager = state_manager
        self.console = Console()
    
    def run(
        self, 
        catalog: Dict[str, Any], 
        state: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Run the complete pipeline.
        
        Args:
            catalog: Singer catalog
            state: Optional state for incremental sync
            
        Returns:
            True if pipeline completed successfully
        """
        try:
            self.console.print("[blue]Starting Singer pipeline...[/blue]")
            
            # Start tap
            tap_process = self.tap.sync(catalog, state)
            
            # Start target
            target_process = self.target.run(tap_process)
            
            # Wait for both processes to complete
            tap_returncode = tap_process.wait()
            target_returncode = target_process.wait()
            
            if tap_returncode != 0:
                self.console.print(f"[red]Tap failed with code {tap_returncode}[/red]")
                if tap_process.stderr:
                    stderr_output = tap_process.stderr.read()
                    self.console.print(f"[red]Tap stderr: {stderr_output}[/red]")
                return False
            
            if target_returncode != 0:
                self.console.print(f"[red]Target failed with code {target_returncode}[/red]")
                if target_process.stderr:
                    stderr_output = target_process.stderr.read()
                    self.console.print(f"[red]Target stderr: {stderr_output}[/red]")
                return False
            
            self.console.print("[green]Pipeline completed successfully![/green]")
            return True
            
        except Exception as e:
            self.console.print(f"[red]Pipeline error: {e}[/red]")
            return False


def create_catalog_with_selection(
    streams: List[StreamInfo], 
    selected_streams: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Create a Singer catalog with stream selection.
    
    Args:
        streams: List of discovered streams
        selected_streams: List of stream names to select (None = select all)
        
    Returns:
        Singer catalog with selection metadata
    """
    catalog_streams = []
    
    for stream in streams:
        # Determine if stream is selected
        is_selected = (
            selected_streams is None or 
            stream.stream in selected_streams or
            stream.tap_stream_id in selected_streams
        )
        
        # Build metadata with selection
        metadata = []
        for meta in stream.metadata:
            if meta.get("breadcrumb") == []:
                # Stream-level metadata
                meta_copy = meta.copy()
                meta_copy["metadata"]["selected"] = is_selected
                metadata.append(meta_copy)
            else:
                # Field-level metadata
                metadata.append(meta)
        
        # Add stream to catalog
        catalog_stream = {
            "tap_stream_id": stream.tap_stream_id,
            "stream": stream.stream,
            "schema": stream.schema,
            "metadata": metadata
        }
        catalog_streams.append(catalog_stream)
    
    return {"streams": catalog_streams}


def validate_catalog(catalog: Dict[str, Any]) -> bool:
    """
    Validate a Singer catalog.
    
    Args:
        catalog: Singer catalog to validate
        
    Returns:
        True if catalog is valid
    """
    try:
        # Basic structure validation
        if "streams" not in catalog:
            return False
        
        for stream in catalog["streams"]:
            required_fields = ["tap_stream_id", "stream", "schema"]
            if not all(field in stream for field in required_fields):
                return False
        
        return True
        
    except Exception:
        return False
