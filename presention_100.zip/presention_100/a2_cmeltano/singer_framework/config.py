"""
Configuration management for the Singer Pydantic Framework.

This module provides Pydantic-based configuration models and YAML loading
with environment variable interpolation.
"""

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union, Literal

import yaml
from pydantic import BaseModel, Field, field_validator, ConfigDict
from jinja2 import Environment, BaseLoader


class EnvVarLoader(BaseLoader):
    """Jinja2 loader for environment variable interpolation."""
    
    def get_source(self, environment: Environment, template: str) -> tuple:
        # Simple environment variable substitution
        def env_var(var_name: str, default: str = "") -> str:
            return os.getenv(var_name, default)
        
        # Replace {{ env_var('VAR_NAME') }} patterns
        pattern = r'\{\{\s*env_var\([\'"]([^\'"]+)[\'"]\)\s*\}\}'
        result = re.sub(pattern, lambda m: env_var(m.group(1)), template)
        
        return result, None, lambda: True


class BaseConnectorConfig(BaseModel):
    """Base configuration model for all connectors."""
    
    name: str = Field(..., description="Unique name for this connector instance")
    type: str = Field(..., description="Connector type (e.g., postgresql, mysql, api)")
    enabled: bool = Field(True, description="Whether this connector is enabled")
    description: Optional[str] = Field(None, description="Human-readable description")
    
    # Common connection settings
    host: Optional[str] = Field(None, description="Host address")
    port: Optional[int] = Field(None, description="Port number")
    username: Optional[str] = Field(None, description="Username for authentication")
    password: Optional[str] = Field(None, description="Password for authentication")
    
    # Data extraction settings
    incremental: bool = Field(True, description="Enable incremental extraction")
    batch_size: int = Field(1000, description="Number of records per batch")
    start_date: Optional[str] = Field(None, description="Start date for initial extraction")
    
    model_config = ConfigDict(extra="allow")  # Allow additional fields for connector-specific config
        
    @field_validator('name')
    @classmethod
    def validate_name(cls, v):
        """Validate connector name format."""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*$', v):
            raise ValueError('Name must start with letter and contain only letters, numbers, and underscores')
        return v


class PostgreSQLConfig(BaseConnectorConfig):
    """Configuration for PostgreSQL connector."""
    
    type: Literal["postgresql"] = "postgresql"
    host: str = Field(..., description="PostgreSQL host")
    port: int = Field(5432, description="PostgreSQL port")
    database: str = Field(..., description="Database name")
    schema: str = Field("public", description="Schema name")
    
    # PostgreSQL-specific settings
    ssl_mode: str = Field("prefer", description="SSL mode")
    application_name: str = Field("singer-framework", description="Application name")


class MySQLConfig(BaseConnectorConfig):
    """Configuration for MySQL connector."""
    
    type: Literal["mysql"] = "mysql"
    host: str = Field(..., description="MySQL host")
    port: int = Field(3306, description="MySQL port")
    database: str = Field(..., description="Database name")
    
    # MySQL-specific settings
    charset: str = Field("utf8mb4", description="Character set")
    use_ssl: bool = Field(True, description="Use SSL connection")


class APIConfig(BaseConnectorConfig):
    """Configuration for REST API connector."""
    
    type: Literal["api"] = "api"
    base_url: str = Field(..., description="API base URL")
    api_key: Optional[str] = Field(None, description="API key for authentication")
    
    # API-specific settings
    rate_limit: int = Field(100, description="Requests per minute")
    timeout: int = Field(30, description="Request timeout in seconds")
    headers: Dict[str, str] = Field(default_factory=dict, description="Additional headers")


class SQLiteConfig(BaseConnectorConfig):
    """Configuration for SQLite connector."""
    
    type: Literal["sqlite"] = "sqlite"
    database_path: str = Field(..., description="Path to SQLite database file")
    
    # SQLite-specific settings
    timeout: int = Field(30, description="Connection timeout in seconds")


class DuckDBConfig(BaseConnectorConfig):
    """Configuration for DuckDB connector."""
    
    type: Literal["duckdb"] = "duckdb"
    database_path: str = Field(..., description="Path to DuckDB database file")
    
    # DuckDB-specific settings
    read_only: bool = Field(False, description="Open database in read-only mode")
    threads: int = Field(4, description="Number of threads to use")


class SnowflakeConfig(BaseConnectorConfig):
    """Configuration for Snowflake connector."""
    
    type: Literal["snowflake"] = "snowflake"
    account: str = Field(..., description="Snowflake account identifier")
    user: str = Field(..., description="Snowflake username")
    password: str = Field(..., description="Snowflake password")
    role: str = Field(..., description="Snowflake role")
    database: str = Field(..., description="Snowflake database")
    warehouse: str = Field(..., description="Snowflake warehouse")
    schema: str = Field("public", description="Snowflake schema")
    
    # Snowflake-specific settings
    threads: int = Field(4, description="Number of threads")
    keepalives_idle: int = Field(240, description="Keepalive idle time")


class ConnectorRegistry:
    """Registry for connector configuration models."""
    
    def __init__(self):
        self._connectors: Dict[str, Type[BaseConnectorConfig]] = {}
        self._register_builtin_connectors()
    
    def _register_builtin_connectors(self):
        """Register built-in connector types."""
        self.register("postgresql", PostgreSQLConfig)
        self.register("mysql", MySQLConfig)
        self.register("api", APIConfig)
        self.register("sqlite", SQLiteConfig)
        self.register("duckdb", DuckDBConfig)
        self.register("snowflake", SnowflakeConfig)
    
    def register(self, connector_type: str, config_class: Type[BaseConnectorConfig]):
        """Register a connector configuration class."""
        self._connectors[connector_type] = config_class
    
    def get_config_class(self, connector_type: str) -> Type[BaseConnectorConfig]:
        """Get configuration class for a connector type."""
        if connector_type not in self._connectors:
            raise ValueError(f"Unknown connector type: {connector_type}")
        return self._connectors[connector_type]
    
    def list_connector_types(self) -> List[str]:
        """List all registered connector types."""
        return list(self._connectors.keys())
    
    def create_config(self, connector_type: str, **kwargs) -> BaseConnectorConfig:
        """Create a configuration instance for a connector type."""
        config_class = self.get_config_class(connector_type)
        return config_class(**kwargs)


class FrameworkConfig(BaseModel):
    """Main framework configuration."""
    
    state_dir: str = Field(".state", description="Directory for state files")
    sources: Dict[str, Dict[str, Any]] = Field(default_factory=dict, description="Source configurations")
    
    model_config = ConfigDict(extra="allow")


def load_yaml_config(config_path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load YAML configuration with environment variable interpolation.
    
    Args:
        config_path: Path to YAML configuration file
        
    Returns:
        Parsed configuration dictionary
    """
    config_path = Path(config_path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    # Read raw YAML content
    with open(config_path, 'r') as f:
        raw_content = f.read()
    
    # Apply environment variable interpolation
    env = Environment(loader=EnvVarLoader())
    template = env.from_string(raw_content)
    interpolated_content = template.render()
    
    # Parse YAML
    try:
        config = yaml.safe_load(interpolated_content)
        return config or {}
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {config_path}: {e}")


def save_yaml_config(config: Dict[str, Any], config_path: Union[str, Path]) -> None:
    """
    Save configuration to YAML file.
    
    Args:
        config: Configuration dictionary
        config_path: Path to save configuration file
    """
    config_path = Path(config_path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, indent=2)


def parse_connector_config(
    config_data: Dict[str, Any], 
    registry: ConnectorRegistry
) -> BaseConnectorConfig:
    """
    Parse connector configuration from dictionary.
    
    Args:
        config_data: Configuration dictionary
        registry: Connector registry
        
    Returns:
        Validated connector configuration
    """
    connector_type = config_data.get('type')
    if not connector_type:
        raise ValueError("Connector configuration must specify 'type'")
    
    config_class = registry.get_config_class(connector_type)
    return config_class(**config_data)
