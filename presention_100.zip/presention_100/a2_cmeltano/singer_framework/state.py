"""
State management for the Singer Pydantic Framework.

This module handles Singer state files, bookmarks, and incremental replication.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field
from rich.console import Console

console = Console()


class StreamState(BaseModel):
    """State for a single stream."""
    
    bookmarks: Dict[str, Any] = Field(default_factory=dict, description="Stream bookmarks")
    version: Optional[int] = Field(None, description="Stream version")
    currently_syncing: Optional[str] = Field(None, description="Currently syncing table")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class SingerState(BaseModel):
    """Singer state model."""
    
    bookmarks: Dict[str, StreamState] = Field(default_factory=dict, description="Stream bookmarks")
    currently_syncing: Optional[str] = Field(None, description="Currently syncing stream")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class StateManager:
    """Manages Singer state files."""
    
    def __init__(self, state_dir: Path):
        """
        Initialize state manager.
        
        Args:
            state_dir: Directory to store state files
        """
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.console = Console()
    
    def get_state_file_path(self, source_name: str) -> Path:
        """
        Get path to state file for a source.
        
        Args:
            source_name: Name of the data source
            
        Returns:
            Path to state file
        """
        return self.state_dir / f"{source_name}.state.json"
    
    def load_state(self, source_name: str) -> SingerState:
        """
        Load state for a source.
        
        Args:
            source_name: Name of the data source
            
        Returns:
            Singer state object
        """
        state_file = self.get_state_file_path(source_name)
        
        if not state_file.exists():
            return SingerState()
        
        try:
            with open(state_file, 'r') as f:
                state_data = json.load(f)
            
            # Convert to SingerState model
            bookmarks = {}
            for stream_name, stream_data in state_data.get("bookmarks", {}).items():
                if isinstance(stream_data, dict):
                    bookmarks[stream_name] = StreamState(**stream_data)
                else:
                    # Handle legacy format
                    bookmarks[stream_name] = StreamState(bookmarks={"replication_key_value": stream_data})
            
            return SingerState(
                bookmarks=bookmarks,
                currently_syncing=state_data.get("currently_syncing")
            )
            
        except (json.JSONDecodeError, Exception) as e:
            self.console.print(f"[yellow]Warning: Could not load state file {state_file}: {e}[/yellow]")
            return SingerState()
    
    def save_state(self, source_name: str, state: SingerState) -> None:
        """
        Save state for a source.
        
        Args:
            source_name: Name of the data source
            state: Singer state to save
        """
        state_file = self.get_state_file_path(source_name)
        
        try:
            # Convert to dictionary format
            state_dict = {
                "bookmarks": {},
                "currently_syncing": state.currently_syncing
            }
            
            for stream_name, stream_state in state.bookmarks.items():
                state_dict["bookmarks"][stream_name] = stream_state.dict()
            
            # Write to file
            with open(state_file, 'w') as f:
                json.dump(state_dict, f, indent=2, default=str)
            
            self.console.print(f"[green]State saved to {state_file}[/green]")
            
        except Exception as e:
            self.console.print(f"[red]Error saving state to {state_file}: {e}[/red]")
            raise
    
    def update_bookmark(
        self, 
        source_name: str, 
        stream_name: str, 
        bookmark_key: str, 
        bookmark_value: Any
    ) -> None:
        """
        Update a bookmark for a stream.
        
        Args:
            source_name: Name of the data source
            stream_name: Name of the stream
            bookmark_key: Bookmark key (e.g., 'replication_key_value')
            bookmark_value: Bookmark value
        """
        state = self.load_state(source_name)
        
        if stream_name not in state.bookmarks:
            state.bookmarks[stream_name] = StreamState()
        
        state.bookmarks[stream_name].bookmarks[bookmark_key] = bookmark_value
        
        self.save_state(source_name, state)
    
    def get_bookmark(
        self, 
        source_name: str, 
        stream_name: str, 
        bookmark_key: str, 
        default: Any = None
    ) -> Any:
        """
        Get a bookmark value for a stream.
        
        Args:
            source_name: Name of the data source
            stream_name: Name of the stream
            bookmark_key: Bookmark key
            default: Default value if bookmark doesn't exist
            
        Returns:
            Bookmark value or default
        """
        state = self.load_state(source_name)
        
        if stream_name not in state.bookmarks:
            return default
        
        return state.bookmarks[stream_name].bookmarks.get(bookmark_key, default)
    
    def set_currently_syncing(self, source_name: str, stream_name: Optional[str]) -> None:
        """
        Set the currently syncing stream.
        
        Args:
            source_name: Name of the data source
            stream_name: Name of the stream being synced (None to clear)
        """
        state = self.load_state(source_name)
        state.currently_syncing = stream_name
        self.save_state(source_name, state)
    
    def get_currently_syncing(self, source_name: str) -> Optional[str]:
        """
        Get the currently syncing stream.
        
        Args:
            source_name: Name of the data source
            
        Returns:
            Name of currently syncing stream or None
        """
        state = self.load_state(source_name)
        return state.currently_syncing
    
    def clear_state(self, source_name: str) -> None:
        """
        Clear all state for a source.
        
        Args:
            source_name: Name of the data source
        """
        state_file = self.get_state_file_path(source_name)
        
        if state_file.exists():
            state_file.unlink()
            self.console.print(f"[green]Cleared state for {source_name}[/green]")
    
    def list_sources_with_state(self) -> list[str]:
        """
        List all sources that have state files.
        
        Returns:
            List of source names with state
        """
        sources = []
        
        for state_file in self.state_dir.glob("*.state.json"):
            source_name = state_file.stem.replace(".state", "")
            sources.append(source_name)
        
        return sources
    
    def get_state_summary(self, source_name: str) -> Dict[str, Any]:
        """
        Get a summary of state for a source.
        
        Args:
            source_name: Name of the data source
            
        Returns:
            State summary dictionary
        """
        state = self.load_state(source_name)
        
        summary = {
            "source": source_name,
            "currently_syncing": state.currently_syncing,
            "streams": {}
        }
        
        for stream_name, stream_state in state.bookmarks.items():
            stream_summary = {
                "bookmarks": dict(stream_state.bookmarks),
                "version": stream_state.version,
                "currently_syncing": stream_state.currently_syncing
            }
            summary["streams"][stream_name] = stream_summary
        
        return summary
    
    def backup_state(self, source_name: str) -> Path:
        """
        Create a backup of the state file.
        
        Args:
            source_name: Name of the data source
            
        Returns:
            Path to backup file
        """
        state_file = self.get_state_file_path(source_name)
        
        if not state_file.exists():
            raise FileNotFoundError(f"No state file found for {source_name}")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.state_dir / f"{source_name}.state.{timestamp}.backup.json"
        
        # Copy state file to backup
        import shutil
        shutil.copy2(state_file, backup_file)
        
        self.console.print(f"[green]State backed up to {backup_file}[/green]")
        return backup_file
    
    def restore_state(self, source_name: str, backup_file: Path) -> None:
        """
        Restore state from a backup file.
        
        Args:
            source_name: Name of the data source
            backup_file: Path to backup file
        """
        if not backup_file.exists():
            raise FileNotFoundError(f"Backup file not found: {backup_file}")
        
        state_file = self.get_state_file_path(source_name)
        
        # Copy backup to state file
        import shutil
        shutil.copy2(backup_file, state_file)
        
        self.console.print(f"[green]State restored from {backup_file}[/green]")
