# Singer Pydantic Framework - Snowflake Demo Guide

## Overview
A modern, type-safe data integration framework that replaces traditional ETL tools like Informatica using the open-source Singer ecosystem with Pydantic validation and dbt integration. This guide demonstrates the complete workflow using Snowflake as the data source.

---

## Quick Start (TL;DR)

```powershell
# 1. Setup demo (generates data, discovers schema, creates dbt models)
.\demo_setup.ps1

# 2. Run dbt transformations
cd dbthero\dbthero
dbt run --models staging.bootcamp_snowflake.*

# 3. Clean up after demo
cd ..\..
.\demo_cleanup.ps1
```

---

## Prerequisites

- Python 3.10+
- Snowflake account with ACCOUNTADMIN role
- PowerShell (Windows) or Bash (Linux/Mac)

---

## Step 1: Environment Setup

### 1.1 Navigate to Project
```powershell
cd F:\presention_100\a2_cmeltano
```

### 1.2 Activate Virtual Environment
```powershell
.\venv\Scripts\Activate.ps1
```

### 1.3 Verify Installation
```powershell
singer-framework version
# Expected: Singer Pydantic Framework v0.1.0
```

---

## Step 2: Configure Snowflake Connection

### 2.1 Review Configuration
Open `snowflake_auto.yml`:
```yaml
account: your_account
user: your_user
password: your_password
role: ACCOUNTADMIN
warehouse: COMPUTE_WH
database: SINGERDB
schema: MARTS
type: snowflake
```

### 2.2 Update Credentials
Edit `snowflake_auto.yml` with your Snowflake credentials.

⚠️ **Security Note**: Never commit credentials to Git. Use environment variables or secret managers in production.

---

## Step 3: Run Complete Demo Setup

### 3.1 Execute Setup Script
```powershell
.\demo_setup.ps1
```

### 3.2 What It Does
The setup script automates 7 steps:

1. **Activates Virtual Environment** - Ensures correct Python environment
2. **Installs Dependencies** - Installs Snowflake connector, tap, faker, numpy, dbt
3. **Generates Test Data** - Creates 50 customers, 30 products, 100 orders in Snowflake
4. **Discovers Schema** - Uses tap-snowflake to discover table structures
5. **Generates dbt Sources** - Creates `bootcamp_snowflake_sources.yml`
6. **Generates dbt Models** - Creates 3 staging models
7. **Validates Setup** - Runs `dbt debug` to confirm configuration

### 3.3 Expected Output
```
╔════════════════════════════════════════════════════════════╗
║        Singer Framework - Complete Demo Setup             ║
╚════════════════════════════════════════════════════════════╝

[1/7] 🔌 Activating Virtual Environment...
   ✓ Virtual environment activated

[2/7] 📦 Installing Dependencies...
   ✓ Framework installed
   ✓ Snowflake connector installed
   ✓ tap-snowflake installed
   ✓ faker installed
   ✓ numpy installed
   ✓ dbt installed

[3/7] 🏗️  Generating Test Data in Snowflake...
   ✓ Generated 50 customers, 30 products, 100 orders

[4/7] 🔍 Discovering Snowflake Schema...
   ✓ Discovered 3 streams

[5/7] 📝 Generating dbt Sources...
   ✓ dbt sources and models generated

[6/7] ✅ Verifying Generated Files...
   ✓ dbt sources file created
   ✓ 3 staging models created

[7/7] 🧪 Testing dbt Setup...
   ✓ dbt is configured correctly

╔════════════════════════════════════════════════════════════╗
║              ✅ DEMO SETUP COMPLETE!                       ║
╚════════════════════════════════════════════════════════════╝
```

### 3.4 Skip Flags (Advanced)
Speed up repeated runs by skipping already-completed steps:

```powershell
# Skip package installation
.\demo_setup.ps1 -SkipInstall

# Skip discovery (reuse catalog.json)
.\demo_setup.ps1 -SkipInstall -SkipDiscovery

# Skip dbt generation (reuse existing sources/models)
.\demo_setup.ps1 -SkipInstall -SkipDiscovery -SkipDbtGen
```

---

## Step 4: Explore Generated Files

### 4.1 View Discovered Catalog
```powershell
cat catalog.json
```

**Contents**: Singer catalog with 3 streams (CUSTOMERS, PRODUCTS, ORDERS), including schema metadata and data types.

### 4.2 View dbt Sources
```powershell
cat dbthero\dbthero\models\sources\bootcamp_snowflake_sources.yml
```

**Contents**: dbt source definition with:
- Source name: `bootcamp_snowflake`
- 3 tables with column definitions
- Data type mappings
- Timestamps and metadata

### 4.3 View Generated Staging Models
```powershell
ls dbthero\dbthero\models\staging\bootcamp_snowflake\
```

**Files**:
- `stg_bootcamp_snowflake_SINGERDB-MARTS-CUSTOMERS.sql`
- `stg_bootcamp_snowflake_SINGERDB-MARTS-PRODUCTS.sql`
- `stg_bootcamp_snowflake_SINGERDB-MARTS-ORDERS.sql`

### 4.4 Inspect a Staging Model
```powershell
cat dbthero\dbthero\models\staging\bootcamp_snowflake\stg_bootcamp_snowflake_SINGERDB-MARTS-CUSTOMERS.sql
```

**Content**:
```sql
{{ config(
    materialized='incremental',
    unique_key='CUSTOMER_ID',
    on_schema_change='sync_all_columns'
) }}

with source as (
    select * from {{ source('bootcamp_snowflake', 'SINGERDB-MARTS-CUSTOMERS') }}
),

renamed as (
    select
        CUSTOMER_ID,
        FIRST_NAME,
        LAST_NAME,
        EMAIL,
        PHONE,
        CITY,
        STATE,
        CREATED_AT,
        current_timestamp() as _loaded_at
    from source
)

select * from renamed

{% if is_incremental() %}
    where _loaded_at > (select max(_loaded_at) from {{ this }})
{% endif %}
```

---

## Step 5: Run dbt Transformations

### 5.1 Navigate to dbt Project
```powershell
cd dbthero\dbthero
```

### 5.2 Run Staging Models
```powershell
dbt run --models staging.bootcamp_snowflake.*
```

**Output**:
```
Running with dbt=1.7.0
Found 3 models, 0 tests, 0 snapshots

Completed successfully

Done. PASS=3 WARN=0 ERROR=0 SKIP=0 TOTAL=3
```

### 5.3 Test dbt Sources
```powershell
dbt test --models source:bootcamp_snowflake
```

### 5.4 View Model Lineage
```powershell
dbt docs generate
dbt docs serve
```

---

## Step 6: Verify Data in Snowflake

### 6.1 Query Raw Data
```sql
USE DATABASE SINGERDB;
USE SCHEMA MARTS;

SELECT * FROM CUSTOMERS LIMIT 10;
SELECT * FROM PRODUCTS LIMIT 10;
SELECT * FROM ORDERS LIMIT 10;
```

### 6.2 Query dbt Models
```sql
-- After running dbt transformations
SELECT * FROM DBT_SCHEMA.STG_BOOTCAMP_SNOWFLAKE_SINGERDB_MARTS_CUSTOMERS LIMIT 10;
```

---

## Step 7: Clean Up Demo Environment

### 7.1 Run Cleanup Script
```powershell
cd ..\..
.\demo_cleanup.ps1
```

### 7.2 What It Does
The cleanup script:

1. **Drops Snowflake Tables** - Removes CUSTOMERS, PRODUCTS, ORDERS
2. **Deletes Generated Files** - Removes catalog.json, sources, models
3. **Cleans dbt Artifacts** - Removes target/, logs/, dbt_packages/
4. **Resets Environment** - Ready for next demo run

### 7.3 Expected Output
```
╔════════════════════════════════════════════════════════════╗
║         Singer Framework - Complete Demo Cleanup          ║
╚════════════════════════════════════════════════════════════╝

[1/5] 🔌 Activating Virtual Environment...
   ✓ Virtual environment activated

[2/5] 🗑️  Dropping Snowflake Tables...
   ✓ Snowflake tables dropped

[3/5] 🧹 Deleting Generated Files...
   ✓ Deleted catalog.json
   ✓ Deleted dbt sources file
   ✓ Deleted dbt staging models

[4/5] 🧼 Cleaning dbt Artifacts...
   ✓ Deleted target/
   ✓ Deleted logs/

[5/5] ✅ Verifying Cleanup...
   ✓ Catalog removed
   ✓ dbt sources removed
   ✓ dbt models removed

╔════════════════════════════════════════════════════════════╗
║              ✅ CLEANUP COMPLETE!                          ║
╚════════════════════════════════════════════════════════════╝
```

---

## Advanced Usage

### Custom Data Generation

```powershell
# Generate custom data amounts
python generate_snowflake_data.py --config snowflake_auto.yml --customers 100 --products 50 --orders 200

# Cleanup specific tables
python cleanup_snowflake.py --config snowflake_auto.yml
```

### Manual Discovery
```powershell
# Discover schema manually
tap-snowflake --config tap_snowflake_config.json --discover > catalog.json
```

### Manual dbt Generation
```powershell
# Generate dbt sources without setup script
singer-framework generate-sources catalog.json snowflake_auto.yml --dbt-project ./dbthero/dbthero --generate-models
```

---

## Troubleshooting

### Issue: Snowflake Connection Fails
**Solution:**
1. Verify credentials in `snowflake_auto.yml`
2. Check ACCOUNTADMIN role access
3. Ensure warehouse is running
4. Test connection:
   ```powershell
   python -c "import snowflake.connector; print('OK')"
   ```

### Issue: numpy Incompatibility
**Solution:**
```powershell
pip install "numpy<2"
```

### Issue: Emoji Encoding Errors
**Cause**: Windows PowerShell console encoding

**Solution**: The script automatically sets UTF-8 encoding. If issues persist:
```powershell
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$env:PYTHONIOENCODING = "utf-8"
```

### Issue: dbt Sources Not Generated
**Solution:**
1. Check catalog.json exists and is valid JSON
2. Verify snowflake_auto.yml has correct format
3. Run manually:
   ```powershell
   singer-framework generate-sources catalog.json snowflake_auto.yml --dbt-project ./dbthero/dbthero --generate-models
   ```

### Issue: Permission Denied on MARTS Schema
**Solution**: Use ACCOUNTADMIN role or grant permissions:
```sql
GRANT USAGE ON SCHEMA SINGERDB.MARTS TO ROLE YOUR_ROLE;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA SINGERDB.MARTS TO ROLE YOUR_ROLE;
```

---

## CLI Command Reference

### Framework Commands
```powershell
# Version
singer-framework version

# Initialize config (interactive)
singer-framework init --source-type snowflake

# Discover schema
singer-framework discover --config snowflake_auto.yml

# Generate dbt sources
singer-framework generate-sources catalog.json snowflake_auto.yml --dbt-project ./dbthero/dbthero

# Generate dbt sources + models
singer-framework generate-sources catalog.json snowflake_auto.yml --dbt-project ./dbthero/dbthero --generate-models

# List available source types
singer-framework list-sources
```

### Demo Scripts
```powershell
# Complete setup
.\demo_setup.ps1

# Setup with skip flags
.\demo_setup.ps1 -SkipInstall
.\demo_setup.ps1 -SkipInstall -SkipDiscovery
.\demo_setup.ps1 -SkipInstall -SkipDiscovery -SkipDbtGen

# Cleanup
.\demo_cleanup.ps1
```

### Data Generation Scripts
```powershell
# Generate test data
python generate_snowflake_data.py --config snowflake_auto.yml

# Custom amounts
python generate_snowflake_data.py --config snowflake_auto.yml --customers 100 --products 50 --orders 200

# Cleanup Snowflake
python cleanup_snowflake.py --config snowflake_auto.yml
```

### dbt Commands
```powershell
cd dbthero\dbthero

# Run all models
dbt run

# Run specific models
dbt run --models staging.bootcamp_snowflake.*

# Test sources
dbt test --models source:bootcamp_snowflake

# Debug connection
dbt debug

# Generate docs
dbt docs generate
dbt docs serve
```

---

## File Structure

```
a2_cmeltano/
├── demo_setup.ps1                    # Main setup script
├── demo_cleanup.ps1                  # Cleanup script
├── snowflake_auto.yml                # Snowflake configuration
├── tap_snowflake_config.json         # Tap-specific config (auto-generated)
├── catalog.json                      # Discovered schema (auto-generated)
├── generate_snowflake_data.py        # Data generator
├── cleanup_snowflake.py              # Snowflake cleanup utility
├── singer_framework/                 # Framework source code
│   ├── __init__.py
│   ├── cli.py                        # CLI commands
│   ├── config.py                     # Configuration models
│   ├── discovery.py                  # Schema discovery
│   └── interactive.py                # Interactive setup
├── dbthero/                          # dbt project
│   └── dbthero/
│       ├── models/
│       │   ├── sources/              # Generated dbt sources
│       │   │   └── bootcamp_snowflake_sources.yml
│       │   └── staging/              # Generated staging models
│       │       └── bootcamp_snowflake/
│       │           ├── stg_bootcamp_snowflake_SINGERDB-MARTS-CUSTOMERS.sql
│       │           ├── stg_bootcamp_snowflake_SINGERDB-MARTS-PRODUCTS.sql
│       │           └── stg_bootcamp_snowflake_SINGERDB-MARTS-ORDERS.sql
│       └── dbt_project.yml
└── pyproject.toml                    # Package definition
```

---

## Production Deployment

### 1. Environment Variables
```powershell
# Set credentials as environment variables
$env:SNOWFLAKE_ACCOUNT = "your_account"
$env:SNOWFLAKE_USER = "your_user"
$env:SNOWFLAKE_PASSWORD = "your_password"
```

### 2. CI/CD Pipeline
```yaml
# .github/workflows/deploy.yml
name: Deploy Singer Framework
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: |
          pip install -e .
          pip install snowflake-connector-python pipelinewise-tap-snowflake
      - name: Run discovery
        run: singer-framework discover --config config.yml
      - name: Generate dbt
        run: singer-framework generate-sources catalog.json config.yml --dbt-project ./dbthero/dbthero --generate-models
```

### 3. Airflow DAG
```python
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

dag = DAG(
    'singer_snowflake_etl',
    start_date=datetime(2024, 1, 1),
    schedule_interval='0 2 * * *',  # Daily at 2 AM
    catchup=False
)

discover = BashOperator(
    task_id='discover_snowflake',
    bash_command='singer-framework discover --config /configs/snowflake.yml',
    dag=dag
)

generate_dbt = BashOperator(
    task_id='generate_dbt',
    bash_command='singer-framework generate-sources catalog.json /configs/snowflake.yml --dbt-project /dbt --generate-models',
    dag=dag
)

run_dbt = BashOperator(
    task_id='run_dbt',
    bash_command='cd /dbt && dbt run',
    dag=dag
)

discover >> generate_dbt >> run_dbt
```

---

## Success Criteria

✅ Environment setup complete  
✅ Snowflake connection successful  
✅ Test data generated (50 customers, 30 products, 100 orders)  
✅ Schema discovered (3 streams)  
✅ dbt sources generated  
✅ dbt staging models created (3 models)  
✅ dbt transformations run successfully  
✅ Cleanup script works  
✅ Ready for live demo

---

## Support & Resources

- **Presentation**: `singer_framework_presentation.marp.md` (30 slides)
- **Configuration**: `snowflake_auto.yml`
- **Framework Code**: `singer_framework/` directory
- **dbt Project**: `dbthero/dbthero/`

---

## Next Steps

1. **Customize for Your Data Source**: Adapt configs for PostgreSQL, MySQL, APIs
2. **Add More Transformations**: Create intermediate and mart models in dbt
3. **Implement CI/CD**: Automate deployment with GitHub Actions
4. **Add Monitoring**: Integrate with Prometheus/Grafana
5. **Scale to Production**: Handle multiple sources and larger data volumes
