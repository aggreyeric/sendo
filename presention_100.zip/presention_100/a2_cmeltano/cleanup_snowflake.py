"""
Cleanup Snowflake tables for fresh demo runs.
"""

import snowflake.connector
import yaml
import argparse
import sys
import io

# Fix encoding for Windows PowerShell
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def get_snowflake_connection(config):
    """Create Snowflake connection."""
    return snowflake.connector.connect(
        account=config['account'],
        user=config['user'],
        password=config['password'],
        role=config['role'],
        warehouse=config['warehouse'],
        database=config['database'],
        schema=config['schema']
    )

def cleanup_all(conn):
    """Drop all demo tables."""
    cursor = conn.cursor()
    
    print("🧹 Cleaning up Snowflake demo data...")
    print("=" * 60)
    
    tables = ['orders', 'products', 'customers']
    
    for table in tables:
        try:
            cursor.execute(f"DROP TABLE IF EXISTS {table}")
            print(f"   ✓ Dropped {table}")
        except Exception as e:
            print(f"   ⚠ Could not drop {table}: {e}")
    
    cursor.close()
    print("=" * 60)
    print("✅ Cleanup complete - ready for fresh demo!\n")

def main():
    parser = argparse.ArgumentParser(description='Cleanup Snowflake demo data')
    parser.add_argument('--config', default='snowflake_auto.yml', help='Snowflake config file')
    
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    print(f"\n🎯 Target: {config['database']}.{config['schema']}\n")
    
    try:
        conn = get_snowflake_connection(config)
        cleanup_all(conn)
        conn.commit()
        conn.close()
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
