# ============================================================================
# SINGER FRAMEWORK - COMPLETE DEMO CLEANUP
# Run this after your presentation to reset everything
# ============================================================================

$ErrorActionPreference = "Stop"

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Red
Write-Host "║         Singer Framework - Complete Demo Cleanup          ║" -ForegroundColor Red
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Red

$ProjectRoot = "F:\presention_100\a2_cmeltano"
$Config = "snowflake_auto.yml"
$DbtProject = "$ProjectRoot\dbthero\dbthero"

Set-Location $ProjectRoot

Write-Host "`n⚠️  WARNING: This will delete all demo data and generated files!" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to cancel, or" -NoNewline
Write-Host " any other key to continue..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
Write-Host ""

# ============================================================================
# Step 1: Activate Virtual Environment
# ============================================================================
Write-Host "`n[1/5] 🔌 Activating Virtual Environment..." -ForegroundColor Yellow

if (Test-Path "venv\Scripts\Activate.ps1") {
    & "venv\Scripts\Activate.ps1"
    Write-Host "   ✓ Virtual environment activated" -ForegroundColor Green
} else {
    Write-Host "   ⚠ Virtual environment not found, skipping..." -ForegroundColor Yellow
}

# ============================================================================
# Step 2: Drop Snowflake Tables
# ============================================================================
Write-Host "`n[2/5] 🗑️  Dropping Snowflake Tables..." -ForegroundColor Yellow

if (Test-Path "cleanup_snowflake.py") {
    Write-Host "   → Dropping CUSTOMERS, PRODUCTS, ORDERS..." -ForegroundColor Cyan
    python cleanup_snowflake.py --config $Config 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   ✓ Snowflake tables dropped" -ForegroundColor Green
    } else {
        Write-Host "   ⚠ Snowflake cleanup had warnings" -ForegroundColor Yellow
    }
} else {
    Write-Host "   ⚠ cleanup_snowflake.py not found, skipping..." -ForegroundColor Yellow
}

# ============================================================================
# Step 3: Delete Generated Files
# ============================================================================
Write-Host "`n[3/5] 🧹 Deleting Generated Files..." -ForegroundColor Yellow

# Delete catalog
if (Test-Path "catalog.json") {
    Remove-Item "catalog.json" -Force
    Write-Host "   ✓ Deleted catalog.json" -ForegroundColor Green
}

# Delete dbt sources
$sourcesFile = "$DbtProject\models\sources\bootcamp_snowflake_sources.yml"
if (Test-Path $sourcesFile) {
    Remove-Item $sourcesFile -Force
    Write-Host "   ✓ Deleted dbt sources file" -ForegroundColor Green
}

# Delete dbt staging models
$stagingDir = "$DbtProject\models\staging\bootcamp_snowflake"
if (Test-Path $stagingDir) {
    Remove-Item $stagingDir -Recurse -Force
    Write-Host "   ✓ Deleted dbt staging models" -ForegroundColor Green
}

# Delete state files
if (Test-Path ".state") {
    Remove-Item ".state\*.json" -Force -ErrorAction SilentlyContinue
    Write-Host "   ✓ Deleted state files" -ForegroundColor Green
}

# Delete temporary files
$tempFiles = @("tap_config.json", "test_sales.db")
foreach ($file in $tempFiles) {
    if (Test-Path $file) {
        Remove-Item $file -Force
        Write-Host "   ✓ Deleted $file" -ForegroundColor Green
    }
}

# ============================================================================
# Step 4: Clean dbt Artifacts
# ============================================================================
Write-Host "`n[4/5] 🧼 Cleaning dbt Artifacts..." -ForegroundColor Yellow

Set-Location $DbtProject

$dbtArtifacts = @("target", "logs", "dbt_packages")
foreach ($artifact in $dbtArtifacts) {
    if (Test-Path $artifact) {
        Remove-Item $artifact -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "   ✓ Deleted $artifact/" -ForegroundColor Green
    }
}

Set-Location $ProjectRoot

# ============================================================================
# Step 5: Verify Cleanup
# ============================================================================
Write-Host "`n[5/5] ✅ Verifying Cleanup..." -ForegroundColor Yellow

$cleanupItems = @(
    @{Path="catalog.json"; Name="Catalog"},
    @{Path="$DbtProject\models\sources\bootcamp_snowflake_sources.yml"; Name="dbt sources"},
    @{Path="$DbtProject\models\staging\bootcamp_snowflake"; Name="dbt models"},
    @{Path=".state"; Name="State files"},
    @{Path="test_sales.db"; Name="Test database"}
)

$allClean = $true
foreach ($item in $cleanupItems) {
    if (Test-Path $item.Path) {
        Write-Host "   ⚠ $($item.Name) still exists" -ForegroundColor Yellow
        $allClean = $false
    } else {
        Write-Host "   ✓ $($item.Name) removed" -ForegroundColor Green
    }
}

# ============================================================================
# SUMMARY
# ============================================================================
Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║              ✅ CLEANUP COMPLETE!                          ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`n📊 What Was Cleaned:" -ForegroundColor Cyan
Write-Host "   ✓ Snowflake tables dropped (CUSTOMERS, PRODUCTS, ORDERS)" -ForegroundColor White
Write-Host "   ✓ Generated files deleted (catalog, sources, models)" -ForegroundColor White
Write-Host "   ✓ dbt artifacts cleaned (target, logs)" -ForegroundColor White
Write-Host "   ✓ State files removed" -ForegroundColor White

if ($allClean) {
    Write-Host "`n✨ Environment is clean and ready for next demo!" -ForegroundColor Green
} else {
    Write-Host "`n⚠️  Some files still exist. Review warnings above." -ForegroundColor Yellow
}

Write-Host "`n🔄 To setup for next demo:" -ForegroundColor Yellow
Write-Host "   .\demo_setup.ps1" -ForegroundColor White

Write-Host ""
