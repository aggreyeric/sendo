"""
Generate test data in Snowflake for Singer Framework demo.
Creates customers, products, and orders tables with sample data.
"""

import snowflake.connector
from faker import Faker
import random
from datetime import datetime, timedelta
import argparse
import sys
import io

# Fix encoding for Windows PowerShell
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

fake = Faker()

def get_snowflake_connection(config):
    """Create Snowflake connection."""
    return snowflake.connector.connect(
        account=config['account'],
        user=config['user'],
        password=config['password'],
        role=config['role'],
        warehouse=config['warehouse'],
        database=config['database'],
        schema=config['schema']
    )

def cleanup_tables(conn):
    """Drop existing tables."""
    cursor = conn.cursor()
    
    print("🧹 Cleaning up existing tables...")
    tables = ['orders', 'products', 'customers']
    
    for table in tables:
        try:
            cursor.execute(f"DROP TABLE IF EXISTS {table}")
            print(f"   ✓ Dropped {table}")
        except Exception as e:
            print(f"   ⚠ Could not drop {table}: {e}")
    
    cursor.close()
    print("✅ Cleanup complete\n")

def create_tables(conn):
    """Create tables in Snowflake."""
    cursor = conn.cursor()
    
    print("📋 Creating tables...")
    
    # Customers table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id INTEGER PRIMARY KEY,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            email VARCHAR(200),
            phone VARCHAR(50),
            city VARCHAR(100),
            state VARCHAR(50),
            country VARCHAR(100),
            created_at TIMESTAMP_NTZ,
            updated_at TIMESTAMP_NTZ
        )
    """)
    print("   ✓ Created customers table")
    
    # Products table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id INTEGER PRIMARY KEY,
            product_name VARCHAR(200),
            category VARCHAR(100),
            price DECIMAL(10, 2),
            stock_quantity INTEGER,
            created_at TIMESTAMP_NTZ,
            updated_at TIMESTAMP_NTZ
        )
    """)
    print("   ✓ Created products table")
    
    # Orders table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER PRIMARY KEY,
            customer_id INTEGER,
            order_date TIMESTAMP_NTZ,
            status VARCHAR(50),
            total_amount DECIMAL(10, 2),
            created_at TIMESTAMP_NTZ,
            updated_at TIMESTAMP_NTZ
        )
    """)
    print("   ✓ Created orders table")
    
    cursor.close()
    print("✅ Tables created\n")

def insert_customers(conn, count=50):
    """Insert customer records."""
    cursor = conn.cursor()
    
    print(f"👥 Inserting {count} customers...")
    
    customers = []
    for i in range(1, count + 1):
        now = datetime.now()
        customers.append((
            i,
            fake.first_name(),
            fake.last_name(),
            fake.email(),
            fake.phone_number(),
            fake.city(),
            fake.state(),
            fake.country(),
            now,
            now
        ))
    
    cursor.executemany("""
        INSERT INTO customers 
        (customer_id, first_name, last_name, email, phone, city, state, country, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, customers)
    
    cursor.close()
    print(f"   ✓ Inserted {count} customers")

def insert_products(conn, count=30):
    """Insert product records."""
    cursor = conn.cursor()
    
    print(f"📦 Inserting {count} products...")
    
    categories = ['Electronics', 'Clothing', 'Food', 'Books', 'Toys', 'Sports']
    products = []
    
    for i in range(1, count + 1):
        now = datetime.now()
        products.append((
            i,
            fake.catch_phrase(),
            random.choice(categories),
            round(random.uniform(10, 500), 2),
            random.randint(0, 1000),
            now,
            now
        ))
    
    cursor.executemany("""
        INSERT INTO products 
        (product_id, product_name, category, price, stock_quantity, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, products)
    
    cursor.close()
    print(f"   ✓ Inserted {count} products")

def insert_orders(conn, count=100, num_customers=50):
    """Insert order records."""
    cursor = conn.cursor()
    
    print(f"🛒 Inserting {count} orders...")
    
    statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']
    orders = []
    
    for i in range(1, count + 1):
        order_date = datetime.now() - timedelta(days=random.randint(0, 365))
        now = datetime.now()
        orders.append((
            i,
            random.randint(1, num_customers),
            order_date,
            random.choice(statuses),
            round(random.uniform(20, 1000), 2),
            now,
            now
        ))
    
    cursor.executemany("""
        INSERT INTO orders 
        (order_id, customer_id, order_date, status, total_amount, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, orders)
    
    cursor.close()
    print(f"   ✓ Inserted {count} orders")

def main():
    parser = argparse.ArgumentParser(description='Generate test data in Snowflake')
    parser.add_argument('--config', default='snowflake_auto.yml', help='Snowflake config file')
    parser.add_argument('--customers', type=int, default=50, help='Number of customers')
    parser.add_argument('--products', type=int, default=30, help='Number of products')
    parser.add_argument('--orders', type=int, default=100, help='Number of orders')
    parser.add_argument('--no-cleanup', action='store_true', help='Skip cleanup step')
    
    args = parser.parse_args()
    
    # Load config
    import yaml
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    print("🏗️  Generating Snowflake test data")
    print("=" * 60)
    print(f"Database: {config['database']}")
    print(f"Schema: {config['schema']}")
    print("=" * 60)
    
    try:
        # Connect to Snowflake
        print("\n🔌 Connecting to Snowflake...")
        conn = get_snowflake_connection(config)
        print("   ✓ Connected\n")
        
        # Cleanup if requested
        if not args.no_cleanup:
            cleanup_tables(conn)
        
        # Create tables
        create_tables(conn)
        
        # Insert data
        insert_customers(conn, args.customers)
        insert_products(conn, args.products)
        insert_orders(conn, args.orders, args.customers)
        
        # Commit
        conn.commit()
        
        print("\n✅ Data generation complete!")
        print("=" * 60)
        print("📊 Summary:")
        print(f"   👥 Customers: {args.customers}")
        print(f"   📦 Products:  {args.products}")
        print(f"   🛒 Orders:    {args.orders}")
        print("=" * 60)
        
        # Sample data
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers LIMIT 1")
        sample = cursor.fetchone()
        if sample:
            print(f"\n📋 Sample Customer:")
            print(f"   ID: {sample[0]}, Name: {sample[1]} {sample[2]}, Email: {sample[3]}")
        
        cursor.close()
        conn.close()
        
        print("\n✨ Snowflake database ready!")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
