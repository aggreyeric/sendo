"""Test GitHub token validity"""
import os
import requests
from dotenv import load_dotenv

load_dotenv()

token = os.getenv("GITHUB_TOKEN")

print("=" * 60)
print("GITHUB TOKEN TEST")
print("=" * 60)
print(f"Token exists: {token is not None}")
print(f"Token length: {len(token) if token else 0}")
print(f"Token starts with: {token[:20] if token else 'N/A'}...")
print(f"Token ends with: ...{token[-10:] if token else 'N/A'}")
print()

if token:
    # Test the token with GitHub API
    print("Testing token with GitHub API...")
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # Try to get rate limit info (doesn't require scopes)
    response = requests.get("https://api.github.com/rate_limit", headers=headers)
    
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print("✅ Token is VALID")
        print(f"Rate limit: {data['rate']['remaining']}/{data['rate']['limit']}")
        print(f"Reset time: {data['rate']['reset']}")
    elif response.status_code == 401:
        print("❌ Token is INVALID or EXPIRED")
        print(f"Response: {response.json()}")
    else:
        print(f"⚠️ Unexpected response: {response.status_code}")
        print(f"Response: {response.text}")
else:
    print("❌ No token found in .env file")

print("=" * 60)
