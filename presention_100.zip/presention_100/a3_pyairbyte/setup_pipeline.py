"""Setup script for data pipeline - supports both PyAirbyte and standard Python approaches"""

import argparse
import sys
from pathlib import Path
from loguru import logger


def setup_pyairbyte():
    """Setup pipeline using PyAirbyte extractors"""
    logger.info("Setting up pipeline with PyAirbyte approach")
    
    try:
        # Import PyAirbyte extractors
        from pyairbyte_extractors.github_pyairbyte_extractor import GitHubPyAirbyteExtractor
        from pyairbyte_extractors.pypi_pyairbyte_extractor import PyPIPyAirbyteExtractor
        
        # Run GitHub extraction
        logger.info("Running GitHub PyAirbyte extraction...")
        github_extractor = GitHubPyAirbyteExtractor()
        github_extractor.run()
        
        # Run PyPI extraction
        logger.info("Running PyPI PyAirbyte extraction...")
        pypi_extractor = PyPIPyAirbyteExtractor()
        pypi_extractor.run()
        
        logger.info("✅ PyAirbyte pipeline setup completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ PyAirbyte pipeline setup failed: {e}")
        return False


def setup_standard():
    """Setup pipeline using standard Python extractors"""
    logger.info("Setting up pipeline with standard Python approach")
    
    try:
        # Import standard extractors
        from extractors.github_duckdb_extractor import GitHubDuckDBExtractor
        from extractors.pypi_duckdb_extractor import PyPIDuckDBExtractor
        
        # Run GitHub extraction
        logger.info("Running GitHub standard extraction...")
        github_extractor = GitHubDuckDBExtractor()
        github_extractor.run()
        
        # Run PyPI extraction
        logger.info("Running PyPI standard extraction...")
        pypi_extractor = PyPIDuckDBExtractor()
        pypi_extractor.run()
        
        logger.info("✅ Standard Python pipeline setup completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ Standard Python pipeline setup failed: {e}")
        return False


def run_dbt():
    """Run dbt models"""
    import subprocess
    
    logger.info("Running dbt models...")
    
    try:
        # Change to dbt project directory
        dbt_dir = Path(__file__).parent / "dbt_project"
        
        # Run dbt debug
        logger.info("Running dbt debug...")
        result = subprocess.run(
            [sys.executable, "-m", "dbt.cli.main", "debug", "--profiles-dir", "."],
            cwd=dbt_dir,
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            logger.warning(f"dbt debug output: {result.stdout}")
            logger.warning(f"dbt debug errors: {result.stderr}")
        
        # Run dbt deps
        logger.info("Running dbt deps...")
        subprocess.run(
            [sys.executable, "-m", "dbt.cli.main", "deps", "--profiles-dir", "."],
            cwd=dbt_dir,
            check=True
        )
        
        # Run dbt run
        logger.info("Running dbt run...")
        result = subprocess.run(
            [sys.executable, "-m", "dbt.cli.main", "run", "--profiles-dir", "."],
            cwd=dbt_dir,
            capture_output=True,
            text=True
        )
        
        logger.info(result.stdout)
        
        if result.returncode == 0:
            logger.info("✅ dbt models executed successfully")
            return True
        else:
            logger.error(f"❌ dbt run failed: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"❌ dbt execution failed: {e}")
        return False


def main():
    """Main setup function"""
    parser = argparse.ArgumentParser(
        description="Setup data pipeline with choice of extraction approach"
    )
    parser.add_argument(
        "--approach",
        choices=["pyairbyte", "standard", "both"],
        default="both",
        help="Choose extraction approach: pyairbyte, standard, or both (default: both)"
    )
    parser.add_argument(
        "--skip-dbt",
        action="store_true",
        help="Skip dbt execution"
    )
    
    args = parser.parse_args()
    
    logger.info("=" * 60)
    logger.info("DATA PIPELINE SETUP")
    logger.info("=" * 60)
    
    success = True
    
    # Run extraction based on approach
    if args.approach in ["pyairbyte", "both"]:
        logger.info("\n--- PyAirbyte Approach ---")
        if not setup_pyairbyte():
            success = False
    
    if args.approach in ["standard", "both"]:
        logger.info("\n--- Standard Python Approach ---")
        if not setup_standard():
            success = False
    
    # Run dbt if not skipped
    if not args.skip_dbt and success:
        logger.info("\n--- dbt Transformation ---")
        if not run_dbt():
            success = False
    
    # Summary
    logger.info("\n" + "=" * 60)
    if success:
        logger.info("✅ PIPELINE SETUP COMPLETED SUCCESSFULLY")
    else:
        logger.error("❌ PIPELINE SETUP FAILED")
    logger.info("=" * 60)
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
