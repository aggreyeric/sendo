{{
  config(
    materialized='view',
    schema='staging'
  )
}}

WITH raw_pypi AS (
    SELECT 
        extracted_at,
        package_name,
        raw_data
    FROM {{ source('raw_data', 'pypi_packages') }}
),

parsed_data AS (
    SELECT 
        extracted_at,
        package_name,
        json_extract_string(raw_data, '$.package_name') AS package_name_parsed,
        json_extract_string(raw_data, '$.version') AS version,
        json_extract_string(raw_data, '$.summary') AS summary,
        json_extract_string(raw_data, '$.description_content_type') AS description_content_type,
        json_extract_string(raw_data, '$.home_page') AS home_page,
        json_extract_string(raw_data, '$.author') AS author,
        json_extract_string(raw_data, '$.author_email') AS author_email,
        json_extract_string(raw_data, '$.maintainer') AS maintainer,
        json_extract_string(raw_data, '$.license') AS license,
        json_extract_string(raw_data, '$.keywords') AS keywords,
        json_extract(raw_data, '$.classifiers') AS classifiers,
        json_extract(raw_data, '$.requires_dist') AS requires_dist,
        json_extract_string(raw_data, '$.requires_python') AS requires_python,
        json_extract(raw_data, '$.project_urls') AS project_urls,
        CAST(json_extract_string(raw_data, '$.release_count') AS INTEGER) AS release_count,
        CAST(json_extract_string(raw_data, '$.latest_release_info.upload_time') AS TIMESTAMP) AS latest_release_upload_time,
        json_extract_string(raw_data, '$.latest_release_info.python_version') AS latest_python_version,
        CAST(json_extract_string(raw_data, '$.latest_release_info.size') AS INTEGER) AS latest_release_size,
        json_extract_string(raw_data, '$.latest_release_info.filename') AS latest_filename,
        CAST(json_extract_string(raw_data, '$.downloads_last_day') AS INTEGER) AS downloads_last_day,
        CAST(json_extract_string(raw_data, '$.downloads_last_week') AS INTEGER) AS downloads_last_week,
        CAST(json_extract_string(raw_data, '$.downloads_last_month') AS INTEGER) AS downloads_last_month
    FROM raw_pypi
)

SELECT 
    extracted_at,
    COALESCE(package_name_parsed, package_name) AS package_name,
    version,
    summary,
    description_content_type,
    home_page,
    author,
    author_email,
    maintainer,
    license,
    keywords,
    classifiers,
    requires_dist,
    requires_python,
    project_urls,
    COALESCE(release_count, 0) AS release_count,
    latest_release_upload_time,
    latest_python_version,
    COALESCE(latest_release_size, 0) AS latest_release_size,
    latest_filename,
    COALESCE(downloads_last_day, 0) AS downloads_last_day,
    COALESCE(downloads_last_week, 0) AS downloads_last_week,
    COALESCE(downloads_last_month, 0) AS downloads_last_month
FROM parsed_data
