"""Teardown script for data pipeline - clean up resources"""

import argparse
import sys
from pathlib import Path
import shutil
from loguru import logger
import duckdb


def clean_duckdb(db_path: str = "dbt_project/target/dbt_duckdb.db"):
    """Clean DuckDB database"""
    logger.info(f"Cleaning DuckDB database: {db_path}")
    
    try:
        full_path = Path(__file__).parent / db_path
        
        if full_path.exists():
            # Connect and drop tables
            conn = duckdb.connect(str(full_path))
            
            # Drop tables if they exist
            tables = ["raw_data.github_repos", "raw_data.pypi_packages"]
            for table in tables:
                try:
                    conn.execute(f"DROP TABLE IF EXISTS {table}")
                    logger.info(f"Dropped table: {table}")
                except Exception as e:
                    logger.warning(f"Could not drop table {table}: {e}")
            
            # Drop schema
            try:
                conn.execute("DROP SCHEMA IF EXISTS raw_data CASCADE")
                logger.info("Dropped schema: raw_data")
            except Exception as e:
                logger.warning(f"Could not drop schema: {e}")
            
            conn.close()
            logger.info("✅ DuckDB database cleaned")
        else:
            logger.warning(f"Database file not found: {full_path}")
            
    except Exception as e:
        logger.error(f"❌ Error cleaning DuckDB: {e}")
        return False
    
    return True


def remove_duckdb(db_path: str = "dbt_project/target/dbt_duckdb.db"):
    """Remove DuckDB database file"""
    logger.info(f"Removing DuckDB database file: {db_path}")
    
    try:
        full_path = Path(__file__).parent / db_path
        
        if full_path.exists():
            full_path.unlink()
            logger.info(f"✅ Removed database file: {full_path}")
        else:
            logger.warning(f"Database file not found: {full_path}")
            
    except Exception as e:
        logger.error(f"❌ Error removing database file: {e}")
        return False
    
    return True


def clean_dbt_artifacts():
    """Clean dbt generated artifacts"""
    logger.info("Cleaning dbt artifacts...")
    
    try:
        dbt_dir = Path(__file__).parent / "dbt_project"
        
        # Directories to clean
        dirs_to_clean = ["target", "logs", "dbt_packages"]
        
        for dir_name in dirs_to_clean:
            dir_path = dbt_dir / dir_name
            if dir_path.exists():
                shutil.rmtree(dir_path)
                logger.info(f"Removed directory: {dir_path}")
        
        logger.info("✅ dbt artifacts cleaned")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error cleaning dbt artifacts: {e}")
        return False


def clean_cache():
    """Clean Python cache files"""
    logger.info("Cleaning Python cache files...")
    
    try:
        project_dir = Path(__file__).parent
        
        # Remove __pycache__ directories
        for pycache in project_dir.rglob("__pycache__"):
            if pycache.is_dir():
                shutil.rmtree(pycache)
                logger.info(f"Removed: {pycache}")
        
        # Remove .pyc files
        for pyc_file in project_dir.rglob("*.pyc"):
            pyc_file.unlink()
            logger.info(f"Removed: {pyc_file}")
        
        logger.info("✅ Python cache cleaned")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error cleaning cache: {e}")
        return False


def main():
    """Main teardown function"""
    parser = argparse.ArgumentParser(
        description="Teardown data pipeline and clean up resources"
    )
    parser.add_argument(
        "--clean-db",
        action="store_true",
        help="Clean database tables but keep the database file"
    )
    parser.add_argument(
        "--remove-db",
        action="store_true",
        help="Remove the entire database file"
    )
    parser.add_argument(
        "--clean-dbt",
        action="store_true",
        help="Clean dbt artifacts (target, logs, dbt_packages)"
    )
    parser.add_argument(
        "--clean-cache",
        action="store_true",
        help="Clean Python cache files"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Clean everything (database, dbt artifacts, cache)"
    )
    
    args = parser.parse_args()
    
    # If no specific option is provided, show help
    if not any([args.clean_db, args.remove_db, args.clean_dbt, args.clean_cache, args.all]):
        parser.print_help()
        return 0
    
    logger.info("=" * 60)
    logger.info("DATA PIPELINE TEARDOWN")
    logger.info("=" * 60)
    
    success = True
    
    # Execute cleanup based on arguments
    if args.all or args.clean_db:
        logger.info("\n--- Cleaning Database ---")
        if not clean_duckdb():
            success = False
    
    if args.all or args.remove_db:
        logger.info("\n--- Removing Database File ---")
        if not remove_duckdb():
            success = False
    
    if args.all or args.clean_dbt:
        logger.info("\n--- Cleaning dbt Artifacts ---")
        if not clean_dbt_artifacts():
            success = False
    
    if args.all or args.clean_cache:
        logger.info("\n--- Cleaning Python Cache ---")
        if not clean_cache():
            success = False
    
    # Summary
    logger.info("\n" + "=" * 60)
    if success:
        logger.info("✅ PIPELINE TEARDOWN COMPLETED SUCCESSFULLY")
    else:
        logger.error("❌ PIPELINE TEARDOWN FAILED")
    logger.info("=" * 60)
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
