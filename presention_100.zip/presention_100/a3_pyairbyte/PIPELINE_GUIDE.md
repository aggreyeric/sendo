# Data Pipeline Guide: PyAirbyte vs Standard Python

This project demonstrates two approaches for building data extraction pipelines to DuckDB:

1. **PyAirbyte Approach**: Using the Airbyte Python SDK
2. **Standard Python Approach**: Using native Python with requests library

## 📁 Project Structure

```
a3_pyairbyte/
├── pyairbyte_extractors/          # PyAirbyte-based extractors
│   ├── github_pyairbyte_extractor.py
│   └── pypi_pyairbyte_extractor.py
├── extractors/                     # Standard Python extractors
│   ├── github_duckdb_extractor.py
│   ├── pypi_duckdb_extractor.py
│   ├── github_extractor.py        # Original Snowflake version
│   └── pypi_extractor.py          # Original Snowflake version
├── dbt_project/                    # dbt transformation layer
│   ├── models/
│   ├── profiles.yml               # DuckDB profile configuration
│   └── dbt_project.yml
├── setup_pipeline.py              # Setup script with approach selection
└── teardown_pipeline.py           # Cleanup script
```

## 🚀 Quick Start

### Prerequisites

```bash
# Ensure you have the virtual environment activated
# Install dependencies
pip install -r requirements.txt
```

### Environment Variables

Create a `.env` file with:

```env
GITHUB_TOKEN=your_github_token_here
```

## 📊 Approach Comparison

### PyAirbyte Approach

**Pros:**
- Built-in connector management
- Standardized data extraction
- Automatic schema detection
- Community-maintained connectors
- Built-in incremental sync support

**Cons:**
- Additional dependency overhead
- Limited customization
- Requires connector availability

**Files:**
- `pyairbyte_extractors/github_pyairbyte_extractor.py`
- `pyairbyte_extractors/pypi_pyairbyte_extractor.py`

### Standard Python Approach

**Pros:**
- Full control over extraction logic
- No additional framework dependencies
- Easy to customize and debug
- Direct API interaction
- Lightweight

**Cons:**
- Manual error handling
- Custom rate limiting implementation
- More code to maintain

**Files:**
- `extractors/github_duckdb_extractor.py`
- `extractors/pypi_duckdb_extractor.py`

## 🔧 Usage

### Setup Pipeline

Run the pipeline with different approaches:

```bash
# Run both approaches
python setup_pipeline.py --approach both

# Run only PyAirbyte approach
python setup_pipeline.py --approach pyairbyte

# Run only standard Python approach
python setup_pipeline.py --approach standard

# Skip dbt execution
python setup_pipeline.py --approach standard --skip-dbt
```

### Teardown Pipeline

Clean up resources:

```bash
# Show help
python teardown_pipeline.py

# Clean database tables (keep file)
python teardown_pipeline.py --clean-db

# Remove database file completely
python teardown_pipeline.py --remove-db

# Clean dbt artifacts
python teardown_pipeline.py --clean-dbt

# Clean Python cache
python teardown_pipeline.py --clean-cache

# Clean everything
python teardown_pipeline.py --all
```

## 🗄️ Database Schema

### DuckDB Structure

```sql
-- Schema
CREATE SCHEMA raw_data;

-- GitHub Repositories Table
CREATE TABLE raw_data.github_repos (
    extracted_at TIMESTAMP,
    repo_name VARCHAR,
    raw_data JSON
);

-- PyPI Packages Table
CREATE TABLE raw_data.pypi_packages (
    extracted_at TIMESTAMP,
    package_name VARCHAR,
    raw_data JSON
);
```

### Database Location

```
dbt_project/target/dbt_duckdb.db
```

## 🔄 dbt Integration

### Profile Configuration

The `dbt_project/profiles.yml` configures DuckDB:

```yaml
dbt_project:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: target/dbt_duckdb.db
      threads: 4
```

### Running dbt Manually

```bash
cd dbt_project

# Debug connection
dbt debug --profiles-dir .

# Install dependencies
dbt deps --profiles-dir .

# Run models
dbt run --profiles-dir .

# Run tests
dbt test --profiles-dir .
```

## 📝 Code Examples

### PyAirbyte Extractor Example

```python
from pyairbyte_extractors.github_pyairbyte_extractor import GitHubPyAirbyteExtractor

# Initialize and run
extractor = GitHubPyAirbyteExtractor()
extractor.run()
```

### Standard Python Extractor Example

```python
from extractors.github_duckdb_extractor import GitHubDuckDBExtractor

# Initialize and run
extractor = GitHubDuckDBExtractor()
extractor.run()
```

## 🎯 Use Cases

### When to Use PyAirbyte

- Need standardized connectors
- Want built-in incremental sync
- Working with well-supported sources
- Need to quickly prototype
- Want community support

### When to Use Standard Python

- Need custom extraction logic
- Working with custom APIs
- Want minimal dependencies
- Need fine-grained control
- Have specific performance requirements

## 🔍 Monitoring and Logging

Both approaches use `loguru` for logging:

```python
from loguru import logger

# Logs are automatically formatted and colored
logger.info("Extraction started")
logger.error("Error occurred")
```

## 🧪 Testing

### Test Individual Extractors

```bash
# PyAirbyte approach
python -m pyairbyte_extractors.github_pyairbyte_extractor
python -m pyairbyte_extractors.pypi_pyairbyte_extractor

# Standard approach
python -m extractors.github_duckdb_extractor
python -m extractors.pypi_duckdb_extractor
```

### Verify Data

```python
import duckdb

conn = duckdb.connect('dbt_project/target/dbt_duckdb.db')

# Check GitHub repos
print(conn.execute("SELECT COUNT(*) FROM raw_data.github_repos").fetchall())

# Check PyPI packages
print(conn.execute("SELECT COUNT(*) FROM raw_data.pypi_packages").fetchall())

conn.close()
```


