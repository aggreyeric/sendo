# Step-by-Step Guide: PyAirbyte vs Standard Python

Complete walkthrough for implementing both data extraction approaches with DuckDB.

---

## Quick Start (5 Minutes)

### 1. Setup Environment

```bash
# Clone/navigate to project
cd f:\presention_100\a3_pyairbyte

# Activate virtual environment
.\venv\Scripts\activate

# Install dependencies (if not done)
pip install -r requirements.txt
```

### 2. Configure GitHub Token

Create `.env` file:
```bash
GITHUB_TOKEN=ghp_your_actual_token_here
```

Get token from: https://github.com/settings/tokens (needs `repo` scope)

### 3. Run Pipeline

```bash
# Standard Python approach
python setup_pipeline.py --approach standard --skip-dbt

# PyAirbyte approach
python setup_pipeline.py --approach pyairbyte --skip-dbt

# Both approaches
python setup_pipeline.py --approach both --skip-dbt
```

### 4. Verify Data

```bash
python check_data.py
```

---

## Detailed Implementation

### Project Structure

```
a3_pyairbyte/
├── pyairbyte_extractors/          # PyAirbyte approach
│   ├── github_pyairbyte_extractor.py
│   └── pypi_pyairbyte_extractor.py
├── extractors/                     # Standard Python approach
│   ├── github_duckdb_extractor.py
│   └── pypi_duckdb_extractor.py
├── dbt_project/                    # dbt transformation
│   ├── models/
│   ├── profiles.yml
│   └── dbt_project.yml
├── setup_pipeline.py              # Main orchestration
├── teardown_pipeline.py           # Cleanup
├── check_data.py                  # Verification
└── requirements.txt
```

---

## Standard Python Approach

### Key Components

**1. GitHub Extractor** (`extractors/github_duckdb_extractor.py`)
- Direct API calls using `requests`
- Custom rate limiting
- Manual error handling
- ~200 lines of code

**2. PyPI Extractor** (`extractors/pypi_duckdb_extractor.py`)
- REST API integration
- JSON parsing
- Batch inserts to DuckDB
- ~180 lines of code

### How It Works

```python
# 1. Setup database
conn = duckdb.connect('dbt_project/target/dbt_duckdb.db')
conn.execute("CREATE SCHEMA IF NOT EXISTS raw_data")
conn.execute("CREATE TABLE IF NOT EXISTS raw_data.github_repos (...)")

# 2. Fetch data from API
response = requests.get(
    f"https://api.github.com/repos/{repo_name}",
    headers={"Authorization": f"Bearer {token}"}
)
repo_data = response.json()

# 3. Save to DuckDB
conn.execute("""
    INSERT INTO raw_data.github_repos (extracted_at, repo_name, raw_data)
    VALUES (?, ?, ?)
""", [datetime.now(), repo_name, json.dumps(repo_data)])
```

### Pros
- ✅ Full control over logic
- ✅ Easy to debug
- ✅ Minimal dependencies
- ✅ Transparent execution

### Cons
- ❌ More code to write
- ❌ Manual error handling
- ❌ No built-in incremental sync

---

## PyAirbyte Approach

### Key Components

**1. GitHub Extractor** (`pyairbyte_extractors/github_pyairbyte_extractor.py`)
- Uses Airbyte SDK
- Auto-installs connectors
- Built-in error handling
- ~120 lines of code

**2. PyPI Extractor** (`pyairbyte_extractors/pypi_pyairbyte_extractor.py`)
- Leverages HTTP source
- Standardized interface
- Stream processing
- ~110 lines of code

### How It Works

```python
# 1. Configure source
source = ab.get_source(
    "source-github",
    config={
        "credentials": {"personal_access_token": token},
        "repositories": ["apache/airflow", "dbt-labs/dbt-core"]
    },
    install_if_missing=True
)

# 2. Read data
result = source.read()

# 3. Process streams
for stream_name, records in result.streams.items():
    for record in records:
        conn.execute("INSERT INTO raw_data.github_repos VALUES (...)")
```

### Pros
- ✅ Pre-built connectors
- ✅ Less code to maintain
- ✅ Standardized patterns
- ✅ Community support

### Cons
- ❌ Framework dependency
- ❌ Less transparency
- ❌ Heavier footprint

---

## Running the Pipeline

### Command Options

```bash
# Run specific approach
python setup_pipeline.py --approach standard
python setup_pipeline.py --approach pyairbyte
python setup_pipeline.py --approach both

# Skip dbt (extract only)
python setup_pipeline.py --approach standard --skip-dbt
```

### What Happens

1. **Setup Database** — Creates DuckDB file and schema
2. **Extract GitHub Data** — Fetches 10 repositories
3. **Extract PyPI Data** — Fetches 10 packages
4. **Load to DuckDB** — Inserts JSON records
5. **Run dbt** — Transforms data (if not skipped)

### Expected Output

```
============================================================
DATA PIPELINE SETUP
============================================================

--- Standard Python Approach ---
2025-10-17 12:12:56 | INFO | Starting GitHub data extraction to DuckDB
2025-10-17 12:12:56 | INFO | Database setup completed
2025-10-17 12:12:57 | INFO | Extracting data for apache/airflow
2025-10-17 12:12:58 | INFO | Successfully extracted data for apache/airflow
...
2025-10-17 12:13:20 | INFO | Successfully saved 10 repositories to DuckDB
2025-10-17 12:13:44 | INFO | Successfully saved 10 packages to DuckDB

✅ PIPELINE SETUP COMPLETED SUCCESSFULLY
============================================================
```

---

## Data Verification

### Check Data in DuckDB

```bash
python check_data.py
```

Output:
```
============================================================
DATA VERIFICATION
============================================================

✅ GitHub repos: 10 records
✅ PyPI packages: 10 records

--- Sample GitHub Repository ---
Repo: apache/airflow
Data keys: ['repo_name', 'full_name', 'description', 'stars', ...]

✅ DATA VERIFICATION COMPLETE
============================================================
```

### Manual SQL Queries

```python
import duckdb

conn = duckdb.connect('dbt_project/target/dbt_duckdb.db')

# Count records
print(conn.execute("SELECT COUNT(*) FROM raw_data.github_repos").fetchall())

# View sample data
print(conn.execute("SELECT * FROM raw_data.github_repos LIMIT 1").fetchall())

# Query JSON fields
print(conn.execute("""
    SELECT 
        repo_name,
        json_extract(raw_data, '$.stars') as stars,
        json_extract(raw_data, '$.forks') as forks
    FROM raw_data.github_repos
    ORDER BY stars DESC
""").fetchall())

conn.close()
```

---

## dbt Integration

### Configure dbt Profile

Create `dbt_project/profiles.yml`:

```yaml
dbt_project:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: target/dbt_duckdb.db
      threads: 4
```

### Create Staging Model

Create `dbt_project/models/staging/stg_github_repos.sql`:

```sql
WITH source AS (
    SELECT
        extracted_at,
        repo_name,
        json_extract(raw_data, '$.stars') AS stars,
        json_extract(raw_data, '$.forks') AS forks,
        json_extract(raw_data, '$.language') AS language,
        json_extract(raw_data, '$.open_issues') AS open_issues
    FROM {{ source('raw_data', 'github_repos') }}
)
SELECT * FROM source
```

### Run dbt

```bash
cd dbt_project

# Test connection
dbt debug --profiles-dir .

# Run models
dbt run --profiles-dir .

# Run tests
dbt test --profiles-dir .
```

---

## Cleanup

### Teardown Options

```bash
# Clean database tables (keep file)
python teardown_pipeline.py --clean-db

# Remove database file
python teardown_pipeline.py --remove-db

# Clean dbt artifacts
python teardown_pipeline.py --clean-dbt

# Clean Python cache
python teardown_pipeline.py --clean-cache

# Clean everything
python teardown_pipeline.py --all
```

---

## Troubleshooting

### Common Issues

**Issue: `ModuleNotFoundError: No module named 'loguru'`**
```bash
Solution: pip install -r requirements.txt
```

**Issue: `GitHub token not provided`**
```bash
Solution: Create .env file with GITHUB_TOKEN=your_token
```

**Issue: `DuckDB file locked`**
```bash
Solution: Close all connections, run teardown
python teardown_pipeline.py --remove-db
```

**Issue: `Rate limit exceeded`**
```bash
Solution: Wait 1 hour or use authenticated token
```

**Issue: `dbt connection error`**
```bash
Solution: Verify profiles.yml exists in dbt_project/
```

---

## Comparison Summary

| Aspect | PyAirbyte | Standard Python |
|--------|-----------|-----------------|
| **Setup Time** | 1-2 hours | 3-4 hours |
| **Code Lines** | ~120 per extractor | ~200 per extractor |
| **Dependencies** | Many | Few |
| **Flexibility** | Limited | Full |
| **Debugging** | Medium | Easy |
| **Maintenance** | Low | Medium |
| **Best For** | Multiple sources | Custom logic |

---

## Next Steps

### Extend the Pipeline

1. **Add More Sources**
   - Create new extractors following existing patterns
   - Add to `setup_pipeline.py`

2. **Implement Incremental Sync**
   - Track last extraction timestamp
   - Only fetch new/updated records

3. **Add Data Quality Checks**
   - Validate schema before insert
   - Check for duplicates
   - Monitor data freshness

4. **Deploy to Production**
   - Containerize with Docker
   - Schedule with Airflow/cron
   - Add monitoring/alerting

### Learn More

- **PyAirbyte**: https://docs.airbyte.com/using-airbyte/pyairbyte/
- **DuckDB**: https://duckdb.org/docs/
- **dbt**: https://docs.getdbt.com/
- **Project Code**: `F:\presention_100\a3_pyairbyte\`

---

## Summary

You now have:
- ✅ Two working extraction approaches
- ✅ DuckDB database with raw data
- ✅ dbt integration for transformations
- ✅ Management scripts for operations
- ✅ Complete documentation

**Choose the approach that fits your needs and start building!**
