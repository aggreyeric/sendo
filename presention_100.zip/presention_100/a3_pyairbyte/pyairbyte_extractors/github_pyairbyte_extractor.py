"""GitHub PyAirbyte extractor to DuckDB"""

import os
import airbyte as ab
import duckdb
from loguru import logger
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()


class GitHubPyAirbyteExtractor:
    """Extract GitHub data using PyAirbyte and load to DuckDB"""
    
    def __init__(self, duckdb_path: str = "dbt_project/target/dbt_duckdb.db"):
        self.github_token = os.getenv("GITHUB_TOKEN")
        self.duckdb_path = duckdb_path
        # Start with fewer repos for testing
        self.repositories = [
            "duckdb/duckdb",
            "dbt-labs/dbt-core"
        ]
        
    def setup_database(self):
        """Create DuckDB database and schema"""
        try:
            # Create directory if it doesn't exist
            from pathlib import Path
            Path(self.duckdb_path).parent.mkdir(parents=True, exist_ok=True)
            
            conn = duckdb.connect(self.duckdb_path)
            
            # Create schema if not exists
            conn.execute("CREATE SCHEMA IF NOT EXISTS raw_data")
            
            # Create table for GitHub repos
            conn.execute("""
                CREATE TABLE IF NOT EXISTS raw_data.github_repos (
                    extracted_at TIMESTAMP,
                    repo_name VARCHAR,
                    raw_data JSON
                )
            """)
            
            conn.close()
            logger.info(f"Database setup completed at {self.duckdb_path}")
            
        except Exception as e:
            logger.error(f"Error setting up database: {e}")
            raise
    
    def extract_and_load(self):
        """Extract GitHub data using PyAirbyte and load to DuckDB"""
        try:
            if not self.github_token:
                raise ValueError("GitHub token not provided. Set GITHUB_TOKEN environment variable.")
            
            logger.info("Starting GitHub PyAirbyte extraction")
            
            # Configure GitHub source - keep repositories as list
            source = ab.get_source(
                "source-github",
                config={
                    "credentials": {
                        "personal_access_token": self.github_token
                    },
                    "repositories": self.repositories,  # Keep as list
                    "start_date": "2024-01-01T00:00:00Z"
                },
                install_if_missing=True
            )
            
            # Verify source configuration
            source.check()
            logger.info("GitHub source configured successfully")
            
            # Read data from source
            result = source.read()
            
            # Connect to DuckDB
            conn = duckdb.connect(self.duckdb_path)
            
            # Process each stream
            for stream_name, records in result.streams.items():
                logger.info(f"Processing stream: {stream_name}")
                
                # Convert records to list
                records_list = list(records)
                
                if records_list:
                    # Insert records into DuckDB
                    for record in records_list:
                        conn.execute("""
                            INSERT INTO raw_data.github_repos (extracted_at, repo_name, raw_data)
                            VALUES (CURRENT_TIMESTAMP, ?, ?)
                        """, [record.get('repository', 'unknown'), str(record)])
                    
                    logger.info(f"Loaded {len(records_list)} records from {stream_name}")
            
            conn.close()
            logger.info("GitHub PyAirbyte extraction completed successfully")
            
        except Exception as e:
            logger.error(f"GitHub PyAirbyte extraction failed: {e}")
            raise
    
    def run(self):
        """Main extraction process"""
        try:
            self.setup_database()
            self.extract_and_load()
            logger.info("GitHub PyAirbyte extraction completed")
        except Exception as e:
            logger.error(f"Extraction failed: {e}")
            raise


if __name__ == "__main__":
    extractor = GitHubPyAirbyteExtractor()
    extractor.run()
