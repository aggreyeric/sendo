"""PyPI PyAirbyte extractor to DuckDB"""

import os
import airbyte as ab
import duckdb
from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class PyPIPyAirbyteExtractor:
    """Extract PyPI data using PyAirbyte and load to DuckDB"""
    
    def __init__(self, duckdb_path: str = "dbt_project/target/dbt_duckdb.db"):
        self.duckdb_path = duckdb_path
        self.packages = [
            "apache-airflow",
            "dbt-core",
            "pyspark", 
            "pandas",
            "sqlalchemy",
            "great-expectations",
            "prefect",
            "kafka-python",
            "snowflake-connector-python",
            "duckdb"
        ]
        
    def setup_database(self):
        """Create DuckDB database and schema"""
        try:
            # Create directory if it doesn't exist
            from pathlib import Path
            Path(self.duckdb_path).parent.mkdir(parents=True, exist_ok=True)
            
            conn = duckdb.connect(self.duckdb_path)
            
            # Create schema if not exists
            conn.execute("CREATE SCHEMA IF NOT EXISTS raw_data")
            
            # Create table for PyPI packages
            conn.execute("""
                CREATE TABLE IF NOT EXISTS raw_data.pypi_packages (
                    extracted_at TIMESTAMP,
                    package_name VARCHAR,
                    raw_data JSON
                )
            """)
            
            conn.close()
            logger.info(f"Database setup completed at {self.duckdb_path}")
            
        except Exception as e:
            logger.error(f"Error setting up database: {e}")
            raise
    
    def extract_and_load(self):
        """Extract PyPI data using PyAirbyte and load to DuckDB"""
        try:
            logger.info("Starting PyPI PyAirbyte extraction")
            
            # Note: PyPI doesn't have a native Airbyte connector
            # We'll use HTTP source to fetch from PyPI API
            # For demonstration, we'll create a custom approach
            
            import requests
            import json
            from datetime import datetime, timezone
            
            conn = duckdb.connect(self.duckdb_path)
            
            for package_name in self.packages:
                try:
                    logger.info(f"Extracting data for {package_name}")
                    
                    # Fetch from PyPI API
                    response = requests.get(f"https://pypi.org/pypi/{package_name}/json")
                    response.raise_for_status()
                    package_data = response.json()
                    
                    # Insert into DuckDB
                    conn.execute("""
                        INSERT INTO raw_data.pypi_packages (extracted_at, package_name, raw_data)
                        VALUES (?, ?, ?)
                    """, [
                        datetime.now(timezone.utc),
                        package_name,
                        json.dumps(package_data)
                    ])
                    
                    logger.info(f"Successfully loaded {package_name}")
                    
                except Exception as e:
                    logger.error(f"Error processing {package_name}: {e}")
                    continue
            
            conn.close()
            logger.info("PyPI PyAirbyte extraction completed successfully")
            
        except Exception as e:
            logger.error(f"PyPI PyAirbyte extraction failed: {e}")
            raise
    
    def run(self):
        """Main extraction process"""
        try:
            self.setup_database()
            self.extract_and_load()
            logger.info("PyPI PyAirbyte extraction completed")
        except Exception as e:
            logger.error(f"Extraction failed: {e}")
            raise


if __name__ == "__main__":
    extractor = PyPIPyAirbyteExtractor()
    extractor.run()
