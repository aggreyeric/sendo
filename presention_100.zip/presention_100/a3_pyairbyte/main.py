def main():
    print("Hello from data-engineering-pipeline!")


if __name__ == "__main__":
    main()
