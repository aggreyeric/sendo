"""GitHub API extractor for data engineering technologies - DuckDB version"""

import os
import json
import time
from datetime import datetime, timezone
from typing import List, Dict, Any
import requests
import duckdb
from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class GitHubDuckDBExtractor:
    """Extract GitHub repository metrics for data engineering technologies"""
    
    def __init__(self, duckdb_path: str = "dbt_project/target/dbt_duckdb.db"):
        self.github_token = os.getenv("GITHUB_TOKEN")
        self.base_url = "https://api.github.com"
        self.duckdb_path = duckdb_path
        self.headers = {
            "Authorization": f"Bearer {self.github_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        self.repositories = [
            "apache/airflow",
            "dbt-labs/dbt-core", 
            "apache/spark",
            "pandas-dev/pandas",
            "sqlalchemy/sqlalchemy",
            "great-expectations/great_expectations",
            "prefecthq/prefect",
            "apache/kafka",
            "snowflakedb/snowflake-connector-python",
            "duckdb/duckdb"
        ]
        
    def get_repo_data(self, repo_name: str) -> Dict[str, Any]:
        """Fetch repository data from GitHub API"""
        try:
            # Get basic repository information
            repo_url = f"{self.base_url}/repos/{repo_name}"
            response = requests.get(repo_url, headers=self.headers)
            
            if response.status_code == 403:
                logger.warning(f"Rate limit hit for {repo_name}, waiting...")
                time.sleep(60)
                response = requests.get(repo_url, headers=self.headers)
            
            response.raise_for_status()
            repo_data = response.json()
            
            # Get additional metrics
            contributors_url = f"{self.base_url}/repos/{repo_name}/contributors"
            contributors_response = requests.get(contributors_url, headers=self.headers)
            contributors_count = len(contributors_response.json()) if contributors_response.status_code == 200 else 0
            
            # Get recent releases
            releases_url = f"{self.base_url}/repos/{repo_name}/releases"
            releases_response = requests.get(releases_url, headers=self.headers)
            releases = releases_response.json() if releases_response.status_code == 200 else []
            
            # Compile comprehensive data
            extracted_data = {
                "repo_name": repo_name,
                "full_name": repo_data.get("full_name"),
                "description": repo_data.get("description"),
                "language": repo_data.get("language"),
                "stars": repo_data.get("stargazers_count", 0),
                "forks": repo_data.get("forks_count", 0),
                "watchers": repo_data.get("watchers_count", 0),
                "open_issues": repo_data.get("open_issues_count", 0),
                "size": repo_data.get("size", 0),
                "created_at": repo_data.get("created_at"),
                "updated_at": repo_data.get("updated_at"),
                "pushed_at": repo_data.get("pushed_at"),
                "default_branch": repo_data.get("default_branch"),
                "contributors_count": contributors_count,
                "releases_count": len(releases),
                "latest_release": releases[0] if releases else None,
                "topics": repo_data.get("topics", []),
                "license": repo_data.get("license", {}).get("name") if repo_data.get("license") else None,
                "extracted_at": datetime.now(timezone.utc).isoformat()
            }
            
            logger.info(f"Successfully extracted data for {repo_name}")
            return extracted_data
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching data for {repo_name}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error for {repo_name}: {e}")
            return None
    
    def setup_database(self):
        """Create DuckDB database and schema"""
        try:
            # Create directory if it doesn't exist
            from pathlib import Path
            Path(self.duckdb_path).parent.mkdir(parents=True, exist_ok=True)
            
            conn = duckdb.connect(self.duckdb_path)
            
            # Create schema if not exists
            conn.execute("CREATE SCHEMA IF NOT EXISTS raw_data")
            
            # Create table for GitHub repos
            conn.execute("""
                CREATE TABLE IF NOT EXISTS raw_data.github_repos (
                    extracted_at TIMESTAMP,
                    repo_name VARCHAR,
                    raw_data JSON
                )
            """)
            
            conn.close()
            logger.info(f"Database setup completed at {self.duckdb_path}")
            
        except Exception as e:
            logger.error(f"Error setting up database: {e}")
            raise
    
    def save_to_duckdb(self, data: List[Dict[str, Any]]):
        """Save extracted data to DuckDB raw table"""
        if not data:
            logger.warning("No data to save")
            return

        try:
            conn = duckdb.connect(self.duckdb_path)
            
            # Prepare data for batch insert
            insert_data = []
            for repo_data in data:
                if repo_data:
                    try:
                        json_str = json.dumps(repo_data)
                        insert_data.append((
                            datetime.now(timezone.utc),
                            repo_data.get('repo_name'),
                            json_str
                        ))
                    except (TypeError, ValueError) as e:
                        logger.error(f"JSON serialization failed for {repo_data.get('repo_name')}: {e}")
                        continue

            if not insert_data:
                logger.warning("No valid data to insert after filtering.")
                return

            # Insert into DuckDB
            conn.executemany("""
                INSERT INTO raw_data.github_repos (extracted_at, repo_name, raw_data)
                VALUES (?, ?, ?)
            """, insert_data)

            conn.close()
            logger.info(f"Successfully saved {len(insert_data)} repositories to DuckDB")

        except Exception as e:
            logger.error(f"Error saving to DuckDB: {e}")
            raise
    
    def extract_all_repositories(self) -> List[Dict[str, Any]]:
        """Extract data for all configured repositories"""
        logger.info(f"Starting extraction for {len(self.repositories)} repositories")
        
        extracted_data = []
        for repo in self.repositories:
            logger.info(f"Extracting data for {repo}")
            repo_data = self.get_repo_data(repo)
            if repo_data:
                extracted_data.append(repo_data)
            
            # Rate limiting - GitHub allows 5000 requests per hour
            time.sleep(1)
        
        logger.info(f"Extraction completed. {len(extracted_data)} repositories processed successfully")
        return extracted_data
    
    def run(self):
        """Main extraction process"""
        try:
            if not self.github_token:
                raise ValueError("GitHub token not provided. Set GITHUB_TOKEN environment variable.")
            
            logger.info("Starting GitHub data extraction to DuckDB")
            self.setup_database()
            data = self.extract_all_repositories()
            
            if data:
                self.save_to_duckdb(data)
                logger.info("GitHub extraction completed successfully")
            else:
                logger.warning("No data extracted")
                
        except Exception as e:
            logger.error(f"GitHub extraction failed: {e}")
            raise


if __name__ == "__main__":
    extractor = GitHubDuckDBExtractor()
    extractor.run()
