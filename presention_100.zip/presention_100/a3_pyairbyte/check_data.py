"""Quick script to verify data in DuckDB"""
import duckdb

conn = duckdb.connect('dbt_project/target/dbt_duckdb.db')

print("=" * 60)
print("DATA VERIFICATION")
print("=" * 60)

# Check GitHub repos
github_count = conn.execute('SELECT COUNT(*) FROM raw_data.github_repos').fetchone()[0]
print(f"\n✅ GitHub repos: {github_count} records")

# Check PyPI packages
pypi_count = conn.execute('SELECT COUNT(*) FROM raw_data.pypi_packages').fetchone()[0]
print(f"✅ PyPI packages: {pypi_count} records")

# Show sample GitHub data
print("\n--- Sample GitHub Repository ---")
sample = conn.execute('SELECT repo_name, raw_data FROM raw_data.github_repos LIMIT 1').fetchone()
if sample:
    print(f"Repo: {sample[0]}")
    print(f"Data keys: {list(sample[1].keys())[:10]}...")

# Show sample PyPI data
print("\n--- Sample PyPI Package ---")
sample = conn.execute('SELECT package_name, raw_data FROM raw_data.pypi_packages LIMIT 1').fetchone()
if sample:
    print(f"Package: {sample[0]}")
    print(f"Data keys: {list(sample[1].keys())[:10]}...")

print("\n" + "=" * 60)
print("✅ DATA VERIFICATION COMPLETE")
print("=" * 60)

conn.close()
